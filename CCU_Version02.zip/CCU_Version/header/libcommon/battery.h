#ifndef __I_BATTERY__
#define __I_BATTERY__
#include <stdbool.h>
#include <unistd.h>
#include <poll.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

int i_battery_init();
int i_battery_get_health();
int i_battery_get_voltage( double * );
int i_get_battery_status( int *b_chrg_status );
int battery_connect_config(int con_status);
int battery_charge_state_config(int state);
int get_power_source();

#endif
