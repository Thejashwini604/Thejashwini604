#ifndef _STATUS_CHECK_H_
#define _STATUS_CHECK_H_


/**************************************************************************************************************************/
/*----------------------------------------------Macros--------------------------------------------------------------------*/
/**************************************************************************************************************************/
#define GSM_RESP_TIME 800000     //response time to read response from GSM module, time in microseconds

// Define the macro bt_ccu_SIMDetected with the value 0xE001000B
#define bt_ccu_SIMDetected 0xE001000B  // This value represents the SIM detected status or similar context


/**
 * Function to get the Ignition status.
 * This function checks and returns the status of the Ignition initialization (TRUE if initialized, FALSE otherwise).
 */
bool bt_ccu_IGN_STS(void);

/**
 * Function to get the ADC Source Voltage status.
 * This function checks and returns the status of ADC Source Voltage initialization (TRUE if successful, FALSE otherwise).
 */
float bt_ccu_ADC_SRC_V(void);

/**
 * Function to get the ADC External Source Voltage status.
 * This function checks and returns the status of ADC External Source Voltage initialization (TRUE if successful, FALSE otherwise).
 */
float bt_ccu_ADC_ETRL_V(void);

/**
 * Function to initialize or check the status of all peripheral devices.
 * This function initializes or checks the status of various peripherals, such as Ignition, ADC Source Voltage, ADC External Source Voltage, etc.
 */
void bt_ccu_PHERIPH(void);

/**
This API is used to send the message to the specific contact number when the MSOS or ASOS event 
is triggered **/
bool bt_ccu_SendSMS(void);

/**
 * This api will return the global variable V_ccu_GSM_set_msg_init true when the modem 
 *  is on and gsm set message initialisation is success  **/
bool bt_ccu_GSM_SET_MSG_STS(void) ;

/**This api will return the global variable V_ccu_gsm_modem_sts when gsm modem status is on **/
bool bt_ccu_GSM_MODEM_STS(void);

/** This api will return the global varaible of SIM status **/
bool bt_ccu_SIM_STS(void);

int MCU_ADC_Read_Request(int adc, float *voltage);

 
bool bt_ccu_CHECK_NW_CONN_STS(void);
 
bool bt_ccu_CHECK_GSM_NW_STS(void); 
#endif // _STATUS_CHECK_H_

