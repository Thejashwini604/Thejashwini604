/**********************************General MAcros header file*************************************************************
Author: Thejashwini Anand
Date: 12/26/2024
Brigosha technologies pvt lmt
/**************************************************************************************************************************/
/*----------------------------------------------Macros--------------------------------------------------------------------*/
/**************************************************************************************************************************/

#define TRUE 1
#define FALSE 0
#define ZERO 0
#define HIGH 1


#define BT_SUCCESS 0
#define BT_FAILURE -1
#define INVALID_ARGUMENTS_PASSED -2

//Set bit 
#define SET_BIT(Val, Mask) Val=Val|Mask    
 
//clear bit at Position Pos
#define CLR_BIT(Val,Pos) ((Val)&=(~(1)<<Pos)) 
