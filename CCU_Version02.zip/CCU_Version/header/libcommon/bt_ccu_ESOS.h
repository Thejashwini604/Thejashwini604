/*****************************************************************************
 * @file bt_ccu_EmergencySOS.h
 * @author Thejashwini Anand @ Brigosha Technologies
 * @date January 21, 2025
 * @brief This file contains the Prototypes for Initialization functions.
 * @note
 * Copyright(C) Brigosha Technologies, 2025
 * All rights reserved.
 */
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/

/**************************************************************************************************************************/
/*----------------------------------------------Includes------------------------------------------------------------------*/
/**************************************************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <termios.h>
#include <signal.h>
#include <stdint.h>
#include <linux/netlink.h>
#include <linux/if_link.h>
#include <linux/input.h>
#include <linux/rtnetlink.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>
#include "gsm.h"
#include <can.h>
#include "battery.h"
#include <time.h>
#include "error_nos.h"
#include "stdbool.h"
#include "Std_generalmacros.h"
#include "bt_ccu_Init.h"
#include "bt_ccu_IMUSensors.h"

//Function prototyping
int read_digital_in (int din1, int *state); // this api has two digital input ports DIN1 and DIN2 we are using DIN1 for MSOS switch
int write_digital_out (int dout, int state);

/***************************************************************************************************************************/
/*----------------------------------------8 bit Message byte information---------------------------------------------------*/
/**************************************************************************************************************************

0th and 1st bit - MSOS Switch status   (00-msos off, 01-msos on, 10-msos error,11 - reserved)
2nd bit --        MSOS Acknowledgement  (1-msos ack received, 0-not received)
3rd and 4th bit - ASOS Status  (00-asos off, 01-asos on, 10-asos error,11 - reserved)
5th bit --        ASOS Acknowledgement  (1-asos ack received, 0-not received)
6th bit --        MSOS Send sms error (1- Err present, 0- no error)
7th bit --        ASOS Send sms error (1- Err present, 0- no error)
/**************************************************************************************************************************/

/**************************************************************************************************************************/
/*----------------------------------------------Macros--------------------------------------------------------------------*/
/**************************************************************************************************************************/

#define BT_ENABLE_MSOS 0
#define BT_DISABLE_MSOS 1

#define BT_DIN1 1
#define BT_DOU1 1

#define BT_ON 1
#define BT_OFF 0

#define BT_ASOS_OFF 3 
#define BT_CLR_ASOS_ACK 5  
#define BT_CLR_MSOS_ACK 2  


//MASK for MSOS 
#define BT_MSOS_SWITCH_OFF 0         //00000 0 00 msos_off_e  [1:0]
#define BT_MSOS_SWITCH_ON 1          //00000 0 01 msos_on_e   [1:0]
#define BT_MSOS_SWITCH_ERROR 2  //00000 0 10 msos_failure_e [1:0]  
                                                                     //00000 0 11 reserved [1:0]
#define BT_MSOS_ACK_STATUS 4        //00000 1 00 MSOS_Ack [2]


//MASK for ASOS
//00 000 000 asos_off_e  [4:3]
#define BT_ASOS_ON 8            //00 001 000 asos_on_e   [4:3]
#define BT_ASOS_SENSOR_ERROR 0X010     //00 010 000 asos_failure_e  [4:3]
                                                                               //00 011 000 asos reserved   [4:3]
#define BT_ASOS_ACK_STATUS 0X020      //00 100 000 ASOS_Ack [5]

#define BT_MSOS_SEND_SMS_ERR 0X040    //01000000 [6]
#define BT_ASOS_SEND_SMS_ERR 0X080   //10000000 [7]


#define BT_SPEED_TEN_kmph 10
#define ASOS_ALGO_TRIG 1
#define ASOS_ALGO_OFF 0

/******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/

uint8_t bt_ccu_ESOS_Message_Byte_u8(void);
/**
* @code
* uint8_t bt_ccu_ESOS_Message_Byte_u8(void)
* @endcode
* @ brief: This api is use to get the ESOS message byte after calling the ESOS Manual & automatic features
* @ param: no params
* @ return: uint8 type, message byte information available in the begining of the file
**/

void bt_ccu_MnlEmgcySOS(void);
/**
* @ code 
* @ int bt_ccu_MnlEmgcySOS(void)
* @endcode
* @ Brief: This API is used to activate or deactivate the manual emergencySOS 
  and to perform operations specified in the feature
* @ param: no params
* @ return: no returns
**/

void bt_ccu_AtoEmgcySOS(void);
/**
* @ code int bt_ccu_AtoEmgcySOS(void)
* @ Brief: This API is used to activate or deactivate the auto emergencySOS and to
*   perform operations specified in the feature the fature use the IMU sensor data 
* @ param: no params
* @ return: no ret
**/
 
/******************************************************************************/
/*-------------------------------Constants-----------------------------------*/
/******************************************************************************/

/***************************End of file************************************************/
