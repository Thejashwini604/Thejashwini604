#include <stdbool.h>
/**
 * @file bt_Initialisation.h
 * @author Venkatesh Prasad k @ Brigosha Technologies
 * @date January 2, 2025
 * @brief This file contains the Prototypes for Initialization functions.
 * @note
 * Copyright(C) Brigosha Technologies, 2025
 * All rights reserved.
 */
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/
 /******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/
/**
 * @code
 *  bt_CCU_Initialisation(void)
 * @endcode
 * @brief This function initializes all the peripherals related to the CCU (Central Control Unit).
 * @param void
 * @return None
 * @note This function is called to configure the CCU and initialize all necessary peripherals before use.
 */
void bt_ccu_INIT(void);

/**
 * @code
 *  BT_CANInit(void)
 * @endcode
 * @brief This function initializes the CAN (Controller Area Network) interface.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note The function configures the CAN controller for communication with other CAN devices.
 */
bool bt_ccu_INIT_CAN_STS(void);

/**
 * @code
 *  BT_WIFIInit(void)
 * @endcode
 * @brief This function initializes the Wi-Fi module for wireless communication.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function configures the Wi-Fi module for network connectivity.
 */
bool bt_ccu_INIT_WIFI_STS(void);

/**
 * @code
 *  BT_BLE_Init(void)
 * @endcode
 * @brief This function initializes the Bluetooth Low Energy (BLE) module for communication.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function prepares the BLE module for short-range wireless communication.
 */
bool bt_ccu_INIT_BLE_STS(void);

/**
 * @code
 *  BT_Accelerometer_Init(void)
 * @endcode
 * @brief This function initializes the accelerometer sensor for motion sensing.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function sets up the accelerometer sensor for detecting movement or orientation changes.
 */
bool bt_ccu_INIT_ACC_STS(void);

/**
 * @code
 *  BT_Gyro_Init(void)
 * @endcode
 * @brief This function initializes the gyroscope sensor for rotational motion sensing.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function configures the gyroscope for detecting angular velocity or rotation.
 */
bool bt_ccu_INIT_GYRO_STS(void);

/**
 * @code
 *  BT_Magnetometer_Init(void)
 * @endcode
 * @brief This function initializes the magnetometer sensor for magnetic field detection.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function prepares the magnetometer sensor for detecting magnetic fields and orientation.
 */
bool bt_ccu_INIT_MAG_STS(void);

bool bt_ccu_INIT_STS(void);

bool bt_ccu_BAT_INIT_STS(void);

int ign_pin_status_check_enable(void);
  /******************************************************************************/
/*-----------------------------END--------------------------------*/
/******************************************************************************/

