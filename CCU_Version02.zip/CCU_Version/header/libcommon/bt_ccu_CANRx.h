 /**
 * @file bt_ccu_CANRx.h
 * @author Venkatesh Prasad k @ Brigosha Technologies
 * @date January 2, 2025
 * @brief This file contains the Prototypes Initialisation.
 * @note
 * Copyright(C) Brigosha Technologies, 2025
 * All rights reserved.
 */
 
 #include <stdbool.h>
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/
 /******************************************************************************/
  /******************************************************************************/
/*-----------------------------MACROS--------------------------------*/
/******************************************************************************/
 /******************************************************************************/
 
static struct bt_ccu_ECU_Rx bt_ccu_ECU_DATA;  	// Structure to store ECU data

static struct bt_ccu_BBS_Rx bt_ccu_BBS_DATA;  	// Struct to store BBS data received via CAN
 // CAN IDs
#define C_ccu_CANRx_BBS 0x18
#define C_ccu_CANRx_ECU 0x24
 
/*-----------------------------Data Structures--------------------------------*/
/******************************************************************************/
/** @struct BBS_Data01
 *  @brief This structure is the structure of the CAN Message
 */
struct bt_ccu_BBS_Rx{
	
uint8_t BBS_ExvlM_NA_ERR	;// BBS_ExvlM_NA_ERR 1 bits
uint8_t BBS_FSpeedSTAT		;// BBS_FSpeedSTAT 2 bits
uint16_t BBS_FSpeed		;// BBS_FSpeed 13 bits
uint8_t BBS_RSpeedSTAT		;// BBS_RSpeedSTAT 2 bits
uint8_t BBS_ExvlCheck		;// BBS_ExvlCheck 1 bits
uint16_t BBS_RSpeed		;// BBS_RSpeed 13 bits
uint8_t BBS_DWCLevACK		;// BBS_DWCLevACK 3 bits
uint8_t BBS_DTC_STAT		;// BBS_DTC_STAT 2 bits
uint8_t BBS_DTCLevACK		;// BBS_DTCLevACK 3 bits
uint8_t BBS_DSC_STAT		;// BBS_DSC_STAT 2 bits
uint8_t BBS_DSCLevACK		;// BBS_DSCLevACK 3 bits
uint8_t BBS_DWC_STAT		;// BBS_DWC_STAT 2 bits
uint8_t BBS_Data01_CNT		;// BBS_Data01_CNT 4 bits
uint8_t BBS_ExvlPot_ERR2	;// BBS_ExvlPot_ERR2 1 bits
uint8_t BBS_ExvlPot_ERR1	;// BBS_ExvlPot_ERR1 1 bits
uint8_t BBS_DAVC_STAT		;// BBS_DAVC_STAT 2 bits
uint8_t BBS_Data01_CRC		;// BBS_Data01_CRC 8 bits

};
struct bt_ccu_ECU_Rx{
	uint8_t ECU_APS		;// ECU_APS 8 bits
	uint8_t ECU_EngSTAT	;// ECU_EngSTAT 3 bits
	uint8_t ECU_DOWNshift	;// ECU_DOWNshift 1 bits
	uint8_t ECU_CCswitchERR	;// ECU_CCswitchERR 1 bits
	uint8_t ECU_UPshift	;// ECU_UPshift 1 bits
	uint8_t ECU_ApsERR	;// ECU_ApsERR 1 bits
	uint8_t ECU_CCswitch	;// ECU_CCswitch 1 bits
	uint8_t ECU_RPM_ERR	;// ECU_RPM_ERR 1 bits
	uint16_t ECU_RPM	;// ECU_RPM 15 bits
	uint8_t ECU_BrakeERR	;// ECU_BrakeERR 2 bits
	uint8_t ECU_GearStb	;// ECU_GearStb 1 bits
	uint8_t ECU_GearSet	;// ECU_GearSet 1 bits
	uint8_t ECU_GearERR	;// ECU_GearERR 1 bits
	uint8_t ECU_Gear	;// ECU_Gear 3 bits
	uint8_t ECU_SideStandERR;// ECU_SideStandERR 1 bits
	uint8_t ECU_BikeModel	;// ECU_BikeModel 4 bits
	uint8_t ECU_SideStand	;// ECU_SideStand 1 bits
	uint8_t ECU_R_Brake	;// ECU_R_Brake 1 bits
	uint8_t ECU_F_Brake	;// ECU_F_Brake 1 bits
	uint8_t ECU_Data01_CNT	;// ECU_Data01_CNT 4 bits
	uint8_t ECU_RLlambdaSTAT;// ECU_RLlambdaSTAT 1 bits
	uint8_t ECU_FLlambdaSTAT;// ECU_FLlambdaSTAT 1 bits
	uint8_t ECU_ClutchSTAT	;// ECU_ClutchSTAT 2 bits
	uint8_t ECU_Data01_CRC	;// ECU_Data01_CRC 8 bits
};
 /******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/
/**
 * @code
 *  CAN_BBSApplicationProcessing(void)
 * @endcode
 * @brief this function is used read the CAN Rx with Message ID 0x18
  * @param void
 * @return CAN read Specific Codes
 * @note
 */
void bt_ccu_CAN_Rx_BBSAppProc(void);
/**
 * @code
 *  CAN_ECUApplicationProcessing(void)
 * @endcode
 * @brief this function is used read the CAN Rx with Message ID 0x24
  * @param void
 * @return CAN read Specific Codes
 * @note
 */
void bt_ccu_CAN_RxECUAppProc(void);

/**
 * @brief This function checks the status of the ECU (Electronic Control Unit) read operation.
 * @param void
 * @return Returns TRUE if ECU read operation is successful, otherwise FALSE.
 * @note Used to determine if the ECU is successfully reading data.
 */
bool bt_ccu_RX_ECUREADSTS(void);

/**
 * @brief This function checks the status of the BBS (Battery Backup System) read operation.
 * @param void
 * @return Returns TRUE if BBS read operation is successful, otherwise FALSE.
 * @note Used to determine if the BBS is successfully reading data.
 */
bool bt_ccu_RX_BBSREADSTS(void);

/**
 * Function to reset the BBS receive (Rx) data structure.
 * 
 * This function resets the fields in the BBS receive data structure (`BBS_Rx`), clearing
 * any previously stored data, and preparing the structure to receive fresh data.
 * It is useful when the system is about to begin receiving new BBS data.
 * 
 * @param bbs_data A pointer to the `BBS_Rx` structure that will be reset.
 */
void bt_ccu_RESET_BBS_Rx(void);

/**
 * Function to reset the ECU receive (Rx) data structure.
 * 
 * This function resets the fields in the ECU receive data structure (`ECU_Rx`), clearing
 * any previously stored data, and preparing the structure to receive fresh data.
 * It is useful when the system is about to begin receiving new ECU data.
 * 
 * @param ecu_data A pointer to the `ECU_Rx` structure that will be reset.
 */
void bt_ccu_RESET_ECU_Rx(void);


// Declare a structure for receiving BBS (Baseband Signal) data over CAN (Controller Area Network)
struct bt_ccu_BBS_Rx bt_ccu_BBS_EXTCT_DATA(void);

// Declare a structure for receiving ECU (Electronic Control Unit) data over CAN
struct bt_ccu_ECU_Rx bt_ccu_ECU_EXTCT_DATA(void);

int set_can_mask_and_filter (uint32_t *mask, uint32_t *filter, int no_of_filter); 
  /******************************************************************************/
/*-----------------------------END--------------------------------*/
/******************************************************************************/
