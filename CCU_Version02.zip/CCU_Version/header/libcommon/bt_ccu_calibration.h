/*************includes***************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <termios.h>
#include <signal.h>
#include <stdint.h>
#include <linux/netlink.h>
#include <linux/if_link.h>
#include <linux/input.h>
#include <linux/rtnetlink.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>
#include "gsm.h"
#include <can.h>
#include "gyroscope.h"
#include "accelerometer.h"
#include "error_nos.h"
#include "magnetometer.h"
#include "battery.h"
#include <time.h>
#include "bt_ccu_IMUSensors.h"


void bt_ccu_IMU_Calibration_Process(void) ;


