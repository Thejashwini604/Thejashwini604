#include <pthread.h>
#include "stdio.h"
#include "common.h"
#include "bt_ccu_Init.h"
#include "bt_ccu_Threads.h"  
        
int main() {

    pthread_t BBSRx_thread, ECURx_thread,imu_thread, peripherals_thread, gps_thread, manual_sos_thread, auto_sos_thread, can_tx_thread,mqtt_Device_thread, mqtt_gps_thread;
    int ret;


    //This function likely handles the setup or initialization of the CCU
     bt_ccu_INIT();
     
     
    // Create threads for each functionality
    ret = pthread_create(&BBSRx_thread, NULL, BBSRx_thread_func, NULL);
    if (ret == 0) 
    {
        
        
        printf("RX thread is created succesfully for the ID 0x18\n");
        printf("Return value of RX thread ID 0x18 is %d\n",ret);
        
    }
    else
    {
        printf("Error creating RX thread for the ID 0x18\n");
        return -1;
    }
    
    ret = pthread_create(&ECURx_thread, NULL, ECURx_thread_func, NULL);
    if (ret == 0) 
    {
        
       
        printf("RX thread is created succesfully for the ID 0x24\n");
        printf("Return value of RX thread ID 0x24 is %d\n",ret);
       
    }
    else
    {
        printf("Error creating RX thread for the ID 0x24\n");
        return -1;
    }
    
    ret = pthread_create(&imu_thread, NULL, imu_thread_func, NULL);
    if (ret == 0) 
    {
        
        
        printf("IMU thread is created successfully\n");
        printf("Return value of IMU thread is %d\n",ret);
        
    }
    else
    {
        printf("Error creating IMU thread\n");
        return -1;
    }
	
    ret = pthread_create(&peripherals_thread, NULL, peripherals_thread_func, NULL);
    if (ret == 0) 
    {
        
        
        printf("peripherals thread is created successfully\n");
        printf("Return value of peripherals thread is %d\n",ret);
        
    }
    else
    {
        printf("Error creating peripherals thread\n");
        return -1;
    }

    ret = pthread_create(&gps_thread, NULL, gps_thread_func, NULL);
    if (ret == 0) 
    {
        
        
        printf("gps thread is created successfully\n");
        printf("Return value of gps thread is %d\n",ret);
        
    }
    else
    {
        printf("Error creating gps thread\n");
        return -1;
    }

    ret = pthread_create(&manual_sos_thread, NULL, manual_sos_thread_func, NULL);
    if (ret == 0) 
    {
        
        
        printf("manual sos thread is created successfully\n");
        printf("Return value of manual sos thread is %d\n",ret);
        
    }
    else
    {
        printf("Error creating manual sos thread\n");
        return -1;
    }

    ret = pthread_create(&auto_sos_thread, NULL, auto_sos_thread_func, NULL);
    if (ret == 0) 
    {
        
        
        printf("Automatic sos thread is created successfully\n");
        printf("Return value of automatic sos thread is %d\n",ret);
        
    }
    else
    {
        printf("Error creating Automatic sos thread\n");
        return -1;
    }

    ret = pthread_create(&can_tx_thread, NULL, can_tx_thread_func, NULL);
    if (ret == 0) 
    {
        
        
        printf("CAN TX thread is created successfully for the ID 0x4EOh\n");
        printf("Return value of Can TX thread for the ID 0x4EOh is %d\n",ret);
        
    }
    else
    {
        printf("Error creating TX thread for the ID 0x4EOh\n");
        return -1;
    }
    ret = pthread_create(&mqtt_Device_thread, NULL, ccu_mqtt_device_Thread, NULL);
    if (ret == 0) 
    {
        
        
        printf("MQTT Device thread is created successfully.\n");
        printf("Return value of MQTT Device Thread is %d\n",ret);
        
    }
    else
    {
        printf("Error creating MQTT Device Thread\n");
        return -1;
    }
    ret = pthread_create(&mqtt_gps_thread, NULL, ccu_mqtt_gps_Thread, NULL);
    if (ret == 0) 
    {
        
        
        printf("MQTT GPS thread is created successfully\n");
        printf("Return value of MQTT GPS Thread is%d\n",ret);
        
    }
    else
    {
        printf("Error creating MQTT GPS Thread\n");
        return -1;
    }
    pthread_join(BBSRx_thread, NULL);
    pthread_join(ECURx_thread, NULL);
    pthread_join(imu_thread, NULL);
    pthread_join(peripherals_thread, NULL);
    pthread_join(gps_thread, NULL);
    pthread_join(manual_sos_thread, NULL);
    pthread_join(auto_sos_thread, NULL);
    pthread_join(can_tx_thread, NULL);
    pthread_join(mqtt_Device_thread, NULL);
    pthread_join(mqtt_gps_thread, NULL);   
          
    return 0;
}

