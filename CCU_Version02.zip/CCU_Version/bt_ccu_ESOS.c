/********************************************************************************************************************
* @file bt_ccu_EmergencySOS.c
* @author Thejashwini Anand @ Brigosha Technologies
* @date January 16, 2025
* @brief This file contains the API used to send the sms to emergency contact.
*
* @note
* Copyright(C) Brigosha Technologies, 2024
* All rights reserved.
*
/*Automatic Emergency SOS systems are used to send the sms with the User/emergency contacts when there is an 
emergency occurred. The system uses sensors to detect an emergency/

/**************************************************************************************************************************/
/*----------------------------------------------Includes------------------------------------------------------------------*/
/**************************************************************************************************************************/
#include "bt_ccu_ESOS.h"
#include "bt_ccu_Pheripherals.h" 
#include "bt_ccu_CANRx.h"
#include "bt_ccu_AtoEmgcySOS_Algo.h"
//ESOS Message byte
uint8_t V_ESOS_MessageByte_u8; // global variable to store the status message of the emergency sos application

 /*****************************************************************************************************************************************/
/** This function is used to check the accelerometer sensors values and set the flag if it crosses the 
 specified threshold values defined**/
 bool bt_ccu_IMU_ChkAccThreshold(void);
 
  /** This function is used to check the gyroscope sensors values and set the flag if it crosses the 
 specified threshold values defined**/
 bool bt_ccu_IMU_ChkGyroThreshold(void);
 
 /** This function is used to enable the logic 1 application to enable the ASOS **/
 void bt_ccu_AtoEmgcySOS_NonAlgo(void) ;
 
 /*****************************************************************************************************************************************/

const signed int C_Acc_min_x=-5;
const unsigned int C_Acc_max_x= 5;

const signed int C_Acc_min_y=-5;
const unsigned int C_Acc_max_y= 5;
 
const signed int C_gyro_min_x=-5;
const unsigned int C_gyro_max_x= 5;

const signed int C_gyro_min_y=-0.05;
const unsigned int C_gyro_max_y=0.05;

/******************************************************************************************************************************************/
/*------------------------------------Manual ESOS Function Implementaion----------------------------------------------------------------------------*/
/*****************************************************************************************************************************************
@ code void bt_ccu_MnlEmgcySOS(void)
@ Brief: This API is used to activate or deactivate the manual emergencySOS and to perform operations specified in the feature
@ param: no params
@ return: no returns
*****************************************************************************************************************************************/
/** Manual SOS switch logic**********************************************************************************************************
 ---------------------------------------------------------------------------
 DIN    DOUT        MSOS Switch status
 1             0               Closed
 0             1               Open
 ------------------------------------------------------------------------------
 ****************************************************************************************************************************************/
void bt_ccu_MnlEmgcySOS(void)
 {
	 if((bt_ccu_GSM_MODEM_STS()==TRUE) && ( bt_ccu_GSM_SET_MSG_STS()==TRUE)&&(bt_ccu_SIM_STS()==TRUE))
	 {
       //Switch Status
       uint8_t v_msos_switch_u8= BT_DIN1;                                  // digital input port from the user using switch 
       int v_msos_state_u8 = BT_DISABLE_MSOS;                      // to store the state of the swicth ENABLE_SOS-0, DISABLE_SOS-1,  current state
       uint8_t v_msos_dout1_u8=BT_DOU1;                                // digital output port to close the switch when switch is pressed
       int v_msos_dout_state_u8;                                                  // to store the status of the digital output
       bool v_msos_send_sms_sts= FALSE;                       // success-0, failure-non zero
	   
	   //Switch transition 00- no action, 01- enable, 10-disable, 11-no action*/
	   static int v_msos_prev_st= BT_DISABLE_MSOS;               //initial state as off
 	
       //API status Signals
       int v_msos_readstatus_ret;                                  // to store the read switch status should be 0 for success
       int rc_wd;                                                            // to store the write digital out api return code 
      
	  // call the read the digital input from the TCU
      v_msos_readstatus_ret = read_digital_in (v_msos_switch_u8, &v_msos_state_u8);
     //chcek the input is read from the switch succesfully  and the state is ENABLE 
	   
    if(BT_SUCCESS == v_msos_readstatus_ret)    //check the read is success 
	{
	 if ((v_msos_prev_st == BT_DISABLE_MSOS) && (v_msos_state_u8== BT_ENABLE_MSOS)) // if switch is closed the state will change from 1 to 0 (din)
	   {	   
 	          v_msos_dout_state_u8 = BT_ON;                                                               // initialise dout state with ON
	          rc_wd=write_digital_out(v_msos_dout1_u8,v_msos_dout_state_u8);       // write the dout state using api
		      printf("MSOS switch is Closed\n");                                                                 //MSOS is ON
	          printf("Dout state is ON and return code is: %d\n",rc_wd);                         //Dout state is ON, LED ON
			  
		      SET_BIT(V_ESOS_MessageByte_u8, BT_MSOS_SWITCH_ON);       //SET_BIT(Val, Mask) Val=Val|Mask 
	          v_msos_send_sms_sts = bt_ccu_SendSMS();               // send sms if switch is on
			 
	          if (TRUE == v_msos_send_sms_sts)                                       // check the bt_ccu_SendSMS api return code is true
 	           {
 	              printf("MSOS sms sent succesfully\n");
	              SET_BIT(V_ESOS_MessageByte_u8, BT_MSOS_ACK_STATUS) ;       //SET_BIT(Val, Mask) Val=Val|Mask 
                   //set the can messsgae with the current state of the MSOS and Aknowledgement status bit 	
	              v_msos_dout_state_u8=BT_OFF;                                                     //reset the dout state to open the switch, LED OFF
 	           } 
	           else
	           {
	           	printf("MSOS sms not sent and status is %d\n",v_msos_send_sms_sts);
	           	SET_BIT(V_ESOS_MessageByte_u8, BT_MSOS_SEND_SMS_ERR);                   //SET_BIT(Val, Mask) Val=Val|Mask 
	           }

 	      }
			
           //when the state is BT_DISABLE_MSOS        
	  else if ((v_msos_prev_st == BT_ENABLE_MSOS) && (v_msos_state_u8== BT_DISABLE_MSOS)) 
		   {
 	            v_msos_dout_state_u8=BT_OFF;                                                           //switch will remain open 
		        rc_wd=write_digital_out(v_msos_dout1_u8,v_msos_dout_state_u8);
 	           	printf("MSOS switch open\n");                                                                  //MSOS is OFF
                printf("Dout state is OFF and return code is: %d\n",rc_wd);                  //Dout state is OFF, LED OFF
		       	CLR_BIT(V_ESOS_MessageByte_u8, BT_MSOS_SWITCH_OFF) ; // clear 0th bit to make ESOS off
		       	CLR_BIT(V_ESOS_MessageByte_u8, BT_CLR_MSOS_ACK) ;         // clear 3rd bit to reset the Ack bit
 	           }
			 
		else 
			 {
				 // do nothing
				 printf("MSOS ON-ON or OFF-OFF state no need to do anything\n");
			 }
		}
			
 	else
	{
		                printf("Manual Emergency SOS switch error: %d\n", v_msos_readstatus_ret );//Fail Safe Mode
 	                    // send the can message as msos_failure_e when switch is failed
                        SET_BIT(V_ESOS_MessageByte_u8, BT_MSOS_SWITCH_ERROR);  //SET_BIT(Val, Mask) Val=Val|Mask 
 	}
    printf("Manual ESOS Message byte  is: %d\n",V_ESOS_MessageByte_u8);	
	v_msos_prev_st = v_msos_state_u8;                 //store the current status in the v_msos_prev_st 
   }
 }

/*------------------------------------Auto ESOS Function Implementaion-------------------------------------------------------*/
/**************************************************************************************************************************
@ code int bt_ccu_AtoEmgcySOS_NonAlgo(void)
@ Brief: This API is used to activate or deactivate the auto emergencySOS and to perform operations specified in the feature
the fature use the IMU sensor data 
@ param: no params
@ return: no ret
***************************************************************************************************************************/
void bt_ccu_AtoEmgcySOS_NonAlgo(void)  //bt_AutoEmergencySOS
{

  printf("Control is here : ");
  if((bt_ccu_GSM_MODEM_STS()==TRUE) && ( bt_ccu_GSM_SET_MSG_STS()==TRUE)&&(bt_ccu_SIM_STS()==TRUE))
	{
    bool v_acc_exceeds=FALSE;                                //signal to store the accelerometer threshold status
    bool v_gyro_exceeds=FALSE;                               //signal to store the gyroscope threshold status
    bool v_asos_send_sms_sts=FALSE;                    //signal to store the send sms return code, 0-success, non zero- failure
    static int v_asos_prev_st=BT_ASOS_OFF;         // signal to store the previous state of ASOS
    static int v_asos_current_st= BT_ASOS_OFF;   // signal to store the current state of ASOS
   
    if((bt_ccu_INIT_ACC_STS()==TRUE) && (bt_ccu_INIT_GYRO_STS()==TRUE))  //check the sensor initialisation status 
	{
	    //check the threshold of accelerometer
        v_acc_exceeds= bt_ccu_IMU_ChkAccThreshold();

       //check the threshold of gyroscope
       v_gyro_exceeds= bt_ccu_IMU_ChkGyroThreshold();
	
      if ((v_acc_exceeds ==TRUE)&& (v_gyro_exceeds==TRUE))   //if both the sensor values reached the threshold 
       {
         v_asos_current_st = BT_ASOS_ON;                                   // store the current status as asos on
         SET_BIT(V_ESOS_MessageByte_u8, BT_ASOS_ON);   //set message ASOS ON
		 
		 
		  if((v_asos_prev_st ==BT_ASOS_OFF) && (v_asos_current_st==BT_ASOS_ON))         // OFF to ON transition
		 {
			 
			 v_asos_send_sms_sts = bt_ccu_SendSMS();             // send sms if both the sensors crosses threshold 
			 
			  if(TRUE == v_asos_send_sms_sts)                                 // check the return code of send sms api if 0-success
             {
                    SET_BIT(V_ESOS_MessageByte_u8, BT_ASOS_ACK_STATUS);   //set message as ACK received 
             }
             else
             {
                   SET_BIT(V_ESOS_MessageByte_u8, BT_ASOS_SEND_SMS_ERR);   //set message as send sms error 
                   printf("ASOS sms not sent and status is %d\n",v_asos_send_sms_sts);
             }		 
			 
		 }
		 
	    else  if((v_asos_prev_st ==BT_ASOS_ON) && (v_asos_current_st==BT_ASOS_ON))    // ON to ON transition
		 {
			 printf("Automatic SOS ON-ON state\n");
		 }   
        
		
	   }
	   else
	   {     
   
         v_asos_current_st = BT_ASOS_OFF;      // store the current state as asos off
		 
        if((v_asos_prev_st ==BT_ASOS_ON) && (v_asos_current_st==BT_ASOS_OFF))        //transition from ON to OFF
		 {
           CLR_BIT(V_ESOS_MessageByte_u8, BT_ASOS_OFF);                                  // if none of the sensor values crosses the threshold set message as ASOS OFF
           CLR_BIT(V_ESOS_MessageByte_u8,BT_CLR_ASOS_ACK);                          // reset the acknowledgement bit 
         }
		else                             //OFF to OFF
		{
			printf("Automatic SOS OFF OFF state\n");
		}
	   }

    }  
else
	{
		SET_BIT(V_ESOS_MessageByte_u8, BT_ASOS_SENSOR_ERROR);            // set message sensor error if there is issue in initialising any sensors
	}
 
	printf("Automatic Emergency SOS Message Byte is: %d\n",V_ESOS_MessageByte_u8);
	v_asos_prev_st= v_asos_current_st;                   // store the current state in v_asos_prev_st 
   }
   }

             
/*************************************************************************************************************
/* this api is used to check the threshold of the accelerometer x and y axis 
@ code static bool bt_ccu_IMU_ChkAccThreshold(void)
@ params : no params
@ ret: boolean, true or false 
**************************************************************************************************************/

bool bt_ccu_IMU_ChkAccThreshold(void)
{
  bool v_acc_thrld_status = FALSE;
  accelerometer_api_priv s_adata = bt_ccu_IMU_GetAccData();
  
  if(((s_adata.x <C_Acc_min_x) || (s_adata.x >C_Acc_max_x))|| ((s_adata.y <C_Acc_min_y) || (s_adata.y >C_Acc_max_y)))
  {
	 v_acc_thrld_status = TRUE;
	 // Accelerometer sensor threshold reached
      printf ("Acc x-axis: %f\t y-axis: %f\t z-axis: %f\n", s_adata.x, s_adata.y, s_adata.z);
  }
 
 return v_acc_thrld_status;
 
}

/*************************************************************************************************************
/* this api is used to check the threshold of the accelerometer x and y axis 
@ code : static bool bt_ccu_IMU_ChkGyroThreshold(void)
@ params : no params
@ ret: boolean, true or false 
**************************************************************************************************************/

bool bt_ccu_IMU_ChkGyroThreshold(void)
{
  bool v_gyro_thrld_status =FALSE;
  gyroscope_api_priv s_gdata = bt_ccu_IMU_GetGyroData();

  if(((s_gdata.x <C_gyro_min_x) || (s_gdata.x >C_gyro_max_x))|| ((s_gdata.y <C_gyro_min_y) || (s_gdata.y> C_gyro_max_y)))
  {
	 v_gyro_thrld_status =TRUE;
	 // Gyroscope sensr threshold reached 
	 printf ("Gyro x-axis: %f\t y-axis: %f\t z-axis: %f\n", s_gdata.x, s_gdata.y, s_gdata.z);
  }
 
 return v_gyro_thrld_status;
 
}

/***************************************************************************************************************************************
@ code int bt_ccu_AtoEmgcySOS(void)
@ Brief: This API is used to activate or deactivate the auto emergencySOS Logic1 if speed is less than 10knph or Logic2 
@ when speed is greater than 10kmph, this fature use the IMU sensor data 
@ param: no params
@ return: no ret
****************************************************************************************************************************************/
void bt_ccu_AtoEmgcySOS(void)
{
	struct bt_ccu_BBS_Rx s_BBS_Rx_d=  bt_ccu_BBS_EXTCT_DATA();
	static bool v_imu_algo_trigger=ASOS_ALGO_OFF;
	static bool v_imu_algo_trigger_prev=ASOS_ALGO_OFF;
	bool v_asos_send_sms_sts=FALSE;
	
	if( s_BBS_Rx_d.BBS_FSpeed< BT_SPEED_TEN_kmph )   
	{
		//when speed is less than 10kmph logic 1 is called to activate the auto emergency sos 
		bt_ccu_AtoEmgcySOS_NonAlgo();
	}
	else
	{
		
	  if((bt_ccu_GSM_MODEM_STS()==TRUE) && ( bt_ccu_GSM_SET_MSG_STS()==TRUE)&&(bt_ccu_SIM_STS()==TRUE))
	  {
		//when speed is greater than 10kmph logic 2 is called to activate the auto emergency sos 
		v_imu_algo_trigger = bt_ccu_AtoEmgcySOS_Algo();
		
		if(  (v_imu_algo_trigger_prev == ASOS_ALGO_OFF) && (v_imu_algo_trigger==ASOS_ALGO_TRIG) )
		{
             SET_BIT(V_ESOS_MessageByte_u8, BT_ASOS_ON);   //set message ASOS ON
			
		     v_asos_send_sms_sts = bt_ccu_SendSMS();    
			 
			 if ( TRUE == v_asos_send_sms_sts )
			 {
				  
                    SET_BIT(V_ESOS_MessageByte_u8, BT_ASOS_ACK_STATUS);   //set message as ACK received 
             }
             else
             {
                   SET_BIT(V_ESOS_MessageByte_u8, BT_ASOS_SEND_SMS_ERR);   //set message as send sms error 
                   printf("ASOS sms not sent and status is %d\n",v_asos_send_sms_sts);
             }	
			 
			 if(  (v_imu_algo_trigger_prev == ASOS_ALGO_TRIG) && (v_imu_algo_trigger==ASOS_ALGO_TRIG) )  // ON to ON transition
		     {
			             printf("Algo Automatic SOS ON-ON state and no operations will be done\n");
		     }   
			 
		}
		else
		{
			if  ( (v_imu_algo_trigger_prev==ASOS_ALGO_TRIG) &&  (v_imu_algo_trigger == ASOS_ALGO_OFF))
			{
			v_imu_algo_trigger = ASOS_ALGO_OFF;
			CLR_BIT(V_ESOS_MessageByte_u8, BT_ASOS_OFF);                                  // if none of the sensor values crosses the threshold set message as ASOS OFF
            CLR_BIT(V_ESOS_MessageByte_u8,BT_CLR_ASOS_ACK);                          // reset the acknowledgement bit 
			}
			else       //OFF to OFF
		   {
			         printf("Algo Automatic SOS OFF OFF stateand no operations will be done \n");
		   }
		}
		
		v_imu_algo_trigger_prev= v_imu_algo_trigger;
		printf("ASOS Algo previous state is : %d\n", v_imu_algo_trigger_prev);
		printf("ASOS Algo current state is : %d\n", v_imu_algo_trigger);
		printf("ASOS Algo Message Byte is: %d\n",V_ESOS_MessageByte_u8);
	  }
    }
  
}
/*************************************************************************************************************
API to return the ESOS message byte status for the can module 
@ code : uint8_t bt_ccu_ESOS_Message_Byte_u8(void)
@ params : no params
@ ret: uint8, 8 bit ESOS message byte 
/**************************************************************************************************************************
@ 0th and 1st bit -  MSOS Switch status   (00-msos off, 01-msos on, 10-msos error,11 - reserved)
@ 2nd bit -- ------    MSOS Acknowledgement  (1-msos ack received, 0-not received)
@ 3rd and 4th bit -  ASOS Status  (00-asos off, 01-asos on, 10-asos error,11 - reserved)
@ 5th bit --              ASOS Acknowledgement  (1-asos ack received, 0-not received)
@ 6th bit --              MSOS Send sms error (1- Err present, 0- no error)
@ 7th bit --              ASOS Send sms error (1- Err present, 0- no error)
/**************************************************************************************************************************/

uint8_t bt_ccu_ESOS_Message_Byte_u8(void)
{
 return V_ESOS_MessageByte_u8;
}


/*************************************************************end of file *************************************************************************/
