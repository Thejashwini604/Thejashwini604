#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <math.h>
#include "bt_ccu_IMUSensors.h"
#include "bt_ccu_calibration.h"
#include "accelerometer.h"
#include "gyroscope.h"
#include "magnetometer.h"
#include "bt_ccu_Threads.h" 

#define G 9.8
#define CALIBRATION_SAMPLES 100
#define SENSOR_RATE_HZ 104
#define SAMPLE_INTERVAL_US (1000000 / SENSOR_RATE_HZ) // Time interval in microseconds
extern int flag;
// Declare calibration offsets and sample count
double acc_x_offset = 0, acc_y_offset = 0, acc_z_offset = 0;
double gyro_x_offset = 0, gyro_y_offset = 0, gyro_z_offset = 0;
double mag_x_offset = 0, mag_y_offset = 0, mag_z_offset = 0;
int samples = 0;


void bt_ccu_IMU_Calibration_Process() {
    //if (samples < CALIBRATION_SAMPLES) {
        
        accelerometer_api_priv S_acc_read = bt_ccu_IMU_GetAccData();
        //bt_ccu_IMU_ProcessAccData(); 
        acc_x_offset += S_acc_read.x/G;
        acc_y_offset += S_acc_read.y/G;
        acc_z_offset += (S_acc_read.z/G - 1);

  
        gyroscope_api_priv S_gyro_read = bt_ccu_IMU_GetGyroData();
        //bt_ccu_IMU_ProcessGyroData(); 
        gyro_x_offset += S_gyro_read.x;
        gyro_y_offset += S_gyro_read.y;
        gyro_z_offset += S_gyro_read.z;

        
        magnetometer_api_priv S_mag_read = bt_ccu_IMU_GetMagData();
        //bt_ccu_IMU_ProcessMagData(); 
        mag_x_offset += S_mag_read.x;
        mag_y_offset += S_mag_read.y;
        mag_z_offset += S_mag_read.z;
        printf("Acc offset PROCESS is before averaging: x=%f, y=%f, z=%f\n", acc_x_offset,acc_y_offset,acc_z_offset);
        
        if (flag)
       {
        acc_x_offset /= CALIBRATION_SAMPLES;
        acc_y_offset /= CALIBRATION_SAMPLES;
        acc_z_offset /= CALIBRATION_SAMPLES;
        
         
  	printf("Acc offset INSIDE FLAG == 1: x=%f, y=%f, z=%f\n", acc_x_offset,acc_y_offset,acc_z_offset);

        gyro_x_offset /= CALIBRATION_SAMPLES;
        gyro_y_offset /= CALIBRATION_SAMPLES;
        gyro_z_offset /= CALIBRATION_SAMPLES;

        mag_x_offset /= CALIBRATION_SAMPLES;
        mag_y_offset /= CALIBRATION_SAMPLES;
        mag_z_offset /= CALIBRATION_SAMPLES;
       }
}



