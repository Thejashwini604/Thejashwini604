#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <math.h>
#include "bt_ccu_IMUSensors.h"
#include "bt_ccu_AtoEmgcySOS_Algo.h"
#include "bt_ccu_calibration.h"
#include "gyroscope.h"
#include "accelerometer.h"
#include "magnetometer.h"
#include "bt_ccu_Threads.h" 


#define G 9.8 // Gravitational constant
#define CALIBRATION_SAMPLES 100 // Number of samples to calibrate
#define ACC_ALPHA 0.9 // Alpha for accelerometer low-pass filter
#define GYRO_ALPHA 0.01 // Alpha for gyroscope low-pass filter
#define DT 0.01 // Time step (seconds)
#define ACC_THRESHOLD 0.5
#define ANG_VEL_THRESHOLD 2.0

/*******************************Global Variables of IMU sensors****************/
accelerometer_api_priv S_acc_read;
gyroscope_api_priv S_gyro_read;
magnetometer_api_priv S_mag_read;
extern double acc_x_offset;
extern double acc_y_offset;
extern double acc_z_offset;
extern double gyro_x_offset;
extern double gyro_y_offset;
extern double gyro_z_offset;
extern double mag_x_offset;
extern double mag_y_offset;
extern double mag_z_offset;
extern int flag;

double accel_x_filtered = 0.0, accel_y_filtered = 0.0, accel_z_filtered = 0.0;
double gyro_x_filtered = 0.0, gyro_y_filtered = 0.0, gyro_z_filtered = 0.0;

double roll_acc = 0.0, pitch_acc = 0.0;
double roll_acc_1 = 0.0, pitch_acc_1 = 0.0;
double roll_acc_2 = 0.0;

double accel_norm_actual = 0.0;
double gyro_norm_actual = 0.0;
double accel_norm_raw = 0.0;
double gyro_norm_raw = 0.0;

bool trigger = FALSE;
/***********Accelerometer Calibration*********************/

/*********** Main Initialization and Calibration Function *********************/
void subtractOffset(void)
{ 
 accelerometer_api_priv S_acc_read = bt_ccu_IMU_GetAccData();
 gyroscope_api_priv S_gyro_read = bt_ccu_IMU_GetGyroData();
 
  printf("Acc offset is before averaging: x=%f, y=%f, z=%f\n", acc_x_offset,acc_y_offset,acc_z_offset);
 

 accel_x_filtered = (S_acc_read.x/G) - acc_x_offset; 
 accel_y_filtered = (S_acc_read.y/G) - acc_y_offset;
 accel_z_filtered = (S_acc_read.z/G) - acc_z_offset;
 
 gyro_x_filtered = S_gyro_read.x - gyro_x_offset;
 gyro_y_filtered = S_gyro_read.y - gyro_y_offset;
 gyro_z_filtered = S_gyro_read.z - gyro_z_offset;
 
}

void calculate_filtered_orientation_and_pitch_roll(void) {
 
 static double prev_accel_x = 0, prev_accel_y = 0, prev_accel_z = 0;
 static double prev_gyro_x = 0, prev_gyro_y = 0, prev_gyro_z = 0;
 accelerometer_api_priv S_acc_read = bt_ccu_IMU_GetAccData();
 gyroscope_api_priv S_gyro_read = bt_ccu_IMU_GetGyroData();

 // Read data from sensors
 // Apply low-pass filter to accelerometer data
 accel_x_filtered = (ACC_ALPHA * prev_accel_x + (1 - ACC_ALPHA) * accel_x_filtered);
 accel_y_filtered = (ACC_ALPHA * prev_accel_y + (1 - ACC_ALPHA) * accel_y_filtered);
 accel_z_filtered = (ACC_ALPHA * prev_accel_z + (1 - ACC_ALPHA) * accel_z_filtered); 

 // Store filtered values for the next iteration
 prev_accel_x = accel_x_filtered;
 prev_accel_y = accel_y_filtered;
 prev_accel_z = accel_z_filtered;
 printf("Acc offset is: x=%f, y=%f, z=%f\n", acc_x_offset,acc_y_offset,acc_z_offset);
 printf("Gyro offset is: x=%f, y=%f, z=%f\n", gyro_x_offset,gyro_y_offset,gyro_z_offset);
 printf("Gyro filtered is: x=%f, y=%f, z=%f\n", gyro_x_filtered,gyro_y_filtered,gyro_z_filtered);
 

 roll_acc = atan2(accel_z_filtered, accel_y_filtered);
 roll_acc_1 = atan2((S_acc_read.z/G ), (S_acc_read.y/G ));
 roll_acc_2 = atan((S_acc_read.y/G - acc_y_offset)/(S_acc_read.z/G - acc_z_offset));
 pitch_acc = atan((-accel_x_filtered)/ (sqrt((accel_y_filtered * accel_y_filtered) + (accel_z_filtered * accel_z_filtered))));
 pitch_acc_1 = atan(-(S_gyro_read.x)/ (sqrt((S_gyro_read.y * S_gyro_read.y) + (S_gyro_read.z * S_gyro_read.z))));

 printf("Filtered Roll (Acc): %f, Filtered Pitch (Acc): %f\n", (roll_acc) * (180/M_PI), (pitch_acc) * (180/M_PI));
 printf("\n");
 printf("Filtered Roll (Acc___1): %f, Filtered Pitch (Acc___1): %f\n", (roll_acc_1) * (180/M_PI), (pitch_acc_1) * (180/M_PI));
 printf("\n");
 printf("Filtered Roll (Acc___2): %f\n", (roll_acc_2) * (180/M_PI));
 printf("\n");
}

/**************************************************************************************************************************
@ code bool bt_ccu_AtoEmgcySOS_Algo(void)
@ Brief: This API is used to activate or deactivate the auto emergencySOS usig the norm formulae algorithm
this feature use the IMU sensor data 
@ param: no params
@ return: no ret
***************************************************************************************************************************/
bool bt_ccu_AtoEmgcySOS_Algo(void)
{
	subtractOffset();
	accelerometer_api_priv S_acc_read = bt_ccu_IMU_GetAccData();
        gyroscope_api_priv S_gyro_read = bt_ccu_IMU_GetGyroData();

	calculate_filtered_orientation_and_pitch_roll();
	
	accel_norm_actual = sqrt((accel_x_filtered * accel_x_filtered) + (accel_y_filtered * accel_y_filtered) + (accel_z_filtered * accel_z_filtered)); 
	accel_norm_raw = sqrt(((S_acc_read.x/G * S_acc_read.x/G) + (S_acc_read.y/G * S_acc_read.y/G) + (S_acc_read.z/G * S_acc_read.z/G)));
	/*accel_norm_actual = sqrt(((S_acc_read.x - acc_x_offset)/G * (S_acc_read.x - acc_x_offset)/G) + ((S_acc_read.y - acc_y_offset)/G * (S_acc_read.y - acc_y_offset)/G) + ((S_acc_read.z - acc_z_offset)/G * (S_acc_read.z - acc_z_offset)/G));*/
	gyro_norm_actual = sqrt((gyro_x_filtered * gyro_x_filtered) + (gyro_y_filtered * gyro_y_filtered) + (gyro_z_filtered * gyro_z_filtered));
	gyro_norm_raw = sqrt((S_gyro_read.x * S_gyro_read.x) + (S_gyro_read.y * S_gyro_read.y) + (S_gyro_read.z * S_gyro_read.z));
	/*gyro_norm_actual = sqrt(((S_gyro_r.x - gyro_x_offset) * (S_gyro_r.x - gyro_x_offset)) + ((S_gyro_r.y - gyro_y_offset) * (S_gyro_r.y - gyro_y_offset)) + ((S_gyro_r.z - gyro_z_offset) * (S_gyro_r.z - gyro_z_offset))); */
	printf("Raw Norm Acc: %f\n",accel_norm_raw);
	printf("Raw Norm Gyro: %f\n",gyro_norm_raw);
	if((accel_norm_actual) < ACC_THRESHOLD || gyro_norm_actual > ANG_VEL_THRESHOLD)
   {
     printf("****************Fall Detected***************:  ACC_Norm = %f, GYRO_NORM = %f\n",(accel_norm_actual), gyro_norm_actual);
     trigger = TRUE;
   }
   else
   {
     printf("**************Safe******************: ACC_Norm = %f, GYRO_NORM = %f\n",(accel_norm_actual), gyro_norm_actual);
     trigger = FALSE;
   }
   return trigger;
}


