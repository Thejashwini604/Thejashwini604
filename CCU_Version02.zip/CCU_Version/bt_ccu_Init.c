#include <stdint.h>
#include "bt_ccu_CANRx.h"
#include "bt_ccu_Init.h"
#include "bt_ccu_Pheripherals.h"
#include "bt_ccu_CANTx.h"
#include "bt_ccu_ESOS.h"
#include "bt_ccu_MQTT.h"
#include "Std_generalmacros.h"

// Global initialization flags for various subsystems
// These flags will hold the status (TRUE or FALSE) of each system's initialization.
bool V_ccu_init_bat = FALSE;         // Battery initialization status
bool V_ccu_init_acc = FALSE;         // Accelerometer initialization status
bool V_ccu_init_gyro = FALSE;        // Gyroscope initialization status
bool V_ccu_init_can = FALSE;         // CAN communication initialization status
bool V_ccu_init_wifi = FALSE;        // WIFI initialization status
bool V_ccu_init_ble = FALSE;         // BLE initialization status
bool V_ccu_init_sts = FALSE;         // Set the CCU Initialisation to FALSE
bool bt_ccu_mag_sts = FALSE;

/**
 * Function to initialize and configure various subsystems and hardware.
 * This function initializes multiple subsystems such as Battery, GSM modem, GPS, 
 * Accelerometer, Gyroscope, Magnetometer, CAN, WIFI, BLE, and Ignition.
 */
void bt_ccu_INIT(void)
{
    int v_ccu_int_rc;
    char v_ccu_can_name[] = "can0";           // CAN bus name (can be changed based on the requirement)
    int v_ccu_can_bitrate = 500000;           // Bitrate for CAN (can be adjusted as needed)
    int v_ccu_wifi_mode = 0;                  // Mode for wifi initialization 1 --> hostapd mode , 0 --> station mode
        
    // Initialize the system (some initialization method for overall setup)
    v_ccu_int_rc = init(1);
       // Set the global flag based on the result of CCU initialization
    V_ccu_init_sts = (v_ccu_int_rc == 0) ? TRUE : FALSE; // CCU initialisation is successful or not
    printf("initialization %s. Status: %d\n", V_ccu_init_sts ? "successful" : "failed", v_ccu_int_rc);       

    // Initialize Accelerometer
    v_ccu_int_rc = acc_init();
    // Set the global flag based on the result of Accelerometer initialization
    V_ccu_init_acc = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("Accelerometer initialization %s. Status: %d\n", V_ccu_init_acc ? "successful" : "failed", v_ccu_int_rc);
    
    
    v_ccu_int_rc = set_acc_sampling_frequency(0x40);
    printf("Accelerometer Sampling Frequency : %d\n",v_ccu_int_rc);
    
    // Initialize Gyroscope
    v_ccu_int_rc = gyro_init();
    // Set the global flag based on the result of Gyroscope initialization
    V_ccu_init_gyro = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("Gyroscope initialization %s. Status: %d\n", V_ccu_init_gyro ? "successful" : "failed", v_ccu_int_rc);
    
       
    v_ccu_int_rc = set_gyro_sampling_frequency (0x40);
    printf("Gyroscope Sampling Frequency : %d\n",v_ccu_int_rc);
    
    // Initialize CAN communication
    v_ccu_int_rc = can_init(v_ccu_can_name, v_ccu_can_bitrate);  // Initialize CAN bus with specified name and bitrate
    // Set the global flag based on the result of CAN initialization
    V_ccu_init_can = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("CAN initialization %s. Status: %d\n", V_ccu_init_can ? "successful" : "failed", v_ccu_int_rc);

    // Initialize WIFI
    v_ccu_int_rc = wifi_init(v_ccu_wifi_mode);
    // Set the global flag based on the result of WIFI initialization
    V_ccu_init_wifi = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("WIFI initialization %s. Status: %d\n", V_ccu_init_wifi ? "successful" : "failed", v_ccu_int_rc);

    // Initialize BLE (Bluetooth Low Energy)
    v_ccu_int_rc = ble_init();
    // Set the global flag based on the result of BLE initialization
    V_ccu_init_ble = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("BLE initialization %s. Status: %d\n", V_ccu_init_ble ? "successful" : "failed", v_ccu_int_rc);
           
    v_ccu_int_rc = ign_pin_status_check_enable();  // Enable Ignition PIN status check
    printf("IgnPin status Check enable value is %d:\n", v_ccu_int_rc);

     bt_ccu_RESET_ECU_Rx();  // Reset ECU data structure
    
     bt_ccu_RESET_BBS_Rx();  // Reset BBS data structure
     
     // This function likely prepares the internal data structure required for MQTT communication.
     bt_ccu_mqtt_STRUCT_INTL();
}

/**
 * Function to get the CCU initialization status.
 * This function returns the global flag for CCU initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_STS(void) { 
    return V_ccu_init_sts; 
}
/**
 * Function to get the CAN initialization status.
 * This function returns the global flag for CAN initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_CAN_STS(void) { 
    return V_ccu_init_can; 
}

/**
 * Function to get the WIFI initialization status.
 * This function returns the global flag for WIFI initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_WIFI_STS(void) { 
    return V_ccu_init_wifi; 
}

/**
 * Function to get the BLE initialization status.
 * This function returns the global flag for BLE initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_BLE_STS(void) { 
    return V_ccu_init_ble; 
}


/**
 * Function to get the Accelerometer initialization status.
 * This function returns the global flag for Accelerometer initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_ACC_STS(void) { 
    return V_ccu_init_acc; 
}

/**
 * Function to get the Gyroscope initialization status.
 * This function returns the global flag for Gyroscope initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_GYRO_STS(void) { 
    return V_ccu_init_gyro; 
}

/**
 * @code
 *  bt_ccu_INIT_MAG_STS(void)
 * @endcode
 * @brief This function initializes the magnetometer sensor for magnetic field detection.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function prepares the magnetometer sensor for detecting magnetic fields and orientation.
 */
bool bt_ccu_INIT_MAG_STS(void)
{

	return bt_ccu_mag_sts;
}
/**
 * @code
 *  bt_ccu_BAT_INIT_STS(void)
 * @endcode
 * @brief This function returns Battery Status.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 */
bool bt_ccu_BAT_INIT_STS(void)
{
        return V_ccu_init_bat;
}


