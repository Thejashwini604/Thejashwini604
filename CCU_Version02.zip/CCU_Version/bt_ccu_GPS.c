
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <termios.h>
#include <signal.h>
#include <stdint.h>
#include <linux/netlink.h>
#include <linux/if_link.h>
#include <linux/input.h>
#include <linux/rtnetlink.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>
#include "gsm.h"
#include <can.h>
#include "gyroscope.h"
#include "accelerometer.h"
#include "error_nos.h"
#include "magnetometer.h"
#include "battery.h"
#include <time.h>
#include "bt_ccu_CANRx.h"
#include "bt_ccu_Init.h"
#include "bt_ccu_Pheripherals.h"
#include "bt_ccu_CANTx.h"
#include "Std_generalmacros.h"
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/
 /******************************************************************************/
/*-------------------------Global Variables--------------------------------*/
/******************************************************************************/
// Define the bt_GPS_Read macro with a value of FALSE (indicating that GPS read is currently not active or successful)
bool bt_ccu_GPS_Read = FALSE;

bool bt_ccu_GET_GPS_Valid = FALSE;

// Global variables to store extracted GPS data
char bt_ccu_RECV_DATA[200] = {0};  // Buffer to hold GPS data

char gps_status[2] = "";  // Array to store the status of the GPS (e.g., "ACTIVE", "INACTIVE", etc.)
double gps_lat_decimal = 0.0;  // Variable to store the GPS latitude in decimal format (e.g., 37.7749)
char gps_lat_hemisphere = '\0';  // Variable to store the hemisphere of the latitude (e.g., 'N' for North, 'S' for South)
double gps_lon_decimal = 0.0; //Variable to store the GPS longitude in decimal format (e.g., -122.4194)
char gps_lon_hemisphere = '\0';  // Variable to store the hemisphere of the longitude (e.g., 'E' for East, 'W' for West)

 /******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/
void bt_ccu_reset_gps_data(void);
/**
 * Extract GPRMC data from received NMEA data
 * 
 * This function extracts relevant GPRMC data (a type of NMEA sentence) from the received
 * GPS data. The exact data extracted would depend on the specific implementation of this function.
 * 
 * @param recv_data - A pointer to the received data from the GPS module.
 * 
 * @note GPRMC (Recommended Minimum Specific GPS/Transit Data) is a standard sentence used in NMEA.
 */
void bt_ccu_EXRT_GPRMC_DATA(char *bt_ccu_RECV_DATA);
/**
 * Convert DMS (Degrees, Minutes, Seconds) format to Decimal format
 * 
 * This function converts geographic coordinates from DMS (Degrees, Minutes, Seconds)
 * format into Decimal format. It takes degrees, minutes, and seconds, along with a
 * hemisphere identifier (N/S or E/W) to calculate the corresponding decimal value.
 * 
 * @param degrees   - The degrees part of the DMS coordinate.
 * @param minutes   - The minutes part of the DMS coordinate.
 * @param seconds   - The seconds part of the DMS coordinate.
 * @param hemisphere - The hemisphere ('N', 'S', 'E', 'W') of the coordinate.
 * 
 * @return The corresponding decimal value of the coordinate.
 */
double dms_to_decimal(double degrees, double minutes, double seconds, char hemisphere); 
 
/**
 * Function to process the GPS data
 * 
 * This function is responsible for processing GPS data. The exact details of
 * the processing would depend on the specific implementation of this function,
 * which is not shown in this header file. This could involve parsing NMEA sentences,
 * validating data, and updating internal states or buffers.
 */
void bt_ccu_GPS_PRCS(void) {
    size_t len = 0;  // Length of received GPS data
    int gps_rc = 0;
    
    // Check if the GSM modem is initialized successfully
    if(bt_ccu_GSM_MODEM_STS() == TRUE) 
    {
            // Infinite loop to keep reading GPS data
                memset(bt_ccu_RECV_DATA, 0, sizeof(bt_ccu_RECV_DATA));  // Clear the receive data buffer to ensure no old data is left

                // Label to retry reading GPS data if an error occurs
                gps_rc = get_gps_data("GPRMC", &len, bt_ccu_RECV_DATA, sizeof(bt_ccu_RECV_DATA));  // Retrieve GPS data (GPRMC sentence)
             
                if(gps_rc == 0)
                {
                      bt_ccu_GPS_Read = TRUE;
                
                      // Print the length of the received GPS data and the actual content
                      printf("get_gps_data len value %d\n", len);
                      printf("get_gps_data recv_data value %s\n", bt_ccu_RECV_DATA);
                      printf("get_gps_data Successful: %d\n", gps_rc);
     
                      // Call the function to extract and display GPS information from the GPRMC sentence
                      bt_ccu_EXRT_GPRMC_DATA(bt_ccu_RECV_DATA);  // Process the GPRMC sentence (which contains GPS data like location, time, etc.)
                }   
                else
                {
                
                   bt_ccu_GPS_Read = FALSE;
                   
                   bt_ccu_GET_GPS_Valid = FALSE;
                   
                   printf("GPS Read is Failed : %d:\n",gps_rc);
                   bt_ccu_reset_gps_data();
                
                }   
    } 
    else 
    {
        bt_ccu_GPS_Read = FALSE;
        
        bt_ccu_GET_GPS_Valid = FALSE;
        
        // If GSM modem failed, print an error message
        printf("GSM Modem failed : ");
        bt_ccu_reset_gps_data();
    }
}
// Function to convert DMS (degrees, minutes, seconds) to decimal degrees
double dms_to_decimal(double degrees, double minutes, double seconds, char hemisphere) 
{
    double decimal_degrees = degrees + (minutes / 60) + (seconds / 3600);
    if (hemisphere == 'S' || hemisphere == 'W') 
    {
        decimal_degrees = -decimal_degrees;  // For southern or western hemisphere, make the value negative
    }
    return decimal_degrees;
}
/**
 * Extract GPRMC data from received NMEA data
 * 
 * This function extracts relevant GPRMC data (a type of NMEA sentence) from the received
 * GPS data. The exact data extracted would depend on the specific implementation of this function.
 * 
 * @param recv_data - A pointer to the received data from the GPS module.
 * 
 * @note GPRMC (Recommended Minimum Specific GPS/Transit Data) is a standard sentence used in NMEA.
 */
// Function to process GPRMC data
void bt_ccu_EXRT_GPRMC_DATA(char *bt_ccu_RECV_DATA) 
{
    char *token;
    double lat_deg, lat_min, lat_sec, lon_deg, lon_min, lon_sec;
    char *utc_time, *status, *latitude, *lat_hemisphere, *longitude, *long_hemisphere, *speed, *course, *date, *checksum;

    // Tokenize the received data using ',' as the delimiter
    token = strtok(bt_ccu_RECV_DATA, ",");
    if (token == NULL || strcmp(token, "$GPRMC") == 0) 
    {
        printf("Invalid GPRMC sentence\n");
        bt_ccu_reset_gps_data();
    } 
    else 
    {
        // Extract fields one by one
        utc_time = strtok(NULL, ",");
        status = strtok(NULL, ",");
        latitude = strtok(NULL, ",");
        lat_hemisphere = strtok(NULL, ",");
        longitude = strtok(NULL, ",");
        long_hemisphere = strtok(NULL, ",");
        speed = strtok(NULL, ",");
        course = strtok(NULL, ",");
        date = strtok(NULL, ",");
        checksum = strtok(NULL, "*");

        // Handle missing or invalid status
        if (!status) 
        {
            printf("Missing GPS status\n");
            
        } 
        else 
        {
            // Update the global GPS status variable
            strncpy(gps_status, status, sizeof(gps_status) - 1);
            gps_status[sizeof(gps_status) - 1] = '\0'; // Null-terminate the string

            // Check if the GPS data is invalid
            if (*status == 'V' || !latitude || !lat_hemisphere || !longitude || !long_hemisphere) 
            {
                printf("Missing critical GPS data or invalid status\n");
                
                bt_ccu_reset_gps_data();
                
                // Output the results
                printf("Status: %s\n", gps_status);
                printf("Latitude: %.6lf %c\n", gps_lat_decimal, gps_lat_hemisphere);
                printf("Longitude: %.6lf %c\n", gps_lon_decimal, gps_lon_hemisphere);                
            } 
            else 
            {
                // Parse and convert latitude
                sscanf(latitude, "%2lf%lf", &lat_deg, &lat_min);
                lat_sec = lat_min - (int)lat_min;

                // Parse and convert longitude
                sscanf(longitude, "%3lf%lf", &lon_deg, &lon_min);
                lon_sec = lon_min - (int)lon_min;

                // Convert to decimal degrees
                gps_lat_decimal = dms_to_decimal(lat_deg, lat_min, lat_sec, lat_hemisphere[0]);
                gps_lon_decimal = dms_to_decimal(lon_deg, lon_min, lon_sec, long_hemisphere[0]);

                // Update global variables
                gps_lat_hemisphere = lat_hemisphere[0];
                gps_lon_hemisphere = long_hemisphere[0];
                bt_ccu_GET_GPS_Valid = TRUE; // Mark as valid

                // Output the results
                printf("Status: %s\n", gps_status);
                printf("Latitude: %.6lf %c\n", gps_lat_decimal, gps_lat_hemisphere);
                printf("Longitude: %.6lf %c\n", gps_lon_decimal, gps_lon_hemisphere);
            }
        }
    }
}

/**
 * Set the Get GPS Data flag to TRUE
 * 
 * This function is responsible for returning TRUE to indicate that the GPS data 
 * should be retrieved or that the flag for GPS data collection is set to active.
 * 
 * @return TRUE - indicating that GPS data collection is enabled.
 */
bool bt_ccu_GPS_READ(void) 
{ 
    return bt_ccu_GPS_Read;  // Return TRUE to signify that GPS data should be retrieved.
}

// Function to return a pointer to the gps_status array
// This function returns the address of the global gps_status array, 
// which can be used to access its content in other parts of the program.
bool bt_ccu_GET_GPS_STS(void) 
{
    return bt_ccu_GET_GPS_Valid;  // Return the pointer to the gps_status array
}

// Function to return a copy of the gps_lat_decimal variable
// This function returns the current value of the global variable gps_lat_decimal.
// The value is returned by value, so the original variable is not affected by the call.
double bt_ccu_GET_GPS_LAT_DEC(void) 
{
    return gps_lat_decimal;  // Return the value of gps_lat_decimal (by value)
}

// Function to return a copy of the gps_lon_decimal variable
// This function returns the current value of the global variable gps_lon_decimal.
// Similar to the previous function, the value is returned by value, 
// so the original variable is not modified by the function call.
double bt_CCU_GET_GPS_LON_DEC(void) 
{
    return gps_lon_decimal;  // Return the value of gps_lon_decimal (by value)
}

void bt_ccu_reset_gps_data(void)
{
	// Reset GPS data to 0 and set status to 'V'
	gps_lat_decimal = 0.0;
	gps_lon_decimal = 0.0;
	strncpy(gps_status, "V", sizeof(gps_status) - 1);
}
