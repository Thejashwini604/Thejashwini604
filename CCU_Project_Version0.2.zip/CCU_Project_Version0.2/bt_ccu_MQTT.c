/**************************************************************************************************************************/
/*----------------------------------------------Includes------------------------------------------------------------------*/
/**************************************************************************************************************************/
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include "bt_ccu_CANRx.h"
#include "bt_ccu_CANTx.h"
#include "bt_ccu_CellularModem.h"
#include "bt_ccu_ESOS.h"
#include "bt_ccu_GPS.h"
#include "bt_ccu_IMUSensors.h"
#include "bt_ccu_Init.h"
#include "bt_ccu_MQTT.h"
#include "bt_ccu_Pheripherals.h"
/******************************************************************************************************************************/
//***********************Local Decleration Part*******************************************************************************/

//created structure for assigning bbs/ecu values into bt_ccu_bbs_data/bt_ccu_ecu_data from bt_ccu_BBS_EXTCT_DATA()/bt_ccu_ECU_EXTCT_DATA()
struct bt_ccu_BBS_Rx bt_ccu_bbs_data;
struct bt_ccu_ECU_Rx bt_ccu_ecu_data;

/******************************************************************************************************************************/

/******************************************************************************************************************************/
//***********************************************Local function Decleration****************************************************/
void bt_ccu_mqtt_bbs_ecu_data(void);
void bt_ccu_mqtt_ReadSignalData_GPS(GPS_SignalData *GPS_Data);
/******************************************************************************************************************************/


/******************************************************************************************************************************/
//*****************************************local struct declaration for gps/rest data*****************************************/

GPS_SignalData GPS_Data;         // for gps data
Device_SignalData data; 	// for device signal data

/******************************************************************************************************************************/


/*********************************************************************************************************************************/
/***************************************** functions*************************************************************************/
void bt_ccu_mqtt_bbs_ecu_data(void)
{
	bt_ccu_bbs_data = bt_ccu_BBS_EXTCT_DATA();// Rx BBS Structure from BBS_Rx Component
	bt_ccu_ecu_data = bt_ccu_ECU_EXTCT_DATA();// Rx BBS Structure from BBS_Rx Component
	
}

/****************************************Reset strcture to 0 ***********************************************************************/
void bt_ccu_mqtt_STRUCT_INTL(void)
{
	//initialize entire structure to 0 //device signal data/ gps data / ecu/bbs data
	data.bt_acc_data.x=0;
	data.bt_gyro_data.y=0;
	data.bt_gyro_data.z=0;
        data.bt_mag_data.x=0;
        data.bt_mag_data.y=0; 
        data.bt_mag_data.z=0;
        data.IMU_A_Init_Status=0; 
        data.IMU_G_Init_Status=0;
        data.IMU_M_Init_Status=0;
        data.Internal_Battery_Status=0;
        data.Source_Voltage=0;
        data.Wifi_Status=0;
        data.BT_Status=0;
        data.Cellular_Status=0;
        data.SIM_Active=0; 
        data.GSM_NW=0;
        data.Ignition_Status=0;
        data.CANRx_Status_BBS=0; 
        data.CANRx_Status_ECU=0; 
        data.CANTx_Status_CCU=0;
        data.SOS_Status=0;
        
        GPS_Data.GPS_Status_Init=0; 
        GPS_Data.GPS_Status_Read=0; 
        GPS_Data.GPS_Status_Data_Validity=0;
        //memset(GPS_Data.GPS_Status_Data_Validity, 0, sizeof(GPS_Data.GPS_Status_Data_Validity));
        GPS_Data.GPS_Lat=0;
        GPS_Data.GPS_Long=0;
        
        bt_ccu_bbs_data.BBS_ExvlM_NA_ERR=0;
        bt_ccu_bbs_data.BBS_FSpeedSTAT=0; 
        bt_ccu_bbs_data.BBS_FSpeed=0;
        bt_ccu_bbs_data.BBS_RSpeedSTAT=0; 
        bt_ccu_bbs_data.BBS_ExvlCheck=0; 
        bt_ccu_bbs_data.BBS_RSpeed=0;
        bt_ccu_bbs_data.BBS_DWCLevACK=0; 
        bt_ccu_bbs_data.BBS_DTC_STAT=0; 
        bt_ccu_bbs_data.BBS_DTCLevACK=0;
        bt_ccu_bbs_data.BBS_DSC_STAT=0; 
        bt_ccu_bbs_data.BBS_DSCLevACK=0; 
        bt_ccu_bbs_data.BBS_DWC_STAT=0;
        bt_ccu_bbs_data.BBS_Data01_CNT=0; 
        bt_ccu_bbs_data.BBS_ExvlPot_ERR2=0; 
        bt_ccu_bbs_data.BBS_ExvlPot_ERR1=0;
        bt_ccu_bbs_data.BBS_DAVC_STAT=0; 
        bt_ccu_bbs_data.BBS_Data01_CRC=0;
        
        bt_ccu_ecu_data.ECU_APS=0; 
        bt_ccu_ecu_data.ECU_EngSTAT=0; 
        bt_ccu_ecu_data.ECU_DOWNshift=0;
        bt_ccu_ecu_data.ECU_CCswitchERR=0; 
        bt_ccu_ecu_data.ECU_UPshift=0; 
        bt_ccu_ecu_data.ECU_ApsERR=0;
        bt_ccu_ecu_data.ECU_CCswitch=0; 
        bt_ccu_ecu_data.ECU_RPM_ERR=0; 
        bt_ccu_ecu_data.ECU_RPM=0;
        bt_ccu_ecu_data.ECU_BrakeERR=0; 
        bt_ccu_ecu_data.ECU_GearStb=0; 
        bt_ccu_ecu_data.ECU_GearSet=0;
        bt_ccu_ecu_data.ECU_GearERR=0; 
        bt_ccu_ecu_data.ECU_Gear=0; 
        bt_ccu_ecu_data.ECU_SideStandERR=0;
        bt_ccu_ecu_data.ECU_BikeModel=0; 
        bt_ccu_ecu_data.ECU_SideStand=0; 
        bt_ccu_ecu_data.ECU_R_Brake=0;
        bt_ccu_ecu_data.ECU_F_Brake=0; 
        bt_ccu_ecu_data.ECU_Data01_CNT=0; 
        bt_ccu_ecu_data.ECU_RLlambdaSTAT=0;
        bt_ccu_ecu_data.ECU_FLlambdaSTAT=0; 
        bt_ccu_ecu_data.ECU_ClutchSTAT=0; 
        bt_ccu_ecu_data.ECU_Data01_CRC=0;
	 
}
/******************************************************************************************************************************/





/*********************************************************************************************************************************/
void bt_ccu_mqtt_ReadSignalData(Device_SignalData *data) {

    //IMU SensorData
    data->bt_acc_data=bt_ccu_IMU_GetAccData();
    data->bt_gyro_data=bt_ccu_IMU_GetGyroData();
    data->bt_mag_data=bt_ccu_IMU_GetMagData();

    // Initialize IMU status
    data->IMU_A_Init_Status = bt_ccu_INIT_ACC_STS();
    data->IMU_G_Init_Status = bt_ccu_INIT_GYRO_STS();
    data->IMU_M_Init_Status = bt_ccu_INIT_MAG_STS();
    
    // Initialize Battery Voltage
    //data->Internal_Battery_Voltage = 0.0f;
    data->Internal_Battery_Status = bt_ccu_INIT_BAT_STS();
    data->Source_Voltage = bt_ccu_ADC_SRC_V();

    // Initialize Wi-Fi, Bluetooth, and Cellular status
    data->Wifi_Status = bt_ccu_INIT_WIFI_STS();
    data->BT_Status = bt_ccu_INIT_BLE_STS();
    data->Cellular_Status = bt_ccu_INIT_GSM_STS();
    data->SIM_Active = bt_ccu_SIM_STS();
    data->GSM_NW = 0;

    //  Ignition status
    data->Ignition_Status = bt_ccu_IGN_STS();

    // Initialize CAN RX/TX Status
    data->CANRx_Status_BBS = bt_ccu_RX_BBSREADSTS();
    data->CANRx_Status_ECU = bt_ccu_RX_ECUREADSTS();
    data->CANTx_Status_CCU = bt_ccu_CANTX_STS();

    // Initialize SOS Status
    data->SOS_Status = bt_ccu_ESOS_Message_Byte_u8();
   
}



void bt_ccu_mqtt_ReadSignalData_GPS(GPS_SignalData *GPS_Data)
{

   // Initialize GPS init/read/data validity/lat &lon data
    GPS_Data->GPS_Status_Init = bt_ccu_INIT_GPS_STS();
    GPS_Data->GPS_Status_Read = bt_ccu_GPS_READ();
    //memcpy(GPS_Data->GPS_Status_Data_Validity, bt_ccu_GET_GPS_STS(), sizeof(GPS_Data->GPS_Status_Data_Validity));
    GPS_Data->GPS_Status_Data_Validity=bt_ccu_GET_GPS_STS();
    GPS_Data->GPS_Lat = bt_ccu_GET_GPS_LAT_DEC();
    GPS_Data->GPS_Long = bt_CCU_GET_GPS_LON_DEC();

}

/********************************************************JSON FORMAT***********************************************************************/
// JSON formatting function for Device signal data
void format_json(const Device_SignalData *data, struct bt_ccu_BBS_Rx *BBS_Data, struct bt_ccu_ECU_Rx *ECU_Data, char *main_json) {
    sprintf(main_json,
        "{"
        "\"IMU_A_x\": %lf, \"IMU_A_y\": %lf, \"IMU_A_z\": %lf, "
        "\"IMU_G_x\": %lf, \"IMU_G_y\": %lf, \"IMU_G_z\": %lf, "
        "\"IMU_M_x\": %lf, \"IMU_M_y\": %lf, \"IMU_M_z\": %lf, "
        "\"IMU_A_Init_Status\": %d, \"IMU_G_Init_Status\": %d, \"IMU_M_Init_Status\": %d, "
        "\"Internal_Battery_Status\": %d, "
        "\"External_Battery_Voltage\": %.2f, "
        "\"Wifi_Status\": %d, \"BT_Status\": %d, \"Cellular_Status\": %d, "
        "\"SIM_Active\": %d, \"GSM_NW\": %d, "
        "\"Ignition_Status\": %d, "
        "\"CANRx_Status_BBS\": %d, \"CANRx_Status_ECU\": %d, \"CANTx_Status_CCU\": %d, "
        "\"SOS_Status\": %d, "
        "\"BBS_ExvlM_NA_ERR\": %d, \"BBS_FSpeedSTAT\": %d, \"BBS_FSpeed\": %d, "
        "\"BBS_RSpeedSTAT\": %d, \"BBS_ExvlCheck\": %d, \"BBS_RSpeed\": %d, "
        "\"BBS_DWCLevACK\": %d, \"BBS_DTC_STAT\": %d, \"BBS_DTCLevACK\": %d, "
        "\"BBS_DSC_STAT\": %d, \"BBS_DSCLevACK\": %d, \"BBS_DWC_STAT\": %d, "
        "\"BBS_Data01_CNT\": %d, \"BBS_ExvlPot_ERR2\": %d, \"BBS_ExvlPot_ERR1\": %d, "
        "\"BBS_DAVC_STAT\": %d, \"BBS_Data01_CRC\": %d, "
        "\"ECU_APS\": %d, \"ECU_EngSTAT\": %d, \"ECU_DOWNshift\": %d, "
        "\"ECU_CCswitchERR\": %d, \"ECU_UPshift\": %d, \"ECU_ApsERR\": %d, "
        "\"ECU_CCswitch\": %d, \"ECU_RPM_ERR\": %d, \"ECU_RPM\": %d, "
        "\"ECU_BrakeERR\": %d, \"ECU_GearStb\": %d, \"ECU_GearSet\": %d, "
        "\"ECU_GearERR\": %d, \"ECU_Gear\": %d, \"ECU_SideStandERR\": %d, "
        "\"ECU_BikeModel\": %d, \"ECU_SideStand\": %d, \"ECU_R_Brake\": %d, "
        "\"ECU_F_Brake\": %d, \"ECU_Data01_CNT\": %d, \"ECU_RLlambdaSTAT\": %d, "
        "\"ECU_FLlambdaSTAT\": %d, \"ECU_ClutchSTAT\": %d, \"ECU_Data01_CRC\": %d"
        "}",
        data->bt_acc_data.x, data->bt_acc_data.y, data->bt_acc_data.z,
        data->bt_gyro_data.x, data->bt_gyro_data.y, data->bt_gyro_data.z,
        data->bt_mag_data.x, data->bt_mag_data.y, data->bt_mag_data.z,
        data->IMU_A_Init_Status, data->IMU_G_Init_Status, data->IMU_M_Init_Status,
        data->Internal_Battery_Status,
        data->Source_Voltage,
        data->Wifi_Status, data->BT_Status, data->Cellular_Status,
        data->SIM_Active, data->GSM_NW,
        data->Ignition_Status,
        data->CANRx_Status_BBS, data->CANRx_Status_ECU, data->CANTx_Status_CCU,
        data->SOS_Status,
        BBS_Data->BBS_ExvlM_NA_ERR, BBS_Data->BBS_FSpeedSTAT, BBS_Data->BBS_FSpeed,
        BBS_Data->BBS_RSpeedSTAT, BBS_Data->BBS_ExvlCheck, BBS_Data->BBS_RSpeed,
        BBS_Data->BBS_DWCLevACK, BBS_Data->BBS_DTC_STAT, BBS_Data->BBS_DTCLevACK,
        BBS_Data->BBS_DSC_STAT, BBS_Data->BBS_DSCLevACK, BBS_Data->BBS_DWC_STAT,
        BBS_Data->BBS_Data01_CNT, BBS_Data->BBS_ExvlPot_ERR2, BBS_Data->BBS_ExvlPot_ERR1,
        BBS_Data->BBS_DAVC_STAT, BBS_Data->BBS_Data01_CRC,
        ECU_Data->ECU_APS, ECU_Data->ECU_EngSTAT, ECU_Data->ECU_DOWNshift,
        ECU_Data->ECU_CCswitchERR, ECU_Data->ECU_UPshift, ECU_Data->ECU_ApsERR,
        ECU_Data->ECU_CCswitch, ECU_Data->ECU_RPM_ERR, ECU_Data->ECU_RPM,
        ECU_Data->ECU_BrakeERR, ECU_Data->ECU_GearStb, ECU_Data->ECU_GearSet,
        ECU_Data->ECU_GearERR, ECU_Data->ECU_Gear, ECU_Data->ECU_SideStandERR,
        ECU_Data->ECU_BikeModel, ECU_Data->ECU_SideStand, ECU_Data->ECU_R_Brake,
        ECU_Data->ECU_F_Brake, ECU_Data->ECU_Data01_CNT, ECU_Data->ECU_RLlambdaSTAT,
        ECU_Data->ECU_FLlambdaSTAT, ECU_Data->ECU_ClutchSTAT, ECU_Data->ECU_Data01_CRC
    );
    
}

//JSON Format for GPS data

void json_Format_gps(const GPS_SignalData *GPS_Data, char *gps_json) {
    sprintf(gps_json,
        "{"
        "\"GPS_Status_Init\": %d, "
        "\"GPS_Status_Read\": %d, "
        "\"GPS_Status_Data_Validity\": %d, "
        "\"GPS_Lat\": %lf, "
        "\"GPS_Long\": %lf"
        "}",
        GPS_Data->GPS_Status_Init, 
        GPS_Data->GPS_Status_Read, 
        GPS_Data->GPS_Status_Data_Validity,
        GPS_Data->GPS_Lat,
        GPS_Data->GPS_Long
    );
}



/*******************************************************JSON FORMAT END**********************************************/


/**************************************************************************************************************************/
/***********************************************MQTT Device Data **********************************************************/
void bt_ccu_mqtt_DEVICE(void)
{
	//payload
	char main_json[8194];
	
	bt_ccu_mqtt_bbs_ecu_data();
	bt_ccu_mqtt_ReadSignalData(&data);
	// Format JSON payload
        format_json(&data,&bt_ccu_bbs_data, &bt_ccu_ecu_data, main_json);
        
        printf("Published: %s\n", main_json);

}


/**************************************************************************************************************************/
/***********************************************MQTT GPS Data **********************************************************/

void bt_ccu_mqtt_GPS(void)
{
	//payload
	char gps_json[128];

	bt_ccu_mqtt_ReadSignalData_GPS(&GPS_Data);
	// Format JSON payload       
	json_Format_gps(&GPS_Data,gps_json);
        
        printf("Published: %s\n", gps_json);
	
}





/**************************************************************************************************************************/
