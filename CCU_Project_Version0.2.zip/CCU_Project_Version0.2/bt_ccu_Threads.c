#include "common.h"
#include "bt_ccu_CANRx.h"
#include "bt_ccu_Init.h"
#include "bt_ccu_Pheripherals.h"
#include "bt_ccu_CANTx.h"
#include "bt_ccu_ESOS.h"
#include "bt_ccu_Calib.h"
#include "bt_ccu_MQTT.h"
#include "bt_ccu_Threads.h"
#include "bt_ccu_GPS.h"
#include "bt_ccu_CFG.h"
#include "bt_ccu_calibration.h"
#include "bt_ccu_AtoEmgcySOS_Algo.h"

int flag=0;  // to start the imu algo thread after 100 run 

// Function to get the current date and time (in ISO 8601 format, UTC)
void get_time(char *buf) {
    time_t rawtime;
    struct tm *timeinfo;
    struct timespec ts;

    clock_gettime(CLOCK_REALTIME, &ts); // Get the current time with nanoseconds precision
    rawtime = ts.tv_sec;               // Extract seconds
    timeinfo = gmtime(&rawtime);       // Convert to UTC time

    // Format the time as "YYYY-MM-DDTHH:MM:SS.sssZ"
    strftime(buf, 50, "%Y-%m-%dT%H:%M:%S.", timeinfo);
    snprintf(buf + strlen(buf), 50 - strlen(buf), "%03ldZ", ts.tv_nsec / 1000000);
}

// Thread function to handle RX (receive) processing for BBS (possibly Battery Management System or similar device)
void* BBSRx_thread_func(void* arg) {
    while (1) {
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing 0x18 Functionalities: %s\n", buf);
        bt_ccu_CAN_Rx_BBSAppProc(); // Process received data from BBS
        usleep(C_ccu_BBS_Rx_Sleep_10ms);             // Sleep for 10ms
        get_time(buf);
        printf("After Executing 0x18 Functionalities: %s\n", buf);
    }
    return NULL;
}

// Thread function to handle RX (receive) processing for ECU (Engine Control Unit)
void* ECURx_thread_func(void* arg) {
    while (1) {
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing 0x24 Functionalities: %s\n", buf);
        bt_ccu_CAN_RxECUAppProc(); // Process received data from ECU
        usleep(C_ccu_ECU_Rx_Sleep_10ms);            // Sleep for 10ms
        get_time(buf);
        printf("After Executing 0x24 Functionalities: %s\n", buf);
    }
    return NULL;
}

// Thread function to process data from the IMU (Inertial Measurement Unit)
void* imu_thread_func(void* arg) {
    static int count=0;
    while (count<100) {
		if(flag==0)
		{
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing imu Functionalities for calibration of imu for every 10ms: %s\n", buf);
        bt_ccu_READ_IMU_SENSORS(); // Read data from IMU sensors
		bt_ccu_IMU_Calibration(); //call calibration api  of asos and stop calling after 100 samples
		 usleep(C_ccu_IMU_Sleep_10ms);   
		 printf("Before Executing imu Functionalities for calibration of imu: %s\n", buf);
		 count++;
		 if(count ==100)
		 { 
	 flag=1;
	 }
		}
		else{
		char buf[50] = {0};
        get_time(buf);
        printf("Before Executing imu Functionalities for every 500ms: %s\n", buf);
        bt_ccu_READ_IMU_SENSORS(); // Read data from IMU sensors
        usleep(C_ccu_IMU_Sleep_500ms);           // Sleep for 500ms
        get_time(buf);
        printf("After Executing imu Functionalities for every 500ms: %s\n", buf);
       }
	}
    return NULL;
}

// Thread function to manage and process peripheral devices
void* peripherals_thread_func(void* arg) {
    while (1) {
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing peripherals Functionalities: %s\n", buf);
        bt_ccu_PHERIPH();         // Handle peripheral device functionalities
        usleep(C_ccu_PHERIP_Sleep_500ms);           // Sleep for 500ms
        get_time(buf);
        printf("After Executing peripherals Functionalities: %s\n", buf);
    }
    return NULL;
}

// Thread function to process GPS-related data
void* gps_thread_func(void* arg) {
    while (1) {
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing gps Functionalities: %s\n", buf);
        bt_ccu_GPS_PRCS();        // Process GPS data
        sleep(C_ccu_GPS_Sleep_1s);           // Sleep for 1s
        get_time(buf);
        printf("After Executing gps Functionalities: %s\n", buf);
    }
    return NULL;
}

// Thread function to handle manual SOS (emergency) functionalities
void* manual_sos_thread_func(void* arg) {
    while (1) {
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing manual sos Functionalities: %s\n", buf);
        bt_ccu_MnlEmgcySOS();     // Process manual SOS events
        usleep(C_ccu_MSOS_Sleep_500ms);           // Sleep for 500ms
        get_time(buf);
        printf("After Executing manual sos Functionalities: %s\n", buf);
    }
    return NULL;
}

// Thread function to handle automatic SOS (emergency) functionalities
void* auto_sos_thread_func(void* arg) {
    while (1) {
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing automatic Functionalities: %s\n", buf);
        bt_ccu_AtoEmgcySOS();     // Process automatic SOS events
        usleep(C_ccu_ASOS_Sleep_500ms);           // Sleep for 500ms
        get_time(buf);
        printf("After Executing Automatic Functionalities: %s\n", buf);
    }
    return NULL;
}

// Thread function to handle CAN (Controller Area Network) TX (transmit) functionalities
void* can_tx_thread_func(void* arg) {
    while (1) {
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing TX Functionalities: %s\n", buf);
        bt_ccu_CANTX_Proc();      // Process CAN TX operations
        usleep(C_ccu_CAN_Tx_Sleep_500ms);           // Sleep for 500ms
        get_time(buf);
        printf("After Executing TX Functionalities: %s\n", buf);
    }
    return NULL;
}

// Thread function to handle MQTT communication for device-related operations
void* ccu_mqtt_device_Thread(void* arg) {
    while (1) {
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing TX Functionalities: %s\n", buf);
        bt_ccu_mqtt_DEVICE();        // Process MQTT device-related communication
        usleep(C_ccu_MQTT_Device_Sleep_500ms);           // Sleep for 500ms
        get_time(buf);
        printf("After Executing TX Functionalities: %s\n", buf);
    }
    return NULL;
}

// Thread function to handle MQTT communication for GPS-related data
void* ccu_mqtt_gps_Thread(void* arg) {
    while (1) {
        char buf[50] = {0};
        get_time(buf);
        printf("Before Executing TX Functionalities: %s\n", buf);
        bt_ccu_mqtt_GPS();           // Process MQTT GPS-related communication
        sleep(C_ccu_MQTT_GPS_Sleep_1s);           // Sleep for 1s
        get_time(buf);
        printf("After Executing TX Functionalities: %s\n", buf);
    }
    return NULL;
}

