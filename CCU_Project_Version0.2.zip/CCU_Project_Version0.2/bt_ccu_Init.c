#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <termios.h>
#include <signal.h>
#include <stdint.h>
#include <linux/netlink.h>
#include <linux/if_link.h>
#include <linux/input.h>
#include <linux/rtnetlink.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>
#include "gsm.h"
#include <can.h>
#include "gyroscope.h"
#include "accelerometer.h"
#include "error_nos.h"
#include "magnetometer.h"
#include "battery.h"
#include <time.h>
#include "bt_ccu_CANRx.h"
#include "bt_ccu_Init.h"
#include "bt_ccu_Pheripherals.h"
#include "bt_ccu_CANTx.h"
#include "bt_ccu_ESOS.h"
#include "bt_ccu_Calib.h"
#include "bt_ccu_MQTT.h"


// Global initialization flags for various subsystems
// These flags will hold the status (TRUE or FALSE) of each system's initialization.
bool V_ccu_init_bat = FALSE;         // Battery initialization status
bool V_ccu_init_gsm_modem = FALSE;   // GSM Modem initialization status
bool V_ccu_init_gps = FALSE;         // GPS initialization status
bool V_ccu_init_acc = FALSE;         // Accelerometer initialization status
bool V_ccu_init_gyro = FALSE;        // Gyroscope initialization status
bool V_ccu_init_mag = FALSE;         // Magnetometer initialization status
bool V_ccu_init_can = FALSE;         // CAN communication initialization status
bool V_ccu_init_wifi = FALSE;        // WIFI initialization status
bool V_ccu_init_ble = FALSE;         // BLE initialization status
//bool V_ccu_GSM_set_msg_init = FALSE; // set the GSM to text message mode
//bool V_ccu_sim_sts = FALSE;     // Set the sim status to FALSE
bool V_ccu_init_sts = FALSE;             // Set the CCU Initialisation to FALSE


/**
 * Function to initialize and configure various subsystems and hardware.
 * This function initializes multiple subsystems such as Battery, GSM modem, GPS, 
 * Accelerometer, Gyroscope, Magnetometer, CAN, WIFI, BLE, and Ignition.
 */
void bt_ccu_INIT(void)
{
    int v_ccu_int_rc;
    char v_ccu_can_name[] = "can0";           // CAN bus name (can be changed based on the requirement)
    int v_ccu_can_bitrate = 500000;           // Bitrate for CAN (can be adjusted as needed)
    int v_ccu_wifi_mode = 0;                  // Mode for wifi initialization 1 --> hostapd mode , 0 --> station mode
    
    
    // Initialize the system (some initialization method for overall setup)
    v_ccu_int_rc = init(1);
       // Set the global flag based on the result of CCU initialization
    V_ccu_init_sts = (v_ccu_int_rc == 0) ? TRUE : FALSE; // CCU initialisation is successful or not
    printf("initialization %s. Status: %d\n", V_ccu_init_sts ? "successful" : "failed", v_ccu_int_rc);       

    // Initialize GSM modem
    //v_ccu_int_rc = gsm_modem_on(v_ccu_gsm_cpin, 4);  
    // Set the global flag based on the result of GSM modem initialization
    //V_ccu_init_gsm_modem = (v_ccu_int_rc == 0) ? TRUE : FALSE;
   // printf("GSM modem initialization %s. Status: %d\n", V_ccu_init_gsm_modem ? "successful" : "failed", v_ccu_int_rc);

    // Initialize GPS
    //v_ccu_int_rc = gps_init();
    // Set the global flag based on the result of GPS initialization
    //V_ccu_init_gps = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    //printf("GPS initialization %s. Status: %d\n", V_ccu_init_gps ? "successful" : "failed", v_ccu_int_rc);

   // sleep(1);  // Delay for 1 second to ensure initialization is stable as this is recommended by iWave

    // Initialize Accelerometer
    v_ccu_int_rc = acc_init();
    // Set the global flag based on the result of Accelerometer initialization
    V_ccu_init_acc = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("Accelerometer initialization %s. Status: %d\n", V_ccu_init_acc ? "successful" : "failed", v_ccu_int_rc);

    // Initialize Gyroscope
    v_ccu_int_rc = gyro_init();
    // Set the global flag based on the result of Gyroscope initialization
    V_ccu_init_gyro = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("Gyroscope initialization %s. Status: %d\n", V_ccu_init_gyro ? "successful" : "failed", v_ccu_int_rc);
    

    
    // Initialize CAN communication
    v_ccu_int_rc = can_init(v_ccu_can_name, v_ccu_can_bitrate);  // Initialize CAN bus with specified name and bitrate
    // Set the global flag based on the result of CAN initialization
    V_ccu_init_can = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("CAN initialization %s. Status: %d\n", V_ccu_init_can ? "successful" : "failed", v_ccu_int_rc);

    // Initialize WIFI
    v_ccu_int_rc = wifi_init(v_ccu_wifi_mode);
    // Set the global flag based on the result of WIFI initialization
    V_ccu_init_wifi = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("WIFI initialization %s. Status: %d\n", V_ccu_init_wifi ? "successful" : "failed", v_ccu_int_rc);

    // Initialize BLE (Bluetooth Low Energy)
    v_ccu_int_rc = ble_init();
    // Set the global flag based on the result of BLE initialization
    V_ccu_init_ble = (v_ccu_int_rc == 0) ? TRUE : FALSE;
    printf("BLE initialization %s. Status: %d\n", V_ccu_init_ble ? "successful" : "failed", v_ccu_int_rc);
       
 
    
    v_ccu_int_rc = ign_pin_status_check_enable();  // Enable Ignition PIN status check
    printf("IgnPin status Check enable value is %d:\n", v_ccu_int_rc);


     // Establish a connection to the GSM module (e.g., initializing communication with the GSM modem)
     //v_ccu_int_rc = establish_connection();  // This function returns an integer indicating the success or failure of the connection establishment

     // Set the GSM network mode to 4G (FOUR_G is likely a defined constant representing the 4G network mode)
    // v_ccu_int_rc = set_gsm_network_mode(FOUR_G);  // This configures the GSM module to use 4G network mode.

     /* Sending AT commands and receive the response */

     // Configure the GSM modem to use the specified Access Point Name (APN), dial-up command, and login credentials
     // These are typically used to set up the data connection for sending and receiving data over the network
     //gsm_apn_configuration("airtelgprs.com","ATDT*99***1#","abcd","1234");              
    
     
     // Call the calibration API to initialize or calibrate the required system components.
     //calib_API();

     bt_ccu_RESET_ECU_Rx();  // Reset ECU data structure
    
     bt_ccu_RESET_BBS_Rx();  // Reset BBS data structure
     // Initialize the MQTT (Message Queuing Telemetry Transport) structure for the CCU (Connectivity Control Unit)
     // This function likely prepares the internal data structure required for MQTT communication.
     // It might involve setting default values, initializing buffers, or configuring MQTT-related parameters.
     bt_ccu_mqtt_STRUCT_INTL();


	// Compiler switch for Automatic SOS
	// 
	//sleep(1);
}

/**
 * Function to get the CCU initialization status.
 * This function returns the global flag for CCU initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_STS(void) { 
    return V_ccu_init_sts; 
}
/**
 * Function to get the CAN initialization status.
 * This function returns the global flag for CAN initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_CAN_STS(void) { 
    return V_ccu_init_can; 
}

/**
 * Function to get the GPS initialization status.
 * This function returns the global flag for GPS initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_GPS_STS(void) { 
    return V_ccu_init_gps;
}

/**
 * Function to get the WIFI initialization status.
 * This function returns the global flag for WIFI initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_WIFI_STS(void) { 
    return V_ccu_init_wifi; 
}

/**
 * Function to get the BLE initialization status.
 * This function returns the global flag for BLE initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_BLE_STS(void) { 
    return V_ccu_init_ble; 
}


/**
 * Function to get the Accelerometer initialization status.
 * This function returns the global flag for Accelerometer initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_ACC_STS(void) { 
    return V_ccu_init_acc; 
}

/**
 * Function to get the Gyroscope initialization status.
 * This function returns the global flag for Gyroscope initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_GYRO_STS(void) { 
    return V_ccu_init_gyro; 
}

/**
 * Function to get the Magnetometer initialization status.
 * This function returns the global flag for Magnetometer initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_MAG_STS(void) { 
    return V_ccu_init_mag; 
}

/**
 * Function to get the GSM modem initialization status.
 * This function returns the global flag for GSM modem initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_GSM_STS(void) { 
    return V_ccu_init_gsm_modem; 
}

/**
 * Function to get the Battery initialization status.
 * This function returns the global flag for Battery initialization (TRUE or FALSE).
 */
bool bt_ccu_INIT_BAT_STS(void) {
    return V_ccu_init_bat;  // Return the global flag for battery initialization status
}




