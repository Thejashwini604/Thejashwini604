#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <math.h>
#include "bt_ccu_IMUSensors.h"
#include "bt_ccu_calibration.h"
#include "accelerometer.h"
#include "gyroscope.h"
#include "magnetometer.h"


#define CALIBRATION_SAMPLES 100
#define SENSOR_RATE_HZ 104
#define SAMPLE_INTERVAL_US (1000000 / SENSOR_RATE_HZ) // Time interval in microseconds

// Declare calibration offsets and sample count
double acc_x_offset = 0, acc_y_offset = 0, acc_z_offset = 0;
double gyro_x_offset = 0, gyro_y_offset = 0, gyro_z_offset = 0;
double mag_x_offset = 0, mag_y_offset = 0, mag_z_offset = 0;
int samples = 0;


void bt_ccu_IMU_Calibration_Process() {
    if (samples < CALIBRATION_SAMPLES) {
        //IMU_GetAccData();
        accelerometer_api_priv S_acc_read = bt_ccu_IMU_GetAccData();
        //bt_ccu_IMU_ProcessAccData(); 
        acc_x_offset += S_acc_read.x;
        acc_y_offset += S_acc_read.y;
        acc_z_offset += S_acc_read.z;

        //IMU_GetGyroData();
        gyroscope_api_priv S_gyro_read = bt_ccu_IMU_GetGyroData();
        //bt_ccu_IMU_ProcessGyroData(); 
        gyro_x_offset += S_gyro_read.x;
        gyro_y_offset += S_gyro_read.y;
        gyro_z_offset += S_gyro_read.z;

        //MU_GetMagData();
        magnetometer_api_priv S_mag_read = bt_ccu_IMU_GetMagData();
        //bt_ccu_IMU_ProcessMagData(); 
        mag_x_offset += S_mag_read.x;
        mag_y_offset += S_mag_read.y;
        mag_z_offset += S_mag_read.z;

        samples++;
    } else {
        acc_x_offset /= CALIBRATION_SAMPLES;
        acc_y_offset /= CALIBRATION_SAMPLES;
        acc_z_offset /= CALIBRATION_SAMPLES;

        gyro_x_offset /= CALIBRATION_SAMPLES;
        gyro_y_offset /= CALIBRATION_SAMPLES;
        gyro_z_offset /= CALIBRATION_SAMPLES;

        mag_x_offset /= CALIBRATION_SAMPLES;
        mag_y_offset /= CALIBRATION_SAMPLES;
        mag_z_offset /= CALIBRATION_SAMPLES;

         // Calibration complete
    }
     // Calibration ongoing
}
/*
void bt_ccu_IMU_Calibration(void) {
    int calibration_complete = 0;
    struct timespec start_time, current_time;

    // Record the starting time
    clock_gettime(CLOCK_MONOTONIC, &start_time);

    while (!calibration_complete) {
        // Call the calibration function
        calibration_complete = bt_ccu_IMU_Calibration_Process();
    }
}

