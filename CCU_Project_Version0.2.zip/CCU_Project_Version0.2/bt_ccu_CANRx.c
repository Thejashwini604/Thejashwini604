#include <stdio.h>
#include "common.h"
#include <can.h>
#include "bt_ccu_CANRx.h"
#include "bt_ccu_CANTx.h"
#include  "bt_ccu_Init.h"
#include "bt_ccu_MQTT.h"
#include  "bt_ccu_Pheripherals.h"
#include <stdbool.h>

// Boolean flag to track if BBS data has been successfully received (initially set to FALSE)
bool V_ccu_CANRx_BBSRead  = FALSE;

// Boolean flag to track if ECU data has been successfully received (initially set to FALSE)
bool V_ccu_CANRx_ECURead = FALSE;

/**
 * Function to extract ECU data from a CAN frame.
 * 
 * This function will process a given CAN frame, extract relevant ECU data from it,
 * and store the extracted information in an ECU data structure.
 * The exact details of how the data is extracted would depend on the CAN protocol
 * and the ECU data format, which are not provided in the declaration.
 * 
 * @param frame A `canfd_frame` structure containing the raw CAN data to be processed.
 */
void bt_ccu_EXTRACT_ECU_Data(struct canfd_frame frame);

/**
 * Function to extract BBS data from a CAN frame.
 * 
 * This function will process a given CAN frame, extract relevant BBS data from it,
 * and store the extracted information in a BBS data structure.
 * The exact details of how the data is extracted would depend on the CAN protocol
 * and the BBS data format, which are not provided in the declaration.
 * 
 * @param frame A `canfd_frame` structure containing the raw CAN data to be processed.
 */
void bt_ccu_EXTRACT_BBS_Data(struct canfd_frame frame);


/******************************************************************************/
// Function: CAN_BBSApplicationProcessing
// Purpose: This function reads CAN Rx data with Message ID 0x18 and processes it.
/******************************************************************************/ 
void bt_ccu_CAN_Rx_BBSAppProc(void) {
    int bt_ccu_rc;  // Variable to store the return code from various functions
    struct canfd_frame bt_ccu_can_frame;  				// Struct to store CAN frame data
    char bt_ccu_can_rx_name[] = "can0";  				// CAN interface name
    uint32_t bt_ccu_can_rx_mask[1] = {C_ccu_CANRx_BBS};  			// CAN mask used for filtering messages by ID
    uint32_t bt_ccu_can_id[1] = {C_ccu_CANRx_BBS};  		// CAN filter ID (message ID to be filtered)
    int bt_ccu_mask_len = 0;  					// Length of the filter array
    bool bt_ccu_ret = FALSE;   // Initialize boolean variable 'ret' to FALSE, typically used to track success/failure
    // Flags to indicate the status of CAN mask and filter setup
    bool bt_ccu_can_bbs_ftr = FALSE;   
 
   
    // Get the length of the CAN filter ID array
    bt_ccu_mask_len = sizeof(bt_ccu_can_id) / sizeof(bt_ccu_can_id[0]);

    // Set the CAN mask and filter using the `set_can_mask_and_filter` function
    bt_ccu_rc = set_can_mask_and_filter(bt_ccu_can_rx_mask, bt_ccu_can_id, bt_ccu_mask_len);
    
    // Check if setting CAN mask and filter was successful
    if (bt_ccu_rc == 0) {
        bt_ccu_can_bbs_ftr = TRUE;  // Set flag to TRUE if successful
        printf("status of CAN mask and filter %d\n", bt_ccu_rc);
    } else {
        bt_ccu_can_bbs_ftr = FALSE;  
        // If setting the mask and filter fails, do nothing, the flag remains FALSE
        printf("status of CAN mask and filter Failure %d\n", bt_ccu_rc);            
    }
    
    // Check if CAN initialization status is TRUE
    if (bt_ccu_INIT_CAN_STS() == TRUE) {
        // If CAN mask and filter were successfully set
        if (bt_ccu_can_bbs_ftr == TRUE) {
            printf("Can mask and filter setting is Success\n");
            
            // Read the CAN data with the specified ID (0x18)
            bt_ccu_rc = can_read(bt_ccu_can_rx_name, &bt_ccu_can_frame);
            printf("Return value for CAN_Read : %x\n", bt_ccu_rc);
            printf("\n");
            
            // If reading the CAN frame failed (bt_ccu_rc <= 0), print failure message and reset data
            if (bt_ccu_rc <= 0) {
                printf("CAN_Read Failed\n");
                V_ccu_CANRx_BBSRead = FALSE;
                bt_ccu_RESET_BBS_Rx();  // Reset BBS data structure to clear any previous data
            } else {
                // If CAN frame was successfully read
                printf("Can Read Success\n");
                // Extract the relevant BBS data from the CAN frame
                bt_ccu_EXTRACT_BBS_Data(bt_ccu_can_frame);
 		        V_ccu_CANRx_BBSRead = TRUE;               
                // Print the extracted BBS data values
                printf("BBS_ExvlM_NA_ERR value is : %x\n", bt_ccu_BBS_DATA.BBS_ExvlM_NA_ERR);
                printf("BBS_FSpeedSTAT value is : %x\n", bt_ccu_BBS_DATA.BBS_FSpeedSTAT);
                printf("BBS_FSpeed value is : %d\n", bt_ccu_BBS_DATA.BBS_FSpeed);
                
                // Print the physical value of FSpeed (currently not in use, placeholder)
                printf("BBS_RSpeedSTAT value is : %x\n", bt_ccu_BBS_DATA.BBS_RSpeedSTAT);
                printf("BBS_ExvlCheck value is : %x\n", bt_ccu_BBS_DATA.BBS_ExvlCheck);
                printf("BBS_RSpeed value is : %x\n", bt_ccu_BBS_DATA.BBS_RSpeed);
                
                // Print the physical value of RSpeed (currently not in use, placeholder)
                printf("BBS_DWCLevACK value is : %x\n", bt_ccu_BBS_DATA.BBS_DWCLevACK);
                printf("BBS_DTC_STAT value is : %x\n", bt_ccu_BBS_DATA.BBS_DTC_STAT);
                printf("BBS_DTCLevACK value is : %x\n", bt_ccu_BBS_DATA.BBS_DTCLevACK);
                printf("BBS_DSC_STAT value is : %x\n", bt_ccu_BBS_DATA.BBS_DSC_STAT);
                printf("BBS_DSCLevACK value is : %x\n", bt_ccu_BBS_DATA.BBS_DSCLevACK);
                printf("BBS_DWC_STAT value is : %x\n", bt_ccu_BBS_DATA.BBS_DWC_STAT);
                printf("BBS_Data01_CNT value is : %x\n", bt_ccu_BBS_DATA.BBS_Data01_CNT);
                printf("BBS_ExvlPot_ERR2 value is : %x\n", bt_ccu_BBS_DATA.BBS_ExvlPot_ERR2);
                printf("BBS_ExvlPot_ERR1 value is : %x\n", bt_ccu_BBS_DATA.BBS_ExvlPot_ERR1);
                printf("BBS_DAVC_STAT value is : %x\n", bt_ccu_BBS_DATA.BBS_DAVC_STAT);
                printf("BBS_Data01_CRC value is : %x\n", bt_ccu_BBS_DATA.BBS_Data01_CRC);
            }
        }
        // If CAN mask and filter setup failed, print an error message
        else {
        
            V_ccu_CANRx_BBSRead = FALSE;
            bt_ccu_RESET_BBS_Rx();  // Reset BBS data structure to clear any previous data
            printf("Can mask and filter setting is Failed\n");
        }
    }
    // If CAN initialization failed, print an error message
    else {
    
        V_ccu_CANRx_BBSRead = FALSE;
        bt_ccu_RESET_BBS_Rx();  // Reset BBS data structure to clear any previous data
        printf("Can init Failed\n");
    }
}

/**
 * @code
 *  CAN_ECUApplicationProcessing(void)
 * @endcode
 * @brief This function reads the CAN Rx data with Message ID 0x24 and processes it.
 * @param void
 * @return CAN read specific codes
 * @note This function interacts with the CAN bus to retrieve ECU-related data and processes the response.
 */
void bt_ccu_CAN_RxECUAppProc(void) {

    int bt_ccu_rc ;  			// Return code for various operations
    struct canfd_frame bt_ccu_can_frame;  		// CAN frame to store the received data
    char bt_ccu_can_name[] = "can0";  		// CAN interface name (typically "can1")
    uint32_t bt_ccu_can_mask[1] = {C_ccu_CANRx_ECU};  	// CAN mask for filtering messages (ID 0x24)
    uint32_t bt_ccu_can_ftr_id[1] = {C_ccu_CANRx_ECU};	// CAN filter ID (message ID to filter for)
    int bt_ccu_length = 0;  			// Length of the CAN filter array
    bool bt_ccu_ret = FALSE; // Initialize boolean variable 'ret' to FALSE, typically used to track success/failure
    
    bool bt_ccu_can_ecu_ftr = FALSE;
    // Calculate the length of the filter array
    bt_ccu_length = sizeof(bt_ccu_can_ftr_id) / sizeof(bt_ccu_can_ftr_id[0]);

    // Set CAN mask and filter with the specified values
    bt_ccu_rc = set_can_mask_and_filter(bt_ccu_can_mask, bt_ccu_can_ftr_id, bt_ccu_length);
    if (bt_ccu_rc == 0) {
        bt_ccu_can_ecu_ftr = TRUE;  // Set the flag to TRUE if mask and filter are set successfully
        printf("Status of CAN mask and filter: %d\n", bt_ccu_rc);
    } else {
    
        bt_ccu_can_ecu_ftr = FALSE;
        // If setting the CAN mask and filter failed, do nothing (flag remains FALSE)
        printf("Status of CAN mask and filter failure: %d\n", bt_ccu_rc);            
    }

    // Check if CAN initialization was successful
    if (bt_ccu_INIT_CAN_STS() == TRUE) {
        // If CAN mask and filter were successfully set
        if (bt_ccu_can_ecu_ftr == TRUE) {
            printf("CAN mask and filter setting is successful\n");

            // Read the CAN frame (Message ID 0x24)
            bt_ccu_rc = can_read(bt_ccu_can_name, &bt_ccu_can_frame);
            printf("Return value for CAN_Read: %x\n", bt_ccu_rc);
            printf("\n");

            // If CAN read failed, reset ECU data and print failure message
            if (bt_ccu_rc <= 0) {
                printf("CAN_Read failed\n");
                bt_ccu_RESET_ECU_Rx();  // Reset ECU data structure
            } else {
                // If CAN read succeeded, extract data from the frame
                printf("CAN Read successful\n");
                bt_ccu_EXTRACT_ECU_Data(bt_ccu_can_frame);  // Extract data into the ecu_data structure
                 V_ccu_CANRx_ECURead = TRUE;
                // Print the extracted ECU data values
                printf("ECU_APS value is: %x\n", bt_ccu_ECU_DATA.ECU_APS);
                printf("ECU_EngSTAT value is: %x\n", bt_ccu_ECU_DATA.ECU_EngSTAT);
                printf("ECU_DOWNshift value is: %x\n", bt_ccu_ECU_DATA.ECU_DOWNshift);
                printf("ECU_CCswitchERR value is: %x\n", bt_ccu_ECU_DATA.ECU_CCswitchERR);
                printf("ECU_UPshift value is: %x\n", bt_ccu_ECU_DATA.ECU_UPshift);
                printf("ECU_ApsERR value is: %x\n", bt_ccu_ECU_DATA.ECU_ApsERR);
                printf("ECU_CCswitch value is: %x\n", bt_ccu_ECU_DATA.ECU_CCswitch);
                printf("ECU_RPM_ERR value is: %x\n", bt_ccu_ECU_DATA.ECU_RPM_ERR);
                printf("ECU_RPM value is: %x\n", bt_ccu_ECU_DATA.ECU_RPM);
                printf("ECU_BrakeERR value is: %x\n", bt_ccu_ECU_DATA.ECU_BrakeERR);
                printf("ECU_GearStb value is: %x\n", bt_ccu_ECU_DATA.ECU_GearStb);
                printf("ECU_GearSet value is: %x\n", bt_ccu_ECU_DATA.ECU_GearSet);
                printf("ECU_GearERR value is: %x\n", bt_ccu_ECU_DATA.ECU_GearERR);
                printf("ECU_Gear value is: %x\n", bt_ccu_ECU_DATA.ECU_Gear);
                printf("ECU_SideStandERR value is: %x\n", bt_ccu_ECU_DATA.ECU_SideStandERR);
                printf("ECU_SideStand value is: %x\n", bt_ccu_ECU_DATA.ECU_SideStand);
                printf("ECU_R_Brake value is: %x\n", bt_ccu_ECU_DATA.ECU_R_Brake);
                printf("ECU_F_Brake value is: %x\n", bt_ccu_ECU_DATA.ECU_F_Brake);
                printf("ECU_Data01_CNT value is: %x\n", bt_ccu_ECU_DATA.ECU_Data01_CNT);
                printf("ECU_RLlambdaSTAT value is: %x\n", bt_ccu_ECU_DATA.ECU_RLlambdaSTAT);
                printf("ECU_FLlambdaSTAT value is: %x\n", bt_ccu_ECU_DATA.ECU_FLlambdaSTAT);
                printf("ECU_ClutchSTAT value is: %x\n", bt_ccu_ECU_DATA.ECU_ClutchSTAT);
                printf("ECU_Data01_CRC value is: %x\n", bt_ccu_ECU_DATA.ECU_Data01_CRC);
            }
        } else {
        
        V_ccu_CANRx_ECURead = FALSE;
        bt_ccu_RESET_ECU_Rx();  // Reset ECU data structure
            // If the CAN mask and filter setting failed, print an error message
            printf("CAN mask and filter setting failed\n");
        }
    } else {
    
         V_ccu_CANRx_ECURead = FALSE;
         bt_ccu_RESET_ECU_Rx();  // Reset ECU data structure
        // If CAN initialization failed, print an error message
        printf("CAN initialization failed\n");
    }
}

/**
 * @code
 *  extract_ECU_Data(struct ECU_Rx *ecu_data, struct canfd_frame *frame)
 * @endcode
 * @brief This function extracts the ECU data bits from the CAN frame and stores them in the `ecu_data` structure.
 * @param ecu_data Pointer to the ECU data structure to store the extracted values
 * @param frame CAN frame containing the received data
 * @return void
 * @note This function performs bitwise extraction to extract various ECU-related bits and stores them in the `ecu_data` structure.
 */
void bt_ccu_EXTRACT_ECU_Data( struct canfd_frame frame) {
     
    // Extracting bits from CAN frame data using shifts and masks

    bt_ccu_ECU_DATA.ECU_APS = frame.data[0];  // 8 bits (Full byte for ECU_APS)
    
    // Extract 3 bits for ECU_EngSTAT (from byte 1)
    bt_ccu_ECU_DATA.ECU_EngSTAT = (frame.data[1] >> 5) & 0x07;  // 3 bits
    
    // Extract single bits for various flags (from byte 1)
    bt_ccu_ECU_DATA.ECU_DOWNshift = (frame.data[1] >> 4) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_CCswitchERR = (frame.data[1] >> 3) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_UPshift = (frame.data[1] >> 2) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_ApsERR = (frame.data[1] >> 1) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_CCswitch = frame.data[1] & 0x01;  // 1 bit

    // Extract ECU_RPM_ERR (1 bit) and ECU_RPM (15 bits)
    bt_ccu_ECU_DATA.ECU_RPM_ERR = (frame.data[2] >> 7) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_RPM = ((frame.data[2] & 0x7F) << 8) | frame.data[3];  // 15 bits (combine 2 bytes)

    // Adjust ECU_RPM based on ECU_RPM (add formula for RPM adjustment)
    bt_ccu_ECU_DATA.ECU_RPM = (bt_ccu_ECU_DATA.ECU_RPM * 0.5) + 0;

    // Extract other ECU flags and values (from byte 4)
    bt_ccu_ECU_DATA.ECU_BrakeERR = (frame.data[4] >> 6) & 0x03;  // 2 bits
    bt_ccu_ECU_DATA.ECU_GearStb = (frame.data[4] >> 5) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_GearSet = (frame.data[4] >> 4) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_GearERR = (frame.data[4] >> 3) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_Gear = (frame.data[4] >> 0) & 0x07;  // 3 bits

    // Extract additional flags from byte 5
    bt_ccu_ECU_DATA.ECU_SideStandERR = (frame.data[5] >> 7) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_BikeModel = (frame.data[5] >> 3) & 0x0F;  // 4 bits
    bt_ccu_ECU_DATA.ECU_SideStand = (frame.data[5] >> 2) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_R_Brake = (frame.data[5] >> 1) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_F_Brake = frame.data[5] & 0x01;  // 1 bit

    // Extract ECU flags and values from byte 6
    bt_ccu_ECU_DATA.ECU_Data01_CNT = (frame.data[6] >> 4) & 0x0F;  // 4 bits
    bt_ccu_ECU_DATA.ECU_RLlambdaSTAT = (frame.data[6] >> 3) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_FLlambdaSTAT = (frame.data[6] >> 2) & 0x01;  // 1 bit
    bt_ccu_ECU_DATA.ECU_ClutchSTAT = (frame.data[6] >> 0) & 0x03;  // 2 bits

    // Extract the CRC value (8 bits) from byte 7
    bt_ccu_ECU_DATA.ECU_Data01_CRC = frame.data[7];  // 8 bits
   
}
/**
 * @code
 *  extract_BBS_Data(struct BBS_Data01 *BBS_Data, struct canfd_frame *frame)
 * @endcode
 * @brief This function is used to extract the bits from the CAN frame and copy them into the structure.
 * @param BBS_Data Pointer to the BBS_Rx structure where the extracted data will be stored.
 * @param frame The CAN frame containing the received data.
 * @return void
 * @note This function performs bitwise operations to extract specific ECU data from the CAN frame and populates the `BBS_Data` structure with those values.
 */
void bt_ccu_EXTRACT_BBS_Data(struct canfd_frame frame) {
    
    // Extracting bits using shifts and masks from the received CAN frame (frame.data)
    // BBS_ExvlM_NA_ERR (1 bit) - from bit 7 of frame.data[1]
    bt_ccu_BBS_DATA.BBS_ExvlM_NA_ERR = frame.data[1] & 0x01;

    // BBS_FSpeedSTAT (2 bits) - from bits 6-7 of frame.data[1]
    bt_ccu_BBS_DATA.BBS_FSpeedSTAT = (frame.data[1] >> 1) & 0x03;
    
    // BBS_FSpeed (13 bits) - from frame.data[1 (bits 0-4)] + frame.data[2 (bits 0-7)]
    bt_ccu_BBS_DATA.BBS_FSpeed = (frame.data[0]) | ((frame.data[1] & 0x1F) << 8) ;
    
    // Apply scaling factor for BBS_FSpeed
    bt_ccu_BBS_DATA.BBS_FSpeed = (bt_ccu_BBS_DATA.BBS_FSpeed * 0.0625) + 0;

    // BBS_RSpeedSTAT (2 bits) - from bits 5-6 of frame.data[3]
    bt_ccu_BBS_DATA.BBS_RSpeedSTAT = (frame.data[2] >> 5) & 0x03;

    // BBS_ExvlCheck (1 bit) - from bit 7 of frame.data[3]
    bt_ccu_BBS_DATA.BBS_ExvlCheck = (frame.data[2] >> 7) & 0x01;


    // BBS_RSpeed (13 bits) - from frame.data[3 (bits 0-4)] + frame.data[4 (bits 0-7)]
    bt_ccu_BBS_DATA.BBS_RSpeed = ((frame.data[2] & 0xF1) >> 8) | frame.data[3];
    // Apply scaling factor for BBS_RSpeed
    bt_ccu_BBS_DATA.BBS_RSpeed = (bt_ccu_BBS_DATA.BBS_RSpeed * 0.0625) + 0;

    // BBS_DWCLevACK (3 bits) - from bits 5-7 of frame.data[5]
    bt_ccu_BBS_DATA.BBS_DWCLevACK = (frame.data[4] >> 5) & 0x07;

    // BBS_DTC_STAT (2 bits) - from bits 3-4 of frame.data[5]
    bt_ccu_BBS_DATA.BBS_DTC_STAT = (frame.data[4] >> 3) & 0x03;

    // BBS_DTCLevACK (3 bits) - from bits 0-2 of frame.data[5]
    bt_ccu_BBS_DATA.BBS_DTCLevACK = (frame.data[4] >> 5) & 0x07;

    // BBS_DSC_STAT (2 bits) - from bits 6-7 of frame.data[6]
    bt_ccu_BBS_DATA.BBS_DSC_STAT = (frame.data[5] >> 6) & 0x03;

    // BBS_DSCLevACK (3 bits) - from bits 3-5 of frame.data[6]
    bt_ccu_BBS_DATA.BBS_DSCLevACK = (frame.data[5] >> 3) & 0x07;

    // BBS_DWC_STAT (2 bits) - from bits 1-2 of frame.data[6]
    bt_ccu_BBS_DATA.BBS_DWC_STAT = (frame.data[5] >> 1) & 0x03;

    // BBS_Data01_CNT (4 bits) - from bits 0, 1, and 5-7 of frame.data[6]
    bt_ccu_BBS_DATA.BBS_Data01_CNT = ((frame.data[6] & 0x01) << 3) | (frame.data[6] >> 5);

    // BBS_ExvlPot_ERR2 (1 bit) - from bit 4 of frame.data[7]
    bt_ccu_BBS_DATA.BBS_ExvlPot_ERR2 = (frame.data[6] >> 4) & 0x01;

    // BBS_ExvlPot_ERR1 (1 bit) - from bit 3 of frame.data[7]
    bt_ccu_BBS_DATA.BBS_ExvlPot_ERR1 = (frame.data[6] >> 3) & 0x01;

    // BBS_DAVC_STAT (2 bits) - from bits 1-2 of frame.data[7]
    bt_ccu_BBS_DATA.BBS_DAVC_STAT = (frame.data[6] >> 1) & 0x03;

    // BBS_Data01_CRC (8 bits) - from the last byte (frame.data[7])
    bt_ccu_BBS_DATA.BBS_Data01_CRC = frame.data[7] & 0xFF;
}

/**
 * @code
 *  reset_BBS_Rx(struct BBS_Rx *bbs_data)
 * @endcode
 * @brief This function is used to reset the structure `BBS_Rx` to default values (zeros).
 * @param bbs_data Pointer to the `BBS_Rx` structure to be reset.
 * @return void
 * @note This function sets all the members of the `BBS_Rx` structure to zero, ensuring that no residual data remains.
 */
void bt_ccu_RESET_BBS_Rx(void) {
    // Set each structure member to zero (Reset the structure to default values)
    bt_ccu_BBS_DATA.BBS_ExvlM_NA_ERR		= 0;		// Reset the "ExvlM_NA_ERR" to 0 (Error in ExvlM (Electrovalve))
    bt_ccu_BBS_DATA.BBS_FSpeedSTAT		= 0;		// Reset the "FSpeedSTAT" to 0 (Front speed status)
    bt_ccu_BBS_DATA.BBS_FSpeed			= 0;		// Reset the "FSpeed" to 0 (Front speed value)
    bt_ccu_BBS_DATA.BBS_RSpeedSTAT		= 0;		// Reset the "RSpeedSTAT" to 0 (Rear speed status)
    bt_ccu_BBS_DATA.BBS_ExvlCheck		= 0;		// Reset the "ExvlCheck" to 0 (Electrovalve check status)
    bt_ccu_BBS_DATA.BBS_RSpeed			= 0;		// Reset the "RSpeed" to 0 (Rear speed value)
    bt_ccu_BBS_DATA.BBS_DWCLevACK		= 0;		// Reset the "DWCLevACK" to 0 (DWC level acknowledgment)
    bt_ccu_BBS_DATA.BBS_DTC_STAT		= 0;            // Reset the "DTC_STAT" to 0 (Diagnostic Trouble Code Status)
    bt_ccu_BBS_DATA.BBS_DTCLevACK		= 0;		// Reset the "DTCLevACK" to 0 (DTC level acknowledgment)
    bt_ccu_BBS_DATA.BBS_DSC_STAT		= 0;            // Reset the "DSC_STAT" to 0 (Dynamic Stability Control Status)
    bt_ccu_BBS_DATA.BBS_DSCLevACK		= 0;		// Reset the "DSCLevACK" to 0 (DSC level acknowledgment)
    bt_ccu_BBS_DATA.BBS_DWC_STAT		= 0;            // Reset the "DWC_STAT" to 0 (DWC status)
    bt_ccu_BBS_DATA.BBS_Data01_CNT		= 0;		// Reset the "Data01_CNT" to 0 (Data counter)
    bt_ccu_BBS_DATA.BBS_ExvlPot_ERR2		= 0;		// Reset the "ExvlPot_ERR2" to 0 (Error in Electrovalve Potentiometer 2)
    bt_ccu_BBS_DATA.BBS_ExvlPot_ERR1		= 0;		// Reset the "ExvlPot_ERR1" to 0 (Error in Electrovalve Potentiometer 1)
    bt_ccu_BBS_DATA.BBS_DAVC_STAT		= 0;		// Reset the "DAVC_STAT" to 0 (Dynamic Adaptive Cruise Control status)
    bt_ccu_BBS_DATA.BBS_Data01_CRC		= 0;		// Reset the "Data01_CRC" to 0 (Cyclic Redundancy Check for data integrity)

}

/**
 * @code
 *  reset_ecu_data01(struct ecu_data01 *ecu_data)
 * @endcode
 * @brief This function is used to reset the `ECU_Rx` structure members to their default values (zero).
 * @param ecu_data Pointer to the `ECU_Rx` structure to be reset.
 * @return void
 * @note This function clears out all the fields in the `ECU_Rx` structure, setting them to zero. It is useful for ensuring that the structure is in a clean state before new data is processed.
 */
void bt_ccu_RESET_ECU_Rx(void) {
    // Reset ECU_Rx structure members to default value of 0
    bt_ccu_ECU_DATA.ECU_APS			= 0;   // Accelerator Pedal Signal (APS)
    bt_ccu_ECU_DATA.ECU_EngSTAT		= 0;   // Engine Status
    bt_ccu_ECU_DATA.ECU_DOWNshift		= 0;   // Downshift Flag
    bt_ccu_ECU_DATA.ECU_CCswitchERR		= 0;   // Cruise Control Switch Error
    bt_ccu_ECU_DATA.ECU_UPshift		= 0;   // Upshift Flag
    bt_ccu_ECU_DATA.ECU_ApsERR			= 0;   // Accelerator Pedal Error
    bt_ccu_ECU_DATA.ECU_CCswitch		= 0;   // Cruise Control Switch
    
    bt_ccu_ECU_DATA.ECU_RPM_ERR		= 0;   // RPM Error
    bt_ccu_ECU_DATA.ECU_RPM			= 0;   // Engine RPM value
    
    bt_ccu_ECU_DATA.ECU_BrakeERR		= 0;   // Brake Error
    bt_ccu_ECU_DATA.ECU_GearStb		= 0;   // Gear Stabilization
    bt_ccu_ECU_DATA.ECU_GearSet		= 0;   // Gear Set value
    bt_ccu_ECU_DATA.ECU_GearERR		= 0;   // Gear Error
    bt_ccu_ECU_DATA.ECU_Gear			= 0;   // Gear value
    
    bt_ccu_ECU_DATA.ECU_SideStandERR		= 0;   // Side Stand Error
    bt_ccu_ECU_DATA.ECU_BikeModel		= 0;   // Bike Model
    bt_ccu_ECU_DATA.ECU_SideStand		= 0;   // Side Stand Status
    bt_ccu_ECU_DATA.ECU_R_Brake		= 0;   // Rear Brake Status
    bt_ccu_ECU_DATA.ECU_F_Brake		= 0;   // Front Brake Status
    
    bt_ccu_ECU_DATA.ECU_Data01_CNT		= 0;   // Data Counter
    bt_ccu_ECU_DATA.ECU_RLlambdaSTAT		= 0;   // Right Lambda Sensor Status
    bt_ccu_ECU_DATA.ECU_FLlambdaSTAT		= 0;   // Left Lambda Sensor Status
    bt_ccu_ECU_DATA.ECU_ClutchSTAT		= 0;   // Clutch Status
    
    bt_ccu_ECU_DATA.ECU_Data01_CRC		= 0;   // CRC Checksum (for data integrity)
}
// Function to check the status of ECU Read (Controller Area Network Receive for ECU Read)
// @return TRUE if ECU Read is active, FALSE otherwise
bool bt_ccu_RX_ECUREADSTS(void)
{
    // In this function, it simply returns TRUE, indicating that the ECU Read status is active.
    // In a real implementation, this function would check the status of the ECU's CAN receive functionality.
    
    return V_ccu_CANRx_ECURead;  // ECU Read status is active (TRUE) or deactive ( FALSE )
}

// Function to check the status of BBS Read (Controller Area Network Receive for BBS Read)
// @return TRUE if BBS Read is active, FALSE otherwise
bool bt_ccu_RX_BBSREADSTS(void)
{
    // This function returns TRUE, indicating that the BBS Read status is active.
    // In a complete system, this function would interact with the BBS (Body Control Module) or CAN network
    // to confirm whether the BBS Read is operational.
    
    return V_ccu_CANRx_BBSRead;  // BBS Read status is active (TRUE) or deactive ( FALSE )
}

// Function to return a pointer to the BBS_Rx structure
// This function does not take any arguments and returns a pointer to the global structure 'rb_ccu_BBS_DATA'
struct bt_ccu_BBS_Rx bt_ccu_BBS_EXTCT_DATA(void)
{
    // Return the address of the 'rb_ccu_BBS_DATA' structure
    // This allows other functions or files to access and manipulate the data in 'rb_ccu_BBS_DATA'
    return bt_ccu_BBS_DATA;  // Return pointer to BBS_Rx structure
}

// Function to return a pointer to the ECU_Rx structure
// This function does not take any arguments and returns a pointer to the global structure 'bt_ccu_ECU_DATA'
struct bt_ccu_ECU_Rx bt_ccu_ECU_EXTCT_DATA(void)
{
    // Return the address of the 'bt_ccu_ECU_DATA' structure
    // This allows other functions or files to access and manipulate the data in 'bt_ccu_ECU_DATA'
    return bt_ccu_ECU_DATA;  // Return pointer to ECU_Rx structure
}

/******************************************************************************/ 
/*-----------------------------END-----------------------------------------*/
/******************************************************************************/

