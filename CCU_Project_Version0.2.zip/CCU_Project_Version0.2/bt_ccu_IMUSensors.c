/***********Manual EmergencySOS implmentation*******************
 * @ file bt_ccu_IMU_Sensors.c
   @ Author: Thejashwini Anand
   @ Date: 1/16/2025
   @ Brigosha technologies pvt lmt
*****************************************************************/

/**************************************************************************************************************************/
/*----------------------------------------------Includes------------------------------------------------------------------*/
/**************************************************************************************************************************/
#include "bt_ccu_IMUSensors.h"

/*******************************Global Variables of IMU sensors****************/
accelerometer_api_priv S_Acc_read;
gyroscope_api_priv S_Gyro_read;
magnetometer_api_priv S_Mag_read;

/***************Accelerometer read API**************************************/
void bt_ccu_IMU_ProcessAccData (void)
{
	/* Reading the accelerometer values from the Telematics */
	
	bool v_acc_init_sts = bt_ccu_INIT_ACC_STS();

    memset( &S_Acc_read, 0, sizeof( S_Acc_read ) );
	int acc_read_ret= accelerometer_read (&S_Acc_read); 

	if ((FALSE==v_acc_init_sts) | (acc_read_ret!=0))
	{
		printf("Accelerometer read failed and the return code is: %d\n", acc_read_ret);
		S_Acc_read.x =0;
		S_Acc_read.y =0;
		S_Acc_read.z =0;
	}
	
}

/******************Gyroscope read API*********************************************/
void bt_ccu_IMU_ProcessGyroData(void)
{
     /* Reading the gyroscope values from the Telematics */
     
bool v_gyro_init_sts = bt_ccu_INIT_GYRO_STS(); 
      
    memset( &S_Gyro_read, 0, sizeof( S_Gyro_read ) );
	int v_gyro_read_ret= gyroscope_read(&S_Gyro_read);
	
	if( (FALSE==v_gyro_init_sts) | (v_gyro_read_ret!=0))
	{
		printf("Gyroscope read failed and the return code is: %d\n", v_gyro_read_ret);
		S_Gyro_read.x =0;
		S_Gyro_read.y =0;
		S_Gyro_read.z =0;
	}
}

/*******************Magnetometer Read API************************************************/
void bt_ccu_IMU_ProcessMagData(void)
{
        /* Reading the gyroscope values from the Telematics */
     bool v_mag_init_sts = bt_ccu_INIT_MAG_STS();
       
    memset( &S_Mag_read, 0, sizeof( S_Mag_read ) );
	int mag_read_ret= magnetometer_read(&S_Mag_read);
	
	if((FALSE==v_mag_init_sts) | (mag_read_ret!=0))
	{
		printf("Magnetometer read failed and the return code is: %d\n", mag_read_ret);
		S_Mag_read.x =0;
		S_Mag_read.y =0;
		S_Mag_read.z =0;
	}
}



/**
    This api is used to initialise and read the IMU sensors and store it in a global structures S_Acc_read, V_Gyro_read_st and S_Mag_read **/

void bt_ccu_READ_IMU_SENSORS(void)
{
	bt_ccu_IMU_ProcessAccData();    // Initialises the accelerometer sensor and stores the data in S_Acc_read
	
	bt_ccu_IMU_ProcessGyroData();   // Initialises the gyroscope sensor and stores the data in V_Gyro_read_st
	
	//bt_ccu_IMU_ProcessMagData();  //Initialises the magnetometer sensor and stores the data in S_Mag_read
	
}

/**
   This api will return the accelerometer data **/
accelerometer_api_priv bt_ccu_IMU_GetAccData (void)
{
	return S_Acc_read;
}

/**
   This api will return the gyroscope data **/
gyroscope_api_priv bt_ccu_IMU_GetGyroData (void)
{
	return S_Gyro_read;
}

/**
   This api will return the magnetometer data **/
magnetometer_api_priv bt_ccu_IMU_GetMagData (void)
{
	return S_Mag_read;
}
