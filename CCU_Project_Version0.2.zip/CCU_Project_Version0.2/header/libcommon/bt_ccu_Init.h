#include <stdbool.h>
/**
 * @file bt_Initialisation.h
 * @author Venkatesh Prasad k @ Brigosha Technologies
 * @date January 2, 2025
 * @brief This file contains the Prototypes for Initialization functions.
 * @note
 * Copyright(C) Brigosha Technologies, 2025
 * All rights reserved.
 */
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/
 /******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/

bool bt_ccu_INIT_BAT_STS(void);
/**
 * @code
 *  bt_CCU_Initialisation(void)
 * @endcode
 * @brief This function initializes all the peripherals related to the CCU (Central Control Unit).
 * @param void
 * @return None
 * @note This function is called to configure the CCU and initialize all necessary peripherals before use.
 */
void bt_ccu_INIT(void);

/**
 * @code
 *  BT_CANInit(void)
 * @endcode
 * @brief This function initializes the CAN (Controller Area Network) interface.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note The function configures the CAN controller for communication with other CAN devices.
 */
bool bt_ccu_INIT_CAN_STS(void);

/**
 * @code
 *  BT_GPSInit(void)
 * @endcode
 * @brief This function initializes the GPS module for operation.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function sets up the GPS receiver for accurate position tracking.
 */
bool bt_ccu_INIT_GPS_STS(void);

/**
 * @code
 *  BT_WIFIInit(void)
 * @endcode
 * @brief This function initializes the Wi-Fi module for wireless communication.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function configures the Wi-Fi module for network connectivity.
 */
bool bt_ccu_INIT_WIFI_STS(void);

/**
 * @code
 *  BT_BLE_Init(void)
 * @endcode
 * @brief This function initializes the Bluetooth Low Energy (BLE) module for communication.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function prepares the BLE module for short-range wireless communication.
 */
bool bt_ccu_INIT_BLE_STS(void);

/**
 * @code
 *  BT_Ignition_Init(void)
 * @endcode
 * @brief This function initializes the ignition system for the device.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function configures the ignition system for proper operation.
 */
bool bt_ccu_INIT_IGN_STS(void);

/**
 * @code
 *  BT_Accelerometer_Init(void)
 * @endcode
 * @brief This function initializes the accelerometer sensor for motion sensing.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function sets up the accelerometer sensor for detecting movement or orientation changes.
 */
bool bt_ccu_INIT_ACC_STS(void);

/**
 * @code
 *  BT_Gyro_Init(void)
 * @endcode
 * @brief This function initializes the gyroscope sensor for rotational motion sensing.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function configures the gyroscope for detecting angular velocity or rotation.
 */
bool bt_ccu_INIT_GYRO_STS(void);

/**
 * @code
 *  BT_Magnetometer_Init(void)
 * @endcode
 * @brief This function initializes the magnetometer sensor for magnetic field detection.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function prepares the magnetometer sensor for detecting magnetic fields and orientation.
 */
bool bt_ccu_INIT_MAG_STS(void);

/**
 * @code
 *  BT_GSMModem_Status(void)
 * @endcode
 * @brief This function checks the status of the GSM modem.
 * @param void
 * @return int - Returns a status code (e.g., 0 for success, non-zero for failure)
 * @note This function queries the GSM modem for its operational status, indicating whether it is ready or not.
 */
bool bt_ccu_INIT_GSM_STS(void);

/**
 * Function to get the GSM message set initialization status.
 * This function returns the global flag that indicates whether 
 * the GSM message setup has been initialized successfully or not (TRUE or FALSE).
 */
bool bt_ccu_GSM_SET_MSG_STS(void);
/**
 * Function to get the SIM status.
 * This function returns the global flag that indicates whether 
 * the SIM setup or initialization has been completed successfully or not (TRUE or FALSE).
 */
bool bt_ccu_SIM_STS(void);
  /******************************************************************************/
/*-----------------------------END--------------------------------*/
/******************************************************************************/

