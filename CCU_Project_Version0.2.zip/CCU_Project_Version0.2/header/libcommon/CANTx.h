 /**
 * @file CANTx_028Processing.h
 * @author Venkatesh Prasad k @ Brigosha Technologies
 * @date January 2, 2025
 * @brief This file contains the Prototypes Initialisation.
 * @note
 * Copyright(C) Brigosha Technologies, 2025
 * All rights reserved.
 */
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/

#define C_ccu_CAN_TX_ID 0x4E0

// Define boolean TRUE and FALSE values for readability
#define TRUE 1   // TRUE is represented as 1
#define FALSE 0  // FALSE is represented as 0

// Define the CAN message ID for transmitting data
#define C_ccu_CAN_TX_ID 0x4E0  // CAN message ID for transmission (0x4E0 is a hexadecimal value)

// Macro for clearing a specific bit
#define CLEAR_BIT(byte, bit)    ((byte) &= ~(1 << (bit)))

/******************************************************************************/
// Macro for setting a specific bit
//#define SET_BIT_u8(byte, bit)      ((byte) |= (1 << (bit)))

/******************************************************************************/
// Macro to shift a value and set a specific bit
#define SET_BIT_WITH_VALUE(byte, bit, value)   ((byte) |= ((value) << (bit)))

/******************************************************************************/
// Macro for converting hex to ASCII
#define bt_ccu_HEX_TO_ASCII(value)   ((value) < 10 ? ('0' + (value)) : ('A' + ((value) - 10)))


// Macros for setting values to 1 and 0
#define BT_ONE_u8 1  // Represents the value '1' (ON)
#define BT_ZERO_u8 0 // Represents the value '0' (OFF)

// Macro to extract the first nibble (high nibble) from a byte
#define GET_HIGH_NIBBLE(byte)  ((byte) >> 4) & 0x0F

// Macro to extract the second nibble (low nibble) from a byte
#define GET_LOW_NIBBLE(byte)   (byte) & 0x0F

#define bt_ccu_OFFSETVALUE -118

#define bt_ccu_OFFSETERROR  -65

#define bt_ccu_ADC_TSHLD_Val 2300


#undef bt_ccu_IMUSensor_cs

#define bt_ccu_EmergencySOS_cs
/**************************************************************************************************************************/
 /******************************************************************************/
/*-----------------------------Data Structures--------------------------------*/
/******************************************************************************/



//void* process_data_packing(void* arg);

void bt_ccu_prc_data_pack(void);

/**
 * @code
 *  BT_CANTx_Processing(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28.
 *        The function handles the transmission of a CAN message to the bus.
 * @param void
 * @return CAN Write Specific Codes
 * @note The actual implementation for CAN transmission needs to be defined in the function body.
 */
void bt_ccu_CANTX_Proc(void);

/**
 * @brief This function checks the status of the CAN Tx.
 * @param void
 * @return Returns TRUE if CAN Tx is active, otherwise FALSE.
 * @note Used to determine the operational status of the CAN transmitter.
 */
bool bt_ccu_CANTX_STS(void);

int set_can_mask_and_filter (uint32_t *mask, uint32_t *filter, int no_of_filter); 

/**************************************************************************************************************************/
