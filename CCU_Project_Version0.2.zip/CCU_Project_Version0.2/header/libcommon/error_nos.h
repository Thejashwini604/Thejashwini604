
/*!< INclude File Header */
#ifndef __PROD_ERR_H_
#define __PROD_ERR_H_
#define INVALID_ARGS            -1
#define E_MQ_OPEN			100
#define E_MQ_SEND		        101
#define E_MQ_RECEIVE			102
#define E_SEM_INIT			103

/*!< Add Doxygen comment for macro, variables and function */
#define OBD2_LIB_SUCCESS	(0)
#define OBD2_LIB_FAILURE	(-1)
#define E_OBD2_LIB_INVALID_ARG	(-2)
#define E_MOD_SHIFT	 	(16)
#define E_MOD_MASK 			((1 << E_MOD_SHIFT) -1)

/*LIB GPIO ErrNos*/
#define E_LIB_GPIO_BASE			(0xF0000000)
#define E_LIB_GPIO_NOS			(E_LIB_GPIO_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

/*!< Configuration ErrNos */
#define E_SET_INVALID_GPIO		(E_LIB_GPIO_NOS + 1)
#define E_GPIO_EXP_OPEN 		(E_LIB_GPIO_NOS + 2)
#define E_GPIO_EXP_WRT 			(E_LIB_GPIO_NOS + 3)
#define E_GPIO_SET_DIR_OPEN	 	(E_LIB_GPIO_NOS + 4)
#define E_GPIO_SET_DIR_WRT 		(E_LIB_GPIO_NOS + 5)
#define E_GPIO_SET_DIR_ACCESS		(E_LIB_GPIO_NOS + 6)
#define E_GPIO_GET_OPEN 		(E_LIB_GPIO_NOS + 7)
#define E_GPIO_GET_RD 			(E_LIB_GPIO_NOS + 8)
#define E_GPIO_GET_VAL_ACCESS       	(E_LIB_GPIO_NOS + 9)
#define E_GPIO_SET_OPEN			(E_LIB_GPIO_NOS + 10)

#define E_LIB_GPIO_SUB_BASE         (0xF1000000)
#define E_LIB_GPIO_SUB_NOS          (E_LIB_GPIO_SUB_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_GPIO_SET_WRT			(E_LIB_GPIO_SUB_NOS + 1)
#define E_GPIO_SET_VAL_ACCESS		(E_LIB_GPIO_SUB_NOS + 2)
#define E_READ_F_OPEN 			(E_LIB_GPIO_SUB_NOS + 3)
#define E_READ_INVALID 			(E_LIB_GPIO_SUB_NOS + 4)
#define E_READ_F_ACCESS 		(E_LIB_GPIO_SUB_NOS + 5)
#define E_GPIO_GET_EVENT_NUMBER		(E_LIB_GPIO_SUB_NOS + 6)

/*LIB Serial ErrNos*/
#define E_LIB_SERIAL_BASE 		(0xF2000000)
#define E_LIB_SERIAL_NOS  		(E_LIB_SERIAL_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_SERIAL_INVALID            	(E_LIB_SERIAL_NOS + 1)
#define E_SERIAL_INIT 		        (E_LIB_SERIAL_NOS + 2)
#define E_SERIAL_WRITE            	(E_LIB_SERIAL_NOS + 3)
#define E_SERIAL_READ 	         	(E_LIB_SERIAL_NOS + 4)
#define E_SERIAL_BAUDRATE       	(E_LIB_SERIAL_NOS + 5)
#define E_SERIAL_DEINIT		        (E_LIB_SERIAL_NOS + 6)

/*LIB I2C ErrNos*/
#define E_LIB_I2C_BASE	                (0xF3000000)
#define E_LIB_I2C_NOS   	        (E_LIB_I2C_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_I2C_INVALID	                (E_LIB_I2C_NOS + 1)
#define E_I2C_OPEN                	(E_LIB_I2C_NOS + 2)

/*LIB I/F ErrNos*/
#define E_LIB_IF_BASE                  (0xF4000000)
#define E_LIB_IF_NOS               (E_LIB_IF_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_IF_INVALID                   (E_LIB_IF_NOS + 1)
#define E_IF_OPEN                  (E_LIB_IF_NOS + 2)

/*Cellular Module ErrNos*/
#define E_LIB_GSM_BASE    		(0xE0000000)
#define E_LIB_GSM_NOS 	 		(E_LIB_GSM_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_GSM_USB_INIT          	(E_LIB_GSM_NOS + 1)
#define E_GSM_USB_WRITE         	(E_LIB_GSM_NOS + 2) 
#define E_GSM_USB_READ          	(E_LIB_GSM_NOS + 3) 
#define E_GSM_USB_DISCONNECT    	(E_LIB_GSM_NOS + 4)

#define E_GSM_AT_SERIAL_INIT     	(E_LIB_GSM_NOS + 5)
#define E_GSM_AT_SERIAL_WRITE    	(E_LIB_GSM_NOS + 6)
#define E_GSM_AT_SERIAL_READ     	(E_LIB_GSM_NOS + 7)
#define E_GSM_IMEI_READ_TIMEOUT  	(E_LIB_GSM_NOS + 8)

#define E_GSM_NW_CONNECTION_DOWN       	(E_LIB_GSM_NOS + 9)
#define E_GSM_SIM_NOT_DETECTED    	(E_LIB_GSM_NOS + 10)

#define E_LIB_GSM_SUB_BASE          (0xE1000000)
#define E_LIB_GSM_SUB_NOS           (E_LIB_GSM_SUB_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_GSM_SIM_REG_ERROR      (E_LIB_GSM_SUB_NOS + 1)
#define E_GSM_SIM_STRENGTH_ERROR      (E_LIB_GSM_SUB_NOS + 2)
#define E_GSM_SIM_ICCID_ERROR      (E_LIB_GSM_SUB_NOS + 3)
#define E_GSM_SIM_SMS_SEND             (E_LIB_GSM_SUB_NOS + 4 )
#define E_GSM_SIM_SMS_SEND_MSG             (E_LIB_GSM_SUB_NOS + 5 )
#define E_GSM_SIM_SMS_DELETE             (E_LIB_GSM_SUB_NOS + 6 )
#define E_GSM_SIM_SMS_DELETE_ALL             (E_LIB_GSM_SUB_NOS + 7 )
#define E_BUFFER_READ_OVERFLOW           (E_LIB_GSM_SUB_NOS + 8 )
#define E_GSM_NETWORK_MODE_ENABLED           (E_LIB_GSM_SUB_NOS + 9 )

#define E_LIB_GSM_SUB2_BASE          (0xE2000000)
#define E_LIB_GSM_SUB2_NOS           (E_LIB_GSM_SUB2_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_GSM_SEM_INIT          (E_LIB_GSM_SUB2_NOS + 1)
#define E_GSM_SIM_NOT_VALID             (E_LIB_GSM_SUB2_NOS + 2)
#define E_GSM_NTP_FAILED            (E_LIB_GSM_SUB2_NOS + 3)
#define E_GSM_SIM_SMS_INIT             (E_LIB_GSM_SUB2_NOS + 4 )
#define E_GSM_SIM_SMS_UNREAD             (E_LIB_GSM_SUB2_NOS + 5 )
#define E_GSM_SIM_SMS_READ             (E_LIB_GSM_SUB2_NOS + 6 )



/*Battery ErrNos*/
#define E_LIB_IBAT_BASE                	(0xD0000000)
#define E_LIB_IBAT_NOS                  (E_LIB_IBAT_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_IBAT_GET_VOL_NODE_OPEN	(E_LIB_IBAT_NOS + 1)
#define E_IBAT_GET_VOL_NODE_READ	(E_LIB_IBAT_NOS + 2)
#define E_IBAT_GET_HEALTH_NODE_OPEN	(E_LIB_IBAT_NOS + 3)
#define E_IBAT_GET_HEALTH_NODE_READ	(E_LIB_IBAT_NOS + 4)

#define E_IBATTERY_NOT_CONNECTED   (E_LIB_IBAT_NOS + 5)
#define E_IBATTERY_FULLY_CHARGED   (E_LIB_IBAT_NOS + 6)
#define E_IBATTERY_CHARGING        (E_LIB_IBAT_NOS + 7)
#define E_IBATTERY_NOT_CHARGING    (E_LIB_IBAT_NOS + 8)
#define E_IBATTERY_UNSTABLE_STATE  (E_LIB_IBAT_NOS + 9)

/*Acceleromter Errnos */
#define E_LIB_ACC_BASE				(0xC0000000)
#define E_LIB_ACC_NOS				(E_LIB_ACC_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)
#define E_ACCELEROMTER_X_AXIS_INIT		(E_LIB_ACC_NOS + 1)
#define E_ACCELEROMTER_Y_AXIS_INIT      	(E_LIB_ACC_NOS + 2)
#define E_ACCELEROMTER_Z_AXIS_INIT      	(E_LIB_ACC_NOS + 3)
#define E_ACCELEROMTER_BUFFER_INIT     		(E_LIB_ACC_NOS + 4)
#define E_ACCELEROMETER_BULD_CHANNEL		(E_LIB_ACC_NOS + 5)
#define E_ACCELEROMETER_SCAN_SIZE		(E_LIB_ACC_NOS + 6)
#define E_ACCELEROMETER_ACC_INT_DISABLE		(E_LIB_ACC_NOS + 7)
#define E_ACCELEROMETER_I2C_REG_CONFIG		(E_LIB_ACC_NOS + 8)
#define E_ACCELEROMETER_SEM_INIT		(E_LIB_ACC_NOS + 9)

/*Magnetometer Errnos */
#define E_LIB_MAG_BASE                          (0xC1000000)
#define E_LIB_MAG_NOS                           (E_LIB_MAG_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)
#define E_MAG_BUILD_CHANNEL                     (E_LIB_MAG_NOS + 1)
#define E_MAG_SCAN_SIZE                         (E_LIB_MAG_NOS + 2)



/* Gyroscope Errnos */
#define E_LIB_GYRO_BASE				(0xB0000000)
#define E_LIB_GYRO_NOS				(E_LIB_GYRO_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_GYRO_X_AXIS_INIT			(E_LIB_GYRO_NOS + 1)
#define E_GYRO_Y_AXIS_INIT			(E_LIB_GYRO_NOS + 2)
#define E_GYRO_Z_AXIS_INIT              	(E_LIB_GYRO_NOS + 3)
#define E_GYRO_BUFFER_INIT              	(E_LIB_GYRO_NOS + 4)
#define E_GYRO_BULD_CHANNEL            		(E_LIB_GYRO_NOS + 5)
#define E_GYRO_SCAN_SIZE                        (E_LIB_GYRO_NOS + 6)
#define E_GYRO_I2C_REG_CONFIG                   (E_LIB_GYRO_NOS + 7)
#define E_GYRO_SEM_INIT                         (E_LIB_GYRO_NOS + 8)


/* GPS Errnos */
#define E_LIB_GPS_BASE                         (0xA0000000)
#define E_LIB_GPS_NOS                          (E_LIB_GPS_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)
#define E_GPS_USB_INIT			       (E_LIB_GPS_NOS + 1)
#define E_GPS_USB_DEINIT		       (E_LIB_GPS_NOS + 2)
#define E_GPS_USB_DISCONNECT		       (E_LIB_GPS_NOS + 3)
#define E_AGPS_ENABLE			       (E_LIB_GPS_NOS + 4)
#define E_AGPS_SET_TIME			       (E_LIB_GPS_NOS + 5)
#define E_AGPS_DEL_EXST_DATA		       (E_LIB_GPS_NOS + 6)
#define E_AGPS_HTTP_CFG_ENABLE		       (E_LIB_GPS_NOS + 7)
#define E_AGPS_QIACT_ENABLE		       (E_LIB_GPS_NOS + 8)
#define E_AGPS_URL_SIZE			       (E_LIB_GPS_NOS + 9)

#define E_AGPS_SUB_BASE          (0xA1000000)
#define E_AGPS_SUB_NOS           (E_AGPS_SUB_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)

#define E_AGPS_DOWNLOAD_DATA_INVALID           (E_AGPS_SUB_NOS + 1)
#define E_AGPS_READ_DATA_INVALID	       (E_AGPS_SUB_NOS + 2)
#define E_AGPS_LOAD_DATA_INVALID	       (E_AGPS_SUB_NOS + 3)
#define E_GPS_SEM_INIT		               (E_AGPS_SUB_NOS + 4)
#define E_AGPS_QICSGP                      (E_AGPS_SUB_NOS + 5)
#define E_AGPS_LIST_EXST_DATA              (E_AGPS_SUB_NOS + 6)
#define E_AGPS_QNTP                        (E_AGPS_SUB_NOS + 7)
#define E_GPS_PORT_EXIST                        (E_AGPS_SUB_NOS + 8)

/* CAN Errnos */
#define E_LIB_CAN_BASE                         (0x90000000)
#define E_LIB_CAN_NOS                          (E_LIB_CAN_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)
#define E_CAN_BITRATE			       (E_LIB_CAN_NOS + 1)
#define E_CAN_INIT			       (E_LIB_CAN_NOS + 2)
#define E_CAN_INTERFACE_NOT_FOUND	       (E_LIB_CAN_NOS + 3)
#define E_CAN_SEM_INIT                         (E_LIB_CAN_NOS + 4)
#define E_CAN_DEINIT                 (E_LIB_CAN_NOS + 5)
#define E_CAN_WAKEUP_ENABLED                         (E_LIB_CAN_NOS + 6)
#define E_CAN0_WAKEUP_FILE_CLOSE_ERROR          (E_LIB_CAN_NOS + 7)
#define E_CAN1_WAKEUP_FILE_CLOSE_ERROR          (E_LIB_CAN_NOS + 8)

/* WiFi Errnos */
#define E_LIB_WIFI_BASE                         (0x80000000)
#define E_LIB_WIFI_NOS                          (E_LIB_WIFI_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)
#define E_OBD2_LIB_MOD_INIT                  (E_LIB_WIFI_NOS + 1)
#define E_OBD2_LIB_MOD_DEINIT                 (E_LIB_WIFI_NOS + 2)
#define E_OBD2_LIB_WIFI_UP          (E_LIB_WIFI_NOS + 3)
#define E_OBD2_LIB_HOST_INIT                         (E_LIB_WIFI_NOS + 4)
#define E_OBD2_LIB_STA_INIT                         (E_LIB_WIFI_NOS + 5)
#define E_OBD2_LIB_HOST_DEINIT                         (E_LIB_WIFI_NOS + 6)
#define E_OBD2_LIB_STA_DEINIT                         (E_LIB_WIFI_NOS + 7)
#define E_OBD2_LIB_WIFI_IP_SET                         (E_LIB_WIFI_NOS + 8)
#define E_OBD2_LIB_WIFI_UDHCPD                         (E_LIB_WIFI_NOS + 9)


#define E_LIB_WIFI_SUB_BASE                  (0x81000000)
#define E_LIB_WIFI_SUB_NOS                   (E_LIB_WIFI_SUB_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)
#define E_OBD2_LIB_WIFI_IPTABLES                         (E_LIB_WIFI_SUB_NOS + 1)
#define E_OBD2_LIB_STA_UDHCPC                         (E_LIB_WIFI_SUB_NOS + 2)
#define E_OBD2_LIB_WIFI_IS_ACTIVE                         (E_LIB_WIFI_SUB_NOS + 3)

/* BLE Errnos */
#define E_LIB_BLE_BASE                         (0x70000000)
#define E_LIB_BLE_NOS                          (E_LIB_BLE_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)
#define E_OBD2_LIB_BLE_INIT                  (E_LIB_BLE_NOS + 1)
#define E_OBD2_LIB_BLE_DEINIT                  (E_LIB_BLE_NOS + 2)

/* BLE Errnos */
#define E_LIB_ETH_BASE                         (0x60000000)
#define E_LIB_ETH_NOS                          (E_LIB_ETH_BASE | (1 & E_MOD_MASK) << E_MOD_SHIFT)
#define E_OBD2_LIB_ETH_MAC0_ADDR                  (E_LIB_ETH_NOS + 1)
#define E_OBD2_LIB_ETH_MAC1_ADDR                  (E_LIB_ETH_NOS + 2)
#define E_OBD2_LIB_ETH_INIT                  (E_LIB_ETH_NOS + 3)
#define E_OBD2_LIB_ETH_DEINIT                  (E_LIB_ETH_NOS + 4)

#endif /* __PROD_ERR_H_*/
