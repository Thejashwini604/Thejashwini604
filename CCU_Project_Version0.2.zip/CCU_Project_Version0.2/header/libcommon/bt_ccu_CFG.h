/**
 * @file bt_ccu_CFG.h
 * @author Venkatesh Prasad K @ Brigosha Technologies
 * @date January 21, 2025
 * @brief This file contains the Prototypes for Initialization functions.
 * @note
 * Copyright(C) Brigosha Technologies, 2025
 * All rights reserved.
 */
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/


#define C_ccu_BBS_Rx_Sleep_10ms 10000  // Sleep for 10,000 microseconds (10 ms)

#define C_ccu_ECU_Rx_Sleep_10ms 10000 // Sleep for 10,000 microseconds (10 ms)

#define C_ccu_IMU_Sleep_500ms 500000 // Sleep for 5,00,000 microseconds (500 ms)

#define C_ccu_PHERIP_Sleep_500ms 500000 // Sleep for 5,00,000 microseconds (500 ms)

#define C_ccu_GPS_Sleep_1s 1 // Sleep for 10,00,000 microseconds (1s)

#define C_ccu_MSOS_Sleep_500ms 500000 // Sleep for 5,00,000 microseconds (500 ms)

#define C_ccu_ASOS_Sleep_500ms 500000 // Sleep for 5,00,000 microseconds (500 ms)

#define C_ccu_CAN_Tx_Sleep_500ms 500000 // Sleep for 5,00,000 microseconds (500 ms)

#define C_ccu_MQTT_Device_Sleep_500ms 500000 // Sleep for 5,00,000 microseconds (500 ms)

#define C_ccu_MQTT_GPS_Sleep_1s 1 // Sleep for 10,00,000 microseconds (1s)

#define C_ccu_IMU_Sleep_10ms 10000 // Sleep for 10,000 microseconds (10 ms)

#define C_ccu_IMU_ALGO_Sleep_500ms 500000 // Sleep for 5,00,000 microseconds (500 ms)

