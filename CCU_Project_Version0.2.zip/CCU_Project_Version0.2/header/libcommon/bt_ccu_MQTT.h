
#include <stdlib.h>
#include "accelerometer.h"
#include "gyroscope.h"
#include "magnetometer.h"
#include "bt_ccu_Init.h"

typedef struct {
 
    accelerometer_api_priv bt_acc_data;
    gyroscope_api_priv bt_gyro_data;
    magnetometer_api_priv bt_mag_data;
    
	//IMU status
    bool IMU_A_Init_Status ;  
    bool IMU_G_Init_Status ; 
    bool IMU_M_Init_Status;  
	
     //Battery voltage
    //float Internal_Battery_Voltage ;
    uint8_t Internal_Battery_Status;
    float Source_Voltage;
	
	//wifi status
    bool Wifi_Status ;
	
	//BT_Status
    bool BT_Status ;
	
	//Cellular Status
    bool Cellular_Status ;
    bool SIM_Active;
    bool GSM_NW ;
	
	//Ignition status
    bool Ignition_Status ;
	
	//CAN RX/TX STATUS
    bool CANRx_Status_BBS ;
    bool CANRx_Status_ECU ;
    bool CANTx_Status_CCU ;
	
	//SOS Status
    uint8_t SOS_Status ;
    
    	
} Device_SignalData;


typedef struct{
    
    //GPS Data &GPS Status
    bool GPS_Status_Init ;
    bool GPS_Status_Read;
    //char GPS_Status_Data_Validity[10] ;
    bool GPS_Status_Data_Validity;
    double GPS_Lat ;
    double GPS_Long ;

} GPS_SignalData;



void bt_ccu_mqtt_STRUCT_INTL(void);//initialize entire structure to 0
void bt_ccu_mqtt_DEVICE(void);
void bt_ccu_mqtt_GPS(void);






