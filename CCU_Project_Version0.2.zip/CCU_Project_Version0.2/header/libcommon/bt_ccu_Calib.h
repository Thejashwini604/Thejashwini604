


#define CALIBRATION_SAMPLES 100
#define SENSOR_RATE_HZ 104
#define SAMPLE_INTERVAL_US (1000000 / SENSOR_RATE_HZ) // Time interval in microseconds


extern double acc_x_offset;
extern double acc_y_offset;
extern double acc_z_offset;
extern double gyro_x_offset;
extern double gyro_y_offset;
extern double gyro_z_offset;
extern double mag_x_offset;
extern double mag_y_offset;
extern double mag_z_offset;


void calib_API(void);

