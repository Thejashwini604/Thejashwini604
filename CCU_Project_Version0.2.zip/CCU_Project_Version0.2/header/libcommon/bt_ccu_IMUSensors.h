/**
 * @file bt_ccu_IMU_sensors.h
 * @author Thejashwini Anand @ Brigosha Technologies
 * @date January 21, 2025
 * @brief This file contains the Prototypes for Initialization functions.
 * @note
 * Copyright(C) Brigosha Technologies, 2025
 * All rights reserved.
 */
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <termios.h>
#include <signal.h>
#include <stdint.h>
#include <linux/netlink.h>
#include <linux/if_link.h>
#include <linux/input.h>
#include <linux/rtnetlink.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>
#include "gsm.h"
#include <can.h>
#include "battery.h"
#include <time.h>
#include "error_nos.h"
#include "gyroscope.h"
#include "accelerometer.h"
#include "magnetometer.h"
#include "Std_generalmacros.h"
#include "stdbool.h"
#include "bt_ccu_Init.h"
/******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/

accelerometer_api_priv bt_ccu_IMU_GetAccData (void);
/**
 * @code
 *  IMU_GetAccData(void)
 * @endcode
 * @brief This function reads the accelerometer x, y and z axis values and store itis the global structure V_Acc_read_st
 * @param void
 * @return None
 * @note This function is called to get the accelerometer sensor values. */

gyroscope_api_priv bt_ccu_IMU_GetGyroData (void);
/**
 * @code
 *  IMU_GetGyroData(void)
 * @endcode
 * @brief This function reads the gyroscope x, y and z axis values and store itis the global structure V_Gyro_read_st
 * @param void
 * @return None
 * @note This function is called to get the gyroscope sensor values. */
 
 magnetometer_api_priv bt_ccu_IMU_GetMagData (void);
/**
 * @code
 *  IMU_GetMagData(void)
 * @endcode
 * @brief This function reads the magnetometer x, y and z axis values and store itis the global structure V_Mag_read_st
 * @param void
 * @return None
 * @note This function is called to get the magnetometer sensor values. */

void bt_ccu_READ_IMU_SENSORS(void);
 
 /****************************Constants***************************************************************/


