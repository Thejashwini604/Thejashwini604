/**
 * @file bt_ccu_Threads.h
 * @author Venkatesh Prasad K @ Brigosha Technologies
 * @date January 21, 2025
 * @brief This file contains the Prototypes for Initialization functions.
 * @note
 * Copyright(C) Brigosha Technologies, 2025
 * All rights reserved.
 */
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/
/******************************************************************************/
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/
// Function to get the current time as a string and store it in the provided buffer.
void get_time(char *buf);

// Thread function to handle data reception from the BBS (possibly a Battery Management System or similar device).
void* BBSRx_thread_func(void* arg);

// Thread function to handle data reception from the ECU (Engine Control Unit).
void* ECURx_thread_func(void* arg);

// Thread function to process data from the IMU (Inertial Measurement Unit).
//The imu calibration is required to be run for every 10ms for 100 samples and no need to run the calibration api later 
//hence the thread will be called for every 10ms for 1st 100 samples later it will be called for every 100ms
void* imu_thread_func(void* arg);

// Thread function to manage and control peripheral devices.
void* peripherals_thread_func(void* arg);

// Thread function to process data from the GPS module.
void* gps_thread_func(void* arg);

// Thread function to monitor and handle manual SOS (emergency) events.
void* manual_sos_thread_func(void* arg);

// Thread function to monitor and handle automatic SOS (emergency) events.
void* auto_sos_thread_func(void* arg);

// Thread function to handle CAN (Controller Area Network) data transmission.
void* can_tx_thread_func(void* arg);

// Thread function to manage MQTT communication for device-related operations.
void* ccu_mqtt_device_Thread(void* arg);

// Thread function to manage MQTT communication specifically for GPS data.
void* ccu_mqtt_gps_Thread(void* arg);

//Thread function to run the imu algorithm logic to send the sms 
void* auto_sos_algo_thread_func(void* arg);

 

