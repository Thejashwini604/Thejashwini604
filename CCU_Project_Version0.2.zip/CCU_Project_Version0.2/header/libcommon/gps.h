#ifndef __GPS_H_
#define __GPS_H_

int gps_init();
int gps_deinit();
int get_gps_data(char * nmea, size_t * g_nbytes, char *recv_data, int);
int agps_init();
#endif
