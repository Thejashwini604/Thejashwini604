/**
 * @file bt_GPS.h
 * @author Venkatesh Prasad K @ Brigosha Technologies
 * @date January 2, 2025
 * @brief This file contains the Prototypes of GPS functions.
 * @note
 * Copyright(C) Brigosha Technologies, 2017
 * All rights reserved.
 */
 
/******************************************************************************/ 
/*-----------------------------START----------------------------------------*/ 
/******************************************************************************/ 

/******************************************************************************/ 
/*-----------------------------Data Structures--------------------------------*/ 
/******************************************************************************/ 
 
/******************************************************************************/ 
/*-------------------------Function Prototypes--------------------------------*/ 
/******************************************************************************/ 

/**
 * Function to process the GPS data
 * 
 * This function is responsible for processing GPS data. The exact details of
 * the processing would depend on the specific implementation of this function,
 * which is not shown in this header file. This could involve parsing NMEA sentences,
 * validating data, and updating internal states or buffers.
 */
void bt_ccu_GPS_PRCS(void);

/**
 * Set the Get GPS read Data flag to TRUE
 * 
 * This function is responsible for returning TRUE to indicate that the GPS data 
 * should be retrieved or that the flag for GPS data collection is set to active.
 * 
 * @return TRUE - indicating that GPS data collection is enabled.
 */
bool bt_ccu_GPS_READ(void);

// Function to return the gps_status array
bool bt_ccu_GET_GPS_STS(void);
// Function to return a copy of the gps_lat_decimal variable
double bt_ccu_GET_GPS_LAT_DEC(void);

// Function to return a copy of the gps_lon_decimal variable
double bt_CCU_GET_GPS_LON_DEC(void);// Returning the value by copy (not by reference)

/******************************************************************************/ 
/*-----------------------------END------------------------------------------*/ 
/******************************************************************************/ 

