#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <termios.h>
#include <signal.h>
#include <stdint.h>
#include <linux/netlink.h>
#include <linux/if_link.h>
#include <linux/input.h>
#include <linux/rtnetlink.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>
#include "gsm.h"
#include <can.h>
#include "gyroscope.h"
#include "accelerometer.h"
#include "error_nos.h"
#include "magnetometer.h"
#include "battery.h"
#include <time.h>
#include "bt_ccu_CANRx.h"
#include "bt_ccu_Init.h"
#include "bt_ccu_Pheripherals.h"
#include "bt_ccu_CANTx.h"
//#include "bt_EmergencySOS.h"
#include "Std_generalmacros.h"
 /******************************************************************************/
/*-----------------------------START--------------------------------*/
/******************************************************************************/
 /******************************************************************************/
/*-------------------------Global Variables--------------------------------*/
/******************************************************************************/
// Global flags to indicate status for Ignition, ADC, and additional voltage
bool V_ccu_init_ign_sts = FALSE;

float bt_ccu_ADC_SRC_VOLT = 0;  // Variable to store the adc source voltage reading

float bt_ccu_ADC_ETRL_VOLT = 0;  // Variable to store the adc external source voltage reading

bool V_ccu_gsm_modem_sts = FALSE;

bool V_ccu_GSM_set_msg_init = FALSE; // variable to store the GSM to text message mode

bool V_ccu_sim_sts = FALSE;     // variable to store the sim status, 1- inserted, 0- not inserted

bool V_ccu_sms_sts = FALSE; // variable to store the send sms status, 1- sent , 0- not sent

 /*************************************************************************************************************/
/*-------------------------Function Prototypes-------------------------------------------------------------------------------*/
/**************************************************************************************************************/
/**
 * Function declaration to check and initialize the Ignition PIN status.
 * This function will enable the ignition status check and set the corresponding global flag
 * for the Ignition status (successful or failed).
 */
void bt_ccu_IGN_PIN_STS(void);

/**
 * Function declaration to check and initialize the ADC source voltage.
 * This function will request the voltage reading from an ADC channel and set the global flag
 * to indicate whether the ADC source voltage has been initialized successfully.
 */
void bt_ccu_ADC_SRC_VOL(void);

/**
 * Function declaration to check and initialize the additional external voltage source.
 * This function will request the voltage reading from a different ADC channel (external voltage)
 * and set the global flag to indicate whether the external voltage has been initialized successfully.
 */
void bt_ccu_ADC_ETRL_SRC_VOL(void);


void bt_ccu_GSM_MODEM_ON(void);

/******************************************************************************/
 /******************************************************************************/
/*-------------------------Function Definition--------------------------------*/
/******************************************************************************/
/******************************************************************************/

/**
 * Function to initialize or check the status of all peripheral devices.
 * This function calls the initialization or status-checking functions for various peripherals, including:
 * Ignition system, ADC Source Voltage, and ADC External Source Voltage.
 */
void bt_ccu_PHERIPH(void)
{
    // Call the function to check or initialize the Ignition PIN status
    bt_ccu_IGN_PIN_STS();
    
    // Call the function to check or initialize the ADC Source Voltage
    bt_ccu_ADC_SRC_VOL();
    
    // Call the function to check or initialize the ADC External Source Voltage
    bt_ccu_ADC_ETRL_SRC_VOL();
	
	//Call the function to check GSM modem status 
	bt_ccu_GSM_MODEM_ON();
}

/**
 * Function to check and initialize the Ignition PIN status.
 * This function enables the ignition status check and sets the corresponding global flag 
 * based on the result of the ignition status check.
 */
void bt_ccu_IGN_PIN_STS(void) {
    
    // Initialize Ignition status (check if ignition pin is valid)
   int  v_ccu_int_rc = ignition_pin_status();  
    // Set the global flag based on the result of ignition initialization
    V_ccu_init_ign_sts = (v_ccu_int_rc == 1) ? TRUE : FALSE; 
    printf("Ignition initialization %s. Status: %d\n", V_ccu_init_ign_sts ? "successful" : "failed", v_ccu_int_rc);
}

/**
 * Function to check and initialize the ADC source voltage.
 * This function reads the voltage from a specific ADC channel and sets the global flag 
 * for the ADC source voltage status.
 */
void bt_ccu_ADC_SRC_VOL(void) {
    int bt_ccu_adc = 1, bt_ccu_ret = 0;  // ADC channel and return status variable
    
    // Request ADC reading for channel 1 and store the result in bt_ccu_adc_volt
    bt_ccu_ret = MCU_ADC_Read_Request(bt_ccu_adc, &bt_ccu_ADC_SRC_VOLT);
    printf("ADC Source Voltage is %f\n",bt_ccu_ADC_SRC_VOLT);
    
}

/**
 * Function to check and initialize the additional external voltage source.
 * Similar to `bt_ccu_ADC_SRC_VOLT`, but for a different ADC channel (channel 3).
 */
void bt_ccu_ADC_ETRL_SRC_VOL(void) {

    int bt_ccu_adc = 3, bt_ccu_ret = 0;  // ADC channel and return status variable
    
    // Request ADC reading for channel 3 and store the result in bt_ccu_adc_volt
    bt_ccu_ret = MCU_ADC_Read_Request(bt_ccu_adc, &bt_ccu_ADC_ETRL_VOLT);
    printf("ADC External Voltage is %f\n",bt_ccu_ADC_ETRL_VOLT);
}

/** This api is used to check the gsm modem status and wait untill gsm status set to TRUE 
** once it becomes true the global variable V_ccu_gsm_modem_sts will be set and Sim status, 
** GSM set message to init could be called**/
void bt_ccu_GSM_MODEM_ON(void)
{

    int SIMStatus_u8 = 0;  // Default SIM status value
    int v_ccu_gsm_modem_ret;
    int v_ccu_sim_rc;
	int v_ccu_gsm_init_rc;
		
	if (V_ccu_gsm_modem_sts == FALSE)
	{
	
		v_ccu_gsm_modem_ret = check_gsm_modem_status();
		V_ccu_gsm_modem_sts= (v_ccu_gsm_modem_ret==0)? TRUE:FALSE;
		printf("V_ccu_gsm_modem_sts status is : %d\n", V_ccu_gsm_modem_sts);
		printf("check gsm modem return code is : %d\n", v_ccu_gsm_modem_ret);
		
		if(V_ccu_gsm_modem_sts == TRUE)
		{
	     
          v_ccu_sim_rc = get_gsm_sim_status(&SIMStatus_u8);  // Retrieve the GSM SIM status
          // Set the global flag based on the result of BLE initialization
          V_ccu_sim_sts = ((v_ccu_sim_rc == 0) && (SIMStatus_u8 ==1))? TRUE : FALSE;
          printf("SIM Status %s. Status: %d\n", V_ccu_sim_sts ? "successful" : "failed", v_ccu_sim_rc);
		  printf("Sim Status is %d\n", SIMStatus_u8);

         // set the GSM to text message mode
          v_ccu_gsm_init_rc = GSM_set_to_message_init ();
        // Set the global flag based on the result of GSM Message Init
         V_ccu_GSM_set_msg_init = (v_ccu_gsm_init_rc == 0) ? TRUE : FALSE;
         printf(" GSM set Message Init %s. Status: %d\n", V_ccu_GSM_set_msg_init ? "successful" : "failed", v_ccu_gsm_init_rc);
        }
    }
}

/**************************************************************************************************************************
@ code bool bt_ccu_SendSMS(void)
@ Brief: This API is used to send the message to the specific contact number when the MSOS or ASOS event 
@ is triggered
@ param: void
@ return: bool sms sent-1, sms not sent-0
***************************************************************************************************************************/
bool bt_ccu_SendSMS(void)
{
   int v_ccu_sms_rc;
  bool V_ccu_sms_sts;
  
  //Before sending sms check the below status
  //1. Sim status, gsm modem status and gsm set message to init status should be TRUE 
  
     v_ccu_sms_rc = send_sms("ESOS detected! Need help", "9986302881", GSM_RESP_TIME );
	 V_ccu_sms_sts= (v_ccu_sms_rc == BT_SUCCESS)? TRUE: FALSE;
     printf("sms %s, return code is %d\n", V_ccu_sms_sts? "sent successfully": "not sent " , v_ccu_sms_rc);
    

          
return V_ccu_sms_sts;
}


/**
 * Function to get the Ignition status.
 * This function returns the global flag that indicates whether the Ignition status 
 * has been initialized successfully (TRUE or FALSE).
 */
bool bt_ccu_IGN_STS(void) {
    return V_ccu_init_ign_sts;  // Return the global flag for Ignition status initialization
}

/**
 * Function to get the ADC source voltage status.
 * This function returns the global flag that indicates whether the ADC source voltage 
 * has been initialized successfully (TRUE or FALSE).
 */
float bt_ccu_ADC_SRC_V(void) {
    return bt_ccu_ADC_SRC_VOLT;  // Return the global flag for ADC source voltage initialization
}

/**
 * Function to get the additional external voltage status.
 * This function returns the global flag that indicates whether the additional external voltage 
 * has been initialized successfully (TRUE or FALSE).
 */
float bt_ccu_ADC_ETRL_V(void) {
    return bt_ccu_ADC_ETRL_VOLT;  // Return the global flag for additional external voltage initialization
}

/**
 * Function to get the GSM message set initialization status.
 * This function returns the global flag that indicates whether 
 * the GSM message setup has been initialized successfully or not (TRUE or FALSE).
 */
bool bt_ccu_GSM_SET_MSG_STS(void) {
    // Return the value of the global flag 'V_ccu_GSM_set_msg_init', which holds 
    // the status of the GSM message setup initialization.
    return V_ccu_GSM_set_msg_init;  // Return the global flag for GSM message set initialization status
}
/**
 * Function to get the SIM status.
 * This function returns the global flag that indicates whether 
 * the SIM setup or initialization has been completed successfully or not (TRUE or FALSE).
 */
bool bt_ccu_SIM_STS(void) {
    // Return the value of the global flag 'V_ccu_sim_sts', which holds 
    // the status of the SIM setup or initialization.
    return V_ccu_sim_sts;  // Return the global flag for SIM initialization status
}

/** 
 * Function to get the gsm modem status
 * This function returns the global flag that indicates whether the 
 * GSM modem is on not (TRUE 0r FALSE)
 */
 bool bt_ccu_GSM_MODEM_STS(void){
    return V_ccu_gsm_modem_sts;
 }
 /******************************************************************************/
/*-------------------------END------------------------------------------------*/
/******************************************************************************/

