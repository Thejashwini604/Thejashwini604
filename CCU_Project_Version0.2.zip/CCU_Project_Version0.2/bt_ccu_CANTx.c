/**
 * @file CANTx_028Processing.c
 * @author Venkatesh Prasad k @ Brigosha Technologies
 * @date January 2, 2025
 * @brief This file contains the Prototypes of GPS.
 * @note
 * Copyright(C) Brigosha Technologies, 2017
 * All rights reserved.
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "common.h"
#include "gps.h"
#include <fcntl.h>
#include <termios.h>
#include <signal.h>
#include <stdint.h>
#include <linux/netlink.h>
#include <linux/if_link.h>
#include <linux/input.h>
#include <linux/rtnetlink.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <unistd.h>
#include <errno.h>
#include "gsm.h"
#include <can.h>
#include "gyroscope.h"
#include "accelerometer.h"
#include "error_nos.h"
#include "magnetometer.h"
#include "battery.h"
#include <time.h>
#include "bt_ccu_CANRx.h"
#include  "bt_ccu_Init.h"
#include  "bt_ccu_Pheripherals.h"
#include "bt_ccu_CANTx.h"
#include  "bt_ccu_ESOS.h"
#include  "bt_ccu_GPS.h"
#include <stdbool.h>
 
 /******************************************************************************/  
/*-----------------------------START--------------------------------*/
/******************************************************************************/


/******************************************************************************/  
/*-----------------------------Global Variables--------------------------------*/
/******************************************************************************/  

// String representing the data to be sent in CAN (Controller Area Network)
// "4E0#0000000000000000" could represent a CAN message in a specific format
// where '4E0' is the CAN ID and the rest is the payload data (usually 8 bytes of data).
char bt_ccu_CAN_Tx_DATA[] = "4E0#0000000000000000";  // Data to be sent in CAN

// Boolean variable indicating the transmission status of the CAN message
// 'FALSE' implies the message has not been transmitted yet, and will be changed when sent.
bool bt_ccu_CAN_Tx_STS = FALSE;  


/******************************************************************************/  
/*-------------------------Function Prototypes--------------------------------*/
/******************************************************************************/  

/** 
 * @brief Converts a hexadecimal value to its ASCII equivalent.
 * 
 * This function takes a hexadecimal value and converts it to an ASCII representation 
 * so that it can be printed or used in character-based operations. 
 * 
 * @param Value The hexadecimal value to convert.
 * @return The ASCII representation of the hexadecimal value.
 * 
 * Example: 0xA would return the ASCII character 'A'.
 */
char bt_ccu_Hex2ASCII(int Value);


/**
 * @brief Initializes CAN transmission for communication.
 * 
 * This function is responsible for setting up all the necessary configurations 
 * to transmit data over the CAN bus. It could include setting the CAN ID, data payload,
 * baud rate, and any other transmission-related settings before starting the transmission.
 */
void bt_ccu_CAN_TX_PackEmerSOS(void);


/**
 * @brief Sets or checks the GPS status.
 * 
 * This function is used to either enable, disable, or check the status of the GPS system.
 * It can indicate whether the GPS module is active and ready to provide data.
 * It can also set flags for GPS status based on the current state of the system.
 */
void bt_ccu_GPSReadDataSts(void);


/**
 * @brief Sets or checks if GPS data is valid.
 * 
 * This function checks whether the data provided by the GPS module is valid. 
 * It ensures that the GPS is providing coherent data that can be used for further operations.
 * This could include validating the integrity of GPS position data like latitude and longitude.
 */
void bt_ccu_GPSValidData(void);
/**
 * @brief Sets or checks the Wi-Fi status.
 * 
 * This function checks whether the Wi-Fi connection is active or not. It can return a status indicating 
 * whether the Wi-Fi is enabled, connected to a network, or if there is an issue with the connection.
 */
void bt_ccu_WIFISts_u8(void);

/**
 * @brief Sets or checks the Bluetooth status.
 * 
 * This function checks the status of the Bluetooth module. It verifies whether Bluetooth is connected 
 * to a device or whether it is enabled and ready for communication.
 */
void bt_ccu_BT_STS(void);

/**
 * @brief Sets or checks the Ignition status.
 * 
 * This function checks the status of the ignition system, determining whether the ignition is turned 
 * on or off. This is typically used in automotive systems to confirm the engine or vehicle power state.
 */
void bt_ccu_Igtn_sts(void);

/**
 * @brief Sets or checks the GSM Modem status.
 * 
 * This function checks the operational status of the GSM modem. It can verify whether the GSM module 
 * is working, ready to transmit, or has an error or issue preventing its operation.
 */
void bt_ccu_GSMMod_sts(void);

/**
 * @brief Sets or checks the overall Battery status.
 * 
 * This function checks the current battery status. It provides information about whether the battery 
 * is charging, discharging, and overall health or condition of the battery.
 */
void BT_ccu_Bat_sts(void);

/**
 * @brief Sets or checks the SIM card status.
 * 
 * This function checks the status of the SIM card, verifying if it is inserted correctly and if it is 
 * functional. It is typically used to detect if a valid SIM card is present for GSM operations.
 */
void bt_ccu_SIM_sts(void);

/**
 * @brief Sets or checks the Accelerometer status.
 * 
 * This function checks whether the accelerometer is operational and transmitting data. The accelerometer 
 * typically detects changes in acceleration or orientation and is used in motion sensing applications.
 */
void bt_ccu_Acc_sts(void);

/**
 * @brief Sets or checks the Gyroscope status.
 * 
 * This function checks whether the gyroscope is operational and transmitting data. A gyroscope is used 
 * for detecting rotational movements and is commonly used in orientation and motion sensing systems.
 */
void bt_ccu_Gyro_sts(void);

/**
 * @brief Sets or checks the Magnetometer status.
 * 
 * This function checks the operational status of the magnetometer, which is used to measure magnetic fields 
 * (typically for detecting direction, such as a digital compass).
 */
void bt_ccu_Mag_sts(void);

/**
 * @brief Sets or checks the ADC voltage status.
 * 
 * This function checks the status of the ADC (Analog-to-Digital Converter) voltage measurement. It verifies 
 * if the ADC is correctly measuring the voltage or if any issues are present in the analog-to-digital conversion.
 */
void bt_ccu_adc_vol(void);

/**
 * @brief Reads the GPS Read status.
 * 
 * This function checks the status of GPS reading. It can verify if the GPS system is successfully receiving 
 * data, if the GPS fix is acquired, or if there is any issue with the GPS reception.
 */
void bt_ccu_CAN_TX_GPS_STS(void);

/**
 * @brief Checks the 8th byte of the message.
 * 
 * This function retrieves and processes the 8th byte in a message. The function may be used to extract 
 * or analyze specific data from the 8th byte of a message, which could be crucial for further processing.
 */
void bt_ccu_Byte8(void);

/**
 * @brief Checks the 6th byte of the message.
 * 
 * This function retrieves and processes the 6th byte in a message, similar to `bt_ccu_Byte8()`. It is 
 * used to extract specific data from the 6th byte of a message for processing or analysis.
 */
void bt_ccu_adc_extrl_volt(void);

/**
 * @brief Checks the GSM network connection status.
 * 
 * This function checks whether the GSM modem is connected to the cellular network and has a valid 
 * connection. It typically verifies the signal strength and connectivity status to the GSM network.
 */
void BT_ccu_check_gsm_nw_con(void);

/**
 * @brief Reads the ECU status.
 * 
 * This function reads the status of the ECU (Electronic Control Unit). It can retrieve information about 
 * the health and operational state of the ECU in an automotive or control system.
 */
void BT_ccu_ECUReadSts(void);

/**
 * @brief Reads the BBS status.
 * 
 * This function reads the status of the BBS (Body Control System), which is responsible for monitoring 
 * and controlling various vehicle or system functions, such as lights, doors, or windows.
 */
void BT_ccu_BBSReadSts(void);

/**
 * @brief Reads the CANTx status.
 * 
 * This function reads the status of the CAN TX (Controller Area Network Transmission). It checks the 
 * operational status of the CAN transmission, ensuring data is being sent correctly over the CAN bus.
 */
void BT_ccu_CANTx_sts(void);

 /******************************************************************************/  
/*-----------------------------Function Definition--------------------------------*/
/******************************************************************************/  
/**
 * @brief This function is used to write a CAN message with Message ID 0x4E0
 * 
 * The function processes and sends CAN messages to the CAN bus with a specific message ID 
 * (0x4E0). It sets up the CAN mask and filter, initiates data packing, and writes data to 
 * the CAN bus. It also handles error checking for the CAN mask/filter setup and the 
 * actual CAN message write process.
 * 
 * @param void No input parameters.
 * @return CAN Write Specific Status Codes (success or failure).
 * @note This function uses the predefined mask and filter ID for sending the CAN message.
 */
void bt_ccu_CANTX_Proc(void) {
    int bt_ccu_rc ;  // Variable to store the return code of CAN operations
    char bt_ccu_can_name[] = "can0";  // CAN interface name (default CAN interface to send messages)
    
    // CAN mask for matching specific message ID (used to match the message ID in the CAN bus)
    uint32_t bt_ccu_can_mask[1] = {C_ccu_CAN_TX_ID};  
    
    // CAN filter ID for incoming messages (used to filter CAN messages based on specific criteria)
    uint32_t bt_ccu_can_ftr[1] = {C_ccu_CAN_TX_ID};  
    
    // Calculate the length of the filter ID array (used for configuring the filter)
    int bt_ccu_length = sizeof(bt_ccu_can_ftr) / sizeof(bt_ccu_can_ftr[0]);  
    
    // Boolean flag to track if the CAN filter setup was successful
    bool bt_ccu_can_Filter = FALSE;
    
    // Set the CAN mask and filter using the predefined mask and filter IDs
    bt_ccu_rc = set_can_mask_and_filter(bt_ccu_can_mask, bt_ccu_can_ftr, bt_ccu_length);
    
    // Check the result of the mask and filter setup
    if (bt_ccu_rc == 0) {
        bt_ccu_can_Filter = TRUE;
        // If the mask and filter setup is successful, print a confirmation message
        printf("CAN mask and filter status: Success\n");
    } else {
        bt_ccu_can_Filter = FALSE;
        // If the mask and filter setup fails, print an error message
        printf("CAN mask and filter status: Failure\n");
    }

    // This section of code is commented out but represents the creation of a thread to parallelly execute 
    // the data packing function, which would process the data to be sent on the CAN bus
    // pthread_t packing_thread;
    // pthread_create(&packing_thread, NULL, bt_ccu_prc_data_pack, NULL);
    
    // Wait for the packing thread to finish before proceeding with the CAN transmission
    // pthread_join(packing_thread, NULL);

    // Check if CAN initialization was successful
    if (bt_ccu_INIT_CAN_STS() == TRUE) {
        
        // Proceed only if the CAN filter setup was successful
        if(bt_ccu_can_Filter == TRUE) {
            
            // Call the function to process and pack the data to be sent over CAN
            bt_ccu_prc_data_pack();

            // Write the CAN message to the CAN bus using the specified CAN interface and message data
            bt_ccu_rc = can_write(bt_ccu_can_name, bt_ccu_CAN_Tx_DATA);
            
            // Check the result of the CAN write operation
            if (bt_ccu_rc == 0) {
                // If the CAN message write was successful, update the CAN transmission status
                bt_ccu_CAN_Tx_STS = TRUE;
                // Print a success message
                printf("CAN write success: %d\n", bt_ccu_rc);
            } else {
                // If the CAN message write failed, update the CAN transmission status to failure
                bt_ccu_CAN_Tx_STS = FALSE;
                // Print a failure message
                printf("CAN write failed: %d\n", bt_ccu_rc);
            }
        } else {
            // If the CAN filter setup failed, update the CAN transmission status to failure
            bt_ccu_CAN_Tx_STS = FALSE;
            // Print an error message indicating the filter initialization failed
            printf("CAN Mask Filter Initialization Failed: %d\n", bt_ccu_rc);
        }
    } else {
        // If CAN initialization failed, update the CAN transmission status to failure
        bt_ccu_CAN_Tx_STS = FALSE;
        // Print an error message indicating the CAN initialization failed
        printf("CAN Initialization Failed: %d\n", bt_ccu_rc);
    }
}
/**
 * @brief Simulates the packing and processing of data for various system components.
 * 
 * This function processes and packs data from different sensors and communication modules 
 * (such as GPS, WiFi, Bluetooth, GSM, etc.). Each component's data is handled in a separate 
 * function, and these tasks can potentially be performed in parallel. The function returns 
 * NULL to indicate the completion of the data packing process.
 *
 * @param bt_ccu_arg A pointer to any additional arguments (currently unused in the function).
 * @return NULL to signify the end of the data packing process.
 */
void bt_ccu_prc_data_pack(void) {
    // Simulate packing data for various components (each can be done in parallel)

    // Pack emergency SOS data for CAN transmission
    bt_ccu_CAN_TX_PackEmerSOS();
    
    // Pack GPS status data for CAN transmission
    bt_ccu_CAN_TX_GPS_STS();
    
    // Validate the GPS data to ensure it's correct and ready for use
    bt_ccu_GPSValidData();
    
    // Read and process the GPS data status (e.g., signal strength, validity, etc.)
    bt_ccu_GPSReadDataSts();
    
    // Pack WiFi status (such as connection status or signal strength) as an 8-bit value
    bt_ccu_WIFISts_u8();
    
    // Process Bluetooth status (check if Bluetooth is connected and functional)
    bt_ccu_BT_STS();
    
    // Process ignition status (detect whether the vehicle ignition is on or off)
    bt_ccu_Igtn_sts();
    
    // Process GSM module status (check GSM communication status, such as network connection)
    bt_ccu_GSMMod_sts();
    
    // Process SIM card status (check whether the SIM card is inserted and functional)
    bt_ccu_SIM_sts();
    
    // Process accelerometer (Acc) status (read acceleration data from the accelerometer)
    bt_ccu_Acc_sts();
    
    // Process gyroscope (Gyro) status (read gyroscope data to measure orientation and movement)
    bt_ccu_Gyro_sts();
    
    // Process magnetometer (Mag) status (read data from the magnetometer to detect magnetic fields)
    bt_ccu_Mag_sts();
    
    // Process BBS (Battery Backup System) read status (monitor the health and status of the BBS)
    BT_ccu_BBSReadSts();
    
    // Process ECU (Electronic Control Unit) read status (read diagnostic information from the ECU)
    BT_ccu_ECUReadSts();
    
    // Process CAN Tx Status (monitor the status of the CAN transmission process)
    BT_ccu_CANTx_sts();
    
    // Check GSM network connection status (verify GSM network availability and connectivity)
    BT_ccu_check_gsm_nw_con();
    
    // Process battery status (check battery health, charging status, and battery level)
    BT_ccu_Bat_sts();
    
    // Read ADC (Analog-to-Digital Converter) voltage value (measures voltage levels in the system)
    bt_ccu_adc_vol();
    
    // Read ADC (Analog-to-Digital Converter) voltage value (measures voltage levels in the system)
    bt_ccu_adc_extrl_volt();
    
    // Process additional data byte 8 (this could represent another piece of system-specific data)
    bt_ccu_Byte8();

    // Return NULL to indicate completion (this is unnecessary in C, as the function doesn't need to return anything)
    // Since the function is void, you can safely omit the return statement.
    // return NULL;
}


// Function to check the status of CAN Tx (Controller Area Network Transmit)
// @return TRUE if CAN Tx is active, FALSE otherwise
bool bt_ccu_CANTX_STS(void)
{
    // In this function, it simply returns TRUE, which means CAN Tx is active.
    // In a real implementation, this function would include logic to check
    // the actual status of the CAN Tx hardware or software component.

    return bt_ccu_CAN_Tx_STS;  // CAN Tx is active (TRUE) or deactive ( FALSE )
}

/**
 * @code
 *  bt_ccu_Hex2ASCII(int Value)
 * @endcode
 * @brief this function is used to convert Hex to Ascii
 * @param void
 * @return Char
 * @note
 */
// Helper function to convert a hex value (0-15) to its corresponding ASCII character
char bt_ccu_Hex2ASCII(int Value)
{
    return bt_ccu_HEX_TO_ASCII(Value);  // Using the macro to convert
}

/**
 * @code
 *  bt_PackEmergencySOS_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28 and pack the emergency SOS status.
 * @param void
 * @return CAN Write Specific Codes
 * @note
 */
// Function to pack the emergency SOS status
void bt_ccu_CAN_TX_PackEmerSOS(void) {

    uint8_t bt_ccu_msos_sts = bt_ccu_ESOS_Message_Byte_u8();  // Decimal value 50 representing SOS status

    // Split the hex_value into two nibbles (4-bit parts)
    uint8_t first_nibble = GET_HIGH_NIBBLE(bt_ccu_msos_sts);  // Extract the first nibble (0x3)
    uint8_t second_nibble = GET_LOW_NIBBLE(bt_ccu_msos_sts);  // Extract the second nibble (0x2)

    // Convert the nibbles to ASCII and store in bt_ccu_CAN_Tx_DATA[4] and bt_ccu_CAN_Tx_DATA[5]
    bt_ccu_CAN_Tx_DATA[4] = bt_ccu_Hex2ASCII(first_nibble); // Convert 0x3 to ASCII '3' (0x33)
    bt_ccu_CAN_Tx_DATA[5] = bt_ccu_Hex2ASCII(second_nibble); // Convert 0x2 to ASCII '2' (0x32)
}
/**
 * @code
 *  bt_GPSStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28 and update the GPS status in byte 6.
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the GPS status in byte 6 of the CAN message.
 */
// Function to update the GPS status in byte 6
void bt_ccu_CAN_TX_GPS_STS(void) {
    uint8_t bt_ccu_gps_sts = BT_ZERO_u8;   // Default GPS status value initialization (0 for inactive)
    
    // Retrieve the current GPS initialization status (e.g., from a GPS module)
    bt_ccu_gps_sts = bt_ccu_INIT_GPS_STS();

    // Clear the bit corresponding to GPS status in byte 6 (bit 0)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[6], 7);  // Clear the 1st bit (0-indexed, bit 0)
    
    // Set the bit corresponding to GPS status in byte 6 (bit 0)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[6], 7, bt_ccu_gps_sts);  // Set the 1st bit with the retrieved GPS status value (active or inactive)
}

/**
 * @code
 *  bt_GPSValidData_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28 and update the GPS valid data status in byte 6.
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the GPS valid data status in byte 6 of the CAN message.
 */
// Function to update the GPS valid data status in byte 6
void bt_ccu_GPSValidData(void) {
    uint8_t bt_ccu_gps_valid_sts = BT_ONE_u8;   // Default GPS valid data status value initialization (1 for valid)
    
    // Retrieve the current GPS valid data status (e.g., from a GPS module or data validation system)
    bt_ccu_gps_valid_sts = bt_ccu_GET_GPS_STS();
    
    // Clear the bit corresponding to GPS valid data status in byte 6 (bit 1)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[6], 6);  // Clear the 2nd bit (0-indexed, bit 1)
    
    // Set the bit corresponding to GPS valid data status in byte 6 (bit 1)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[6], 6, bt_ccu_gps_valid_sts);  // Set the 2nd bit with the retrieved GPS valid data status value (valid or invalid)
}

/**
 * @code
 *  bt_GPSReadDataStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28 and update the GPS read data status in byte 6.
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the GPS read data status in byte 6 of the CAN message.
 */
// Function to update the GPS read data status in byte 6
void bt_ccu_GPSReadDataSts(void) {
    uint8_t bt_ccu_gps_read_sts = BT_ONE_u8;   // Default GPS read data status value initialization (1 for data available)
    
    // Retrieve the current GPS read data status (e.g., from a GPS module or system)
    bt_ccu_gps_read_sts = bt_ccu_GPS_READ(); 

    // Clear the bit corresponding to GPS read data status in byte 6 (bit 2)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[6], 5);  // Clear the 3rd bit (0-indexed, bit 2)
    
    // Set the bit corresponding to GPS read data status in byte 6 (bit 2)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[6], 5, bt_ccu_gps_read_sts);  // Set the 3rd bit with the retrieved GPS read data status value (data available or not)
}

/**
 * @code
 *  bt_WIFIStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28 and update the Wi-Fi status in byte 6.
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the Wi-Fi status in byte 6 of the CAN message.
 */
// Function to update the Wi-Fi status in byte 6
void bt_ccu_WIFISts_u8(void) {
    uint8_t bt_ccu_wifi_sts = BT_ZERO_u8;  // Default Wi-Fi status value initialization (0 for disconnected)
    
    // Retrieve the current Wi-Fi status (e.g., from a Wi-Fi module or system)
    bt_ccu_wifi_sts = bt_ccu_INIT_WIFI_STS();

    // Clear the bit corresponding to Wi-Fi status in byte 6 (bit 3)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[6], 4);  // Clear the 4th bit (0-indexed, bit 3)
    
    // Set the bit corresponding to Wi-Fi status in byte 6 (bit 3)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[6], 4, bt_ccu_wifi_sts);  // Set the 4th bit with the retrieved Wi-Fi status value (connected or disconnected)
}

/**
 * @code
 *  bt_BluetoothStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28 and update the Bluetooth status in byte 6.
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the Bluetooth status in byte 6 of the CAN message.
 */
// Function to update the Bluetooth status in byte 6
void bt_ccu_BT_STS(void) {
    uint8_t bt_ccu_bt_sts = BT_ZERO_u8;  // Default Bluetooth status value (0 for inactive)
    
    // Retrieve the current Bluetooth status (e.g., from a Bluetooth module or system state)
    bt_ccu_bt_sts = bt_ccu_INIT_BLE_STS();

    // Clear the bit corresponding to Bluetooth status in byte 6 (bit 4)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[6], 3);  // Clear the 5th bit (0-indexed, bit 4)
    
    // Set the bit corresponding to Bluetooth status in byte 6 (bit 4)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[6], 3, bt_ccu_bt_sts);  // Set the 5th bit with the retrieved Bluetooth status value (active or inactive)
}

/**
 * @code
 *  bt_IgnitionStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28 and update the Ignition status in byte 6.
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the Ignition status in byte 6 of the CAN message.
 */
// Function to update the Ignition status in byte 6
void bt_ccu_Igtn_sts(void) {
    uint8_t bt_ccu_ign_sts = BT_ZERO_u8;  // Default Ignition status value (0 for OFF)
    
    // Retrieve the current Ignition status (e.g., from a vehicle's ignition system)
    bt_ccu_ign_sts = bt_ccu_IGN_STS();

    // Clear the bit corresponding to Ignition status in byte 6 (bit 5)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[6], 2);  // Clear the 6th bit (0-indexed, bit 5)
    
    // Set the bit corresponding to Ignition status in byte 6 (bit 5)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[6], 2, bt_ccu_ign_sts);  // Set the 6th bit with the retrieved Ignition status value (ON or OFF)
}

/**
 * @code
 *  bt_GSMModemStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28 and update the GSM Modem status in byte 6.
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the GSM Modem status in byte 6 of the CAN message.
 */
// Function to update the GSM Modem status in byte 6
void bt_ccu_GSMMod_sts(void) {
    uint8_t bt_ccu_gsm_mdm_sts = BT_ONE_u8;  // Default GSM Modem status value (1 for connected)
    
    // Retrieve the current GSM Modem network status (e.g., from a GSM module)
    bt_ccu_gsm_mdm_sts = bt_ccu_INIT_GSM_STS();

    // Clear the bit corresponding to GSM Modem status in byte 6 (bit 6)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[6], 1);  // Clear the 7th bit (0-indexed, bit 6)
    
    // Set the bit corresponding to GSM Modem status in byte 6 (bit 6)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[6], 1, bt_ccu_gsm_mdm_sts);  // Set the 7th bit with the retrieved GSM Modem status value (connected or disconnected)
}

/**
 * @code
 *  bt_SIMStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28 and update the SIM status in byte 6.
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the SIM status in byte 6 of the CAN message.
 */
// Function to update the SIM status in byte 6
void bt_ccu_SIM_sts(void) {
    int bt_ccu_sim_sts = BT_ZERO_u8;  // Default SIM status value (0 for inactive)
    
    // Retrieve the current SIM status (e.g., from a SIM card reader or system state)
    bt_ccu_sim_sts = bt_ccu_SIM_STS();

    // Clear the bit corresponding to SIM status in byte 6 (bit 7)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[6], 0);  // Clear the 8th bit (0-indexed, bit 7)
    
    // Set the bit corresponding to SIM status in byte 6 (bit 7)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[6], 0, bt_ccu_sim_sts);  // Set the 8th bit with the retrieved SIM status value (active or inactive)   

    // Split the hex_value into two nibbles
    uint8_t first_nibble = GET_HIGH_NIBBLE(bt_ccu_CAN_Tx_DATA[6]);  // Extract the first nibble (0x3)
    uint8_t second_nibble = GET_LOW_NIBBLE(bt_ccu_CAN_Tx_DATA[6]);        // Extract the second nibble (0x2)

    // Convert the nibbles to ASCII and store in bt_ccu_CAN_Tx_DATA[6] and bt_ccu_CAN_Tx_DATA[7]
    bt_ccu_CAN_Tx_DATA[6] = bt_ccu_Hex2ASCII(first_nibble);  // Convert 0x3 to ASCII '3' (0x33)
    bt_ccu_CAN_Tx_DATA[7] = bt_ccu_Hex2ASCII(second_nibble); // Convert 0x2 to ASCII '2' (0x32)
}

/**
 * @code
 *  bt_AccelerometerStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the accelerometer status in byte 8 of the CAN data array.
 */
// Function to update the Accelerometer status in byte 8
void bt_ccu_Acc_sts(void) {
    uint8_t bt_ccu_acc_sts = BT_ONE_u8;  // Default Accelerometer status value (1 for active)
    
    // Retrieve the current accelerometer status (e.g., from a sensor or system state)
    bt_ccu_acc_sts = bt_ccu_INIT_ACC_STS();
        
    // Clear the bit corresponding to the accelerometer status in byte 8 (bit 0)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[8], 7);  // Clear the 1st bit (0-indexed)
    
    // Set the bit corresponding to the accelerometer status in byte 8 (bit 0)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[8], 7, bt_ccu_acc_sts);  // Set the 1st bit with the new accelerometer status value
}

/**
 * @code
 *  bt_GyroscopeStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the gyroscope status in byte 8 of the CAN data array.
 */
// Function to update the Gyroscope status in byte 8
void bt_ccu_Gyro_sts(void) {
    uint8_t bt_ccu_gyro_sts = BT_ONE_u8;  // Default Gyroscope status value (1 for active)
    
    // Retrieve the current gyroscope status (e.g., from a sensor or system state)
    bt_ccu_gyro_sts = bt_ccu_INIT_GYRO_STS();
     
    // Clear the bit corresponding to the gyroscope status in byte 8 (bit 1)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[8], 6);  // Clear the 2nd bit (0-indexed)
    
    // Set the bit corresponding to the gyroscope status in byte 8 (bit 1)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[8], 6, bt_ccu_gyro_sts);  // Set the 2nd bit with the new gyroscope status value
}

/**
 * @code
 *  bt_MagnetometerStatus_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the magnetometer status in byte 8 of the CAN data array.
 */
// Function to update the Magnetometer status in byte 8
void bt_ccu_Mag_sts(void) {
    uint8_t bt_ccu_msg_sts = BT_ONE_u8;  // Default Magnetometer status value (1 for active)
    
    // Retrieve the current magnetometer status (e.g., from a sensor or system state)
    bt_ccu_msg_sts = bt_ccu_INIT_MAG_STS();
    
    // Clear the bit corresponding to the magnetometer status in byte 8 (bit 2)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[8], 5);  // Clear the 3rd bit (0-indexed)
    
    // Set the bit corresponding to the magnetometer status in byte 8 (bit 2)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[8], 5, bt_ccu_msg_sts);  // Set the 3rd bit with the new magnetometer status value
}

/**
 * @code
 *  BT_BBSReadStatus(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the BBS read status in byte 8 of the CAN data array.
 */
// Function to update the BBS Read status in byte 8
void BT_ccu_BBSReadSts(void) {
    uint8_t bt_ccu_bbs_read_sts = BT_ZERO_u8;  // Default BBS Read status value (0 for inactive)
   
    // Retrieve the current BBS read status (e.g., from a sensor or system state)
    bt_ccu_bbs_read_sts = bt_ccu_RX_BBSREADSTS();
      
    // Clear the bit corresponding to the BBS read status in byte 8 (bit 3)
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[8], 4);  // Clear the 4th bit (0-indexed)
    
    // Set the bit corresponding to the BBS read status in byte 8 (bit 3)
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[8], 4, bt_ccu_bbs_read_sts);  // Set the 4th bit with the new BBS read status value
}

/**
 * @code
 *  BT_ECUReadStatus(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates the ECU read status in byte 10 by checking the ECU status
 *       and modifying the corresponding bit.
 */
// Function to update the ECU Read status in byte 10
void BT_ccu_ECUReadSts(void) {
    uint8_t bt_ccu_ecu_read_sts = BT_ZERO_u8;  // Default ECU Read status value (1 for active)
   
    bt_ccu_ecu_read_sts = bt_ccu_RX_ECUREADSTS();  // Retrieve the current ECU status from CAN message
    
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[8], 3);  // Clear the 5th bit (0-indexed), position of ECU read status
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[8], 3, bt_ccu_ecu_read_sts);  // Set the 5th bit with the new ECU read status value    
}
/**
 * @code
 *  BT_BatteryStatus(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates byte 10 with battery status information.
 */
// Function to update the Battery status in byte 10
void BT_ccu_CANTx_sts(void) {
    uint8_t rb_ccu_can_tx_sts = bt_ccu_CANTX_STS();  // Default battery status value (1 for active)  
    
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[8], 2);  // Clear the 7th bit (0-indexed), position of battery status
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[8], 2, rb_ccu_can_tx_sts);  // Set the 7th bit with the new battery status value      
}
/**
 * @code
 *  BT_check_gsm_nw_connection(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function checks the GSM network connection status and updates byte 10 accordingly.
 */
// Function to check the GSM network connection in byte 10
void BT_ccu_check_gsm_nw_con(void) {
    uint8_t bt_ccu_gsm_nw_con = BT_ONE_u8;  // Default value (1 for connected)
    
    bt_ccu_gsm_nw_con = check_gsm_nw_connection();  // Retrieve the current GSM network connection status
    
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[8], 1);  // Clear the 6th bit (0-indexed), position of GSM network status
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[8], 1, bt_ccu_gsm_nw_con);  // Set the 6th bit with the new GSM network connection status
}

/**
 * @code
 *  BT_BatteryStatus(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates byte 10 with battery status information.
 */
// Function to update the Battery status in byte 10
void BT_ccu_Bat_sts(void) {
    uint8_t bt_ccu_bat_sts = BT_ZERO_u8;  // Default battery status value (1 for active)  
    
    CLEAR_BIT(bt_ccu_CAN_Tx_DATA[8], 0);  // Clear the 7th bit (0-indexed), position of battery status
    SET_BIT_WITH_VALUE(bt_ccu_CAN_Tx_DATA[8], 0, bt_ccu_bat_sts);  // Set the 7th bit with the new battery status value      

    // Split the hex_value into two nibbles (4-bit each)
    uint8_t first_nibble = GET_HIGH_NIBBLE(bt_ccu_CAN_Tx_DATA[8]);  // Extract the higher 4 bits (first nibble)
    uint8_t second_nibble = GET_LOW_NIBBLE(bt_ccu_CAN_Tx_DATA[8]);        // Extract the lower 4 bits (second nibble)
    
    // Convert the nibbles to ASCII characters and store them in bt_ccu_CAN_Tx_DATA[10] and bt_ccu_CAN_Tx_DATA[11]
    bt_ccu_CAN_Tx_DATA[8] = bt_ccu_Hex2ASCII(first_nibble);  // Convert the first nibble to ASCII and store in bt_ccu_CAN_Tx_DATA[8]
    bt_ccu_CAN_Tx_DATA[9] = bt_ccu_Hex2ASCII(second_nibble); // Convert the second nibble to ASCII and store in bt_ccu_CAN_Tx_DATA[9]
}

/**
 * @code
 *  bt_ADCVoltage_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function retrieves and updates the ADC voltage value in bytes 12 and 13.
 */
// Function to update ADC voltage in byte 12 and 13
/**
 * @brief Function to convert ADC voltage to a decimal value and store it in CAN message for transmission.
 */
void bt_ccu_adc_vol(void) {

    float bt_ccu_adc_vol;  // Variable to hold the ADC voltage value
    
    int bt_ccu_dec_val;  // Variable to hold the calculated decimal value after processing the ADC voltage
    
    uint8_t first_nibble_MSB, first_nibble_LSB, second_nibble_MSB, second_nibble_LSB;

    bt_ccu_adc_vol = bt_ccu_ADC_SRC_V();  // Retrieve the actual ADC voltage value using the function 'bt_ccu_ADC_SRC_V'
    
    // Calculate the decimal value based on ADC voltage, applying conversion for a 3.3V reference and scaling factor
    bt_ccu_dec_val = (float)((bt_ccu_adc_vol / (3.3 * 11 / 4095)) - bt_ccu_OFFSETVALUE);
    
    // If the calculated decimal value is greater than a threshold (2300), apply an error correction offset
    if(bt_ccu_dec_val > bt_ccu_ADC_TSHLD_Val) 
    {
        bt_ccu_dec_val = (float)((bt_ccu_adc_vol / (3.3 * 11 / 4095)) - bt_ccu_OFFSETERROR);
    } 
    else 
    {
        // No action required if value is below the threshold
    }

    // Store the most significant byte (MSB) of the decimal value in the CAN message (byte 10)
    bt_ccu_CAN_Tx_DATA[10] = (bt_ccu_dec_val >> 8) & 0xFF;  // MSB: Extract the higher 8 bits
    // Store the least significant byte (LSB) of the decimal value in the CAN message (byte 12)
    bt_ccu_CAN_Tx_DATA[12] = bt_ccu_dec_val & 0xFF;         // LSB: Extract the lower 8 bits

    // Convert the MSB byte into its hexadecimal representation
    first_nibble_MSB = GET_HIGH_NIBBLE(bt_ccu_CAN_Tx_DATA[10]); // Extract the higher 4 bits (first nibble) from MSB
    second_nibble_MSB = GET_LOW_NIBBLE(bt_ccu_CAN_Tx_DATA[10]);  // Extract the lower 4 bits (second nibble) from MSB

    // Convert the nibbles into ASCII characters and store them in the CAN message
    bt_ccu_CAN_Tx_DATA[10] = bt_ccu_Hex2ASCII(first_nibble_MSB);  // Convert first nibble of MSB to ASCII and store in byte 10
    bt_ccu_CAN_Tx_DATA[11] = bt_ccu_Hex2ASCII(second_nibble_MSB); // Convert second nibble of MSB to ASCII and store in byte 11
    
    // Convert the LSB byte into its hexadecimal representation
    first_nibble_LSB = GET_HIGH_NIBBLE(bt_ccu_CAN_Tx_DATA[12]);  // Extract the higher 4 bits (first nibble) from LSB
    second_nibble_LSB = GET_LOW_NIBBLE(bt_ccu_CAN_Tx_DATA[12]);  // Extract the lower 4 bits (second nibble) from LSB

    // Convert the nibbles into ASCII characters and store them in the CAN message
    bt_ccu_CAN_Tx_DATA[12] = bt_ccu_Hex2ASCII(first_nibble_LSB);  // Convert first nibble of LSB to ASCII and store in byte 12
    bt_ccu_CAN_Tx_DATA[13] = bt_ccu_Hex2ASCII(second_nibble_LSB); // Convert second nibble of LSB to ASCII and store in byte 13

}

/**
 * @code
 *  bt_ccu_adc_extrl_volt(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates Byte 6 in the data array with the hexadecimal value 0xCC.
 */
 // Function to update Byte 6 in data array
void bt_ccu_adc_extrl_volt(void) {

    float bt_ccu_adc_vol;  // Variable to hold the ADC voltage value
    
    int bt_ccu_dec_val;  // Variable to hold the calculated decimal value after processing the ADC voltage
    
    uint8_t first_nibble_MSB, first_nibble_LSB, second_nibble_MSB, second_nibble_LSB;

    bt_ccu_adc_vol = bt_ccu_ADC_ETRL_V();  // Retrieve the actual ADC voltage value using the function 'bt_ccu_ADC_SRC_V'
    
    // Calculate the decimal value based on ADC voltage, applying conversion for a 3.3V reference and scaling factor
    bt_ccu_dec_val = (float)((bt_ccu_adc_vol / (3.3 * 11 / 4095)) - bt_ccu_OFFSETVALUE);
    
    // If the calculated decimal value is greater than a threshold (2300), apply an error correction offset
    if(bt_ccu_dec_val > bt_ccu_ADC_TSHLD_Val) 
    {
        bt_ccu_dec_val = (float)((bt_ccu_adc_vol / (3.3 * 11 / 4095)) - bt_ccu_OFFSETERROR);
    } 
    else 
    {
        // No action required if value is below the threshold
    }

    // Store the most significant byte (MSB) of the decimal value in the CAN message (byte 10)
    bt_ccu_CAN_Tx_DATA[14] = (bt_ccu_dec_val >> 8) & 0xFF;  // MSB: Extract the higher 8 bits
    // Store the least significant byte (LSB) of the decimal value in the CAN message (byte 12)
    bt_ccu_CAN_Tx_DATA[16] = bt_ccu_dec_val & 0xFF;         // LSB: Extract the lower 8 bits

    // Convert the MSB byte into its hexadecimal representation
    first_nibble_MSB = GET_HIGH_NIBBLE(bt_ccu_CAN_Tx_DATA[14]); // Extract the higher 4 bits (first nibble) from MSB
    second_nibble_MSB = GET_LOW_NIBBLE(bt_ccu_CAN_Tx_DATA[14]);  // Extract the lower 4 bits (second nibble) from MSB

    // Convert the nibbles into ASCII characters and store them in the CAN message
    bt_ccu_CAN_Tx_DATA[14] = bt_ccu_Hex2ASCII(first_nibble_MSB);  // Convert first nibble of MSB to ASCII and store in byte 10

    bt_ccu_CAN_Tx_DATA[15] = bt_ccu_Hex2ASCII(second_nibble_MSB); // Convert second nibble of MSB to ASCII and store in byte 11
    
    // Convert the LSB byte into its hexadecimal representation
    first_nibble_LSB = GET_HIGH_NIBBLE(bt_ccu_CAN_Tx_DATA[16]);  // Extract the higher 4 bits (first nibble) from LSB
    second_nibble_LSB = GET_LOW_NIBBLE(bt_ccu_CAN_Tx_DATA[16]);  // Extract the lower 4 bits (second nibble) from LSB

    // Convert the nibbles into ASCII characters and store them in the CAN message
    bt_ccu_CAN_Tx_DATA[16] = bt_ccu_Hex2ASCII(first_nibble_LSB);  // Convert first nibble of LSB to ASCII and store in byte 12
    bt_ccu_CAN_Tx_DATA[17] = bt_ccu_Hex2ASCII(second_nibble_LSB); // Convert second nibble of LSB to ASCII and store in byte 13
}

/**
 * @code
 *  bt_Byte7_u8(void)
 * @endcode
 * @brief This function is used to write the CAN Tx with Message ID 0x28
 * @param void
 * @return CAN Write Specific Codes
 * @note This function updates Byte 8 in the data array with the hexadecimal value 0xCC.
 */
 // Function to update Byte 8 in data array
void bt_ccu_Byte8(void) {
    int Byte8 = 0XCC;  // Example value to be written (0xDD), could be any 8-bit value

    // Split the hex_value (0xDD) into two nibbles (4-bit chunks)
    uint8_t first_nibble = GET_HIGH_NIBBLE(Byte8);  // Extract the first nibble (higher 4 bits) from the byte
    uint8_t second_nibble = GET_LOW_NIBBLE(Byte8);        // Extract the second nibble (lower 4 bits) from the byte

    // Convert the nibbles to ASCII characters and store them in the CAN message data array
    bt_ccu_CAN_Tx_DATA[18] = bt_ccu_Hex2ASCII(first_nibble);  // Convert the first nibble to ASCII and store in bt_ccu_CAN_Tx_DATA[18]
    bt_ccu_CAN_Tx_DATA[19] = bt_ccu_Hex2ASCII(second_nibble); // Convert the second nibble to ASCII and store in bt_ccu_CAN_Tx_DATA[19]
}

